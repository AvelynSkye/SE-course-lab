#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "app/app_context.h"
#include "app/seed.h"
#include "domain/datetime.h"
#include "infra/csv_util.h"
#include "infra/data_store.h"
#include "infra/security.h"
#include "service/activity_service.h"
#include "service/audit_service.h"
#include "service/auth_service.h"
#include "service/background_task_service.h"
#include "service/notification_service.h"
#include "service/registration_service.h"
#include "service/role_service.h"
#include "service/session_service.h"
#include "service/stats_service.h"
#include "service/ticket_service.h"
#include "ui/console_io.h"
#include "ui/console_view.h"

namespace {
using namespace campus;
using domain::Id;
using domain::RegistrationStatus;
using domain::VersionStatus;

void Need(bool ok, const std::string& msg) {
  if (!ok) throw std::runtime_error(msg);
}

struct Tmp {
  std::filesystem::path dir = std::filesystem::temp_directory_path() /
                              ("campus-uml-" + infra::UuidGenerator::V4());
  Tmp() { std::filesystem::create_directories(dir); }
  ~Tmp() { std::filesystem::remove_all(dir); }
};

struct Act {
  Id activity_id = 0, activity_version_id = 0, sid = 0, cid = 0;
};

struct Fx {
  infra::DataStore db;
  service::AuditService aud{&db};
  service::RoleService rls{&db, &aud};
  service::AuthService auth{&db, &aud, &rls};
  service::NotificationService ntf{&db, &aud, &rls};
  service::TicketService tkt{&db, &rls, &aud};
  service::SessionService ss{&db, &rls, &aud, &ntf, &tkt};
  service::ActivityService act{&db, &rls, &aud, &ntf, &tkt};
  service::RegistrationService reg{&db, &rls, &aud, &ntf, &tkt};
  service::StatsService stat{&db, &rls, &aud};
  service::BackgroundTaskService bg{&db, &aud, &ntf, &rls, &tkt};
  Id adm, org, insp, u1, u2, u3;
  std::string txt;

  Id User(domain::Role rl) {
    domain::User u;
    u.id = db.NextId("user");
    u.account = "u" + std::to_string(u.id);
    u.name = u.account;
    u.password_hash = infra::PasswordHasher::Hash(u.account, "abcdef");
    db.usrs().push_back(u);
    db.user_roles().push_back({u.id, rl});
    if (db.usrs().empty() || db.usrs().back().account != u.account)
      throw std::runtime_error("fixture insert failed");
    if (auth.FindByAccount(u.account) == nullptr)
      throw std::runtime_error("fixture auth lookup failed: " + u.account +
                               "/" + db.usrs().back().account);
    Id id = 0;
    const auto res = auth.Login(u.account, "abcdef", &id);
    Need(res.ok, "fixture login: " + res.msg);
    return id;
  }

  Fx() {
    adm = User(domain::Role::kAdministrator);
    org = User(domain::Role::kOrganizer);
    insp = User(domain::Role::kInspector);
    u1 = User(domain::Role::kOrdinaryParticipant);
    u2 = User(domain::Role::kOrdinaryParticipant);
    u3 = User(domain::Role::kOrdinaryParticipant);
  }

  Act New(const std::string& location = "A1", int capacity = 1) {
    Act x;
    Need(act.CreateActivity(org, location, "desc", &x.activity_id).ok,
         "create activity");
    x.activity_version_id = act.LatestVersion(x.activity_id)->id;
    const auto ts = domain::Now();
    Need(ss.CreateSession(org, x.activity_version_id, location, ts + 3600,
                          ts + 7200, ts - 3600, ts + 1800, capacity, &x.sid)
             .ok,
         "create session");
    Need(ss.CreateCategory(org, x.activity_version_id, x.sid, "ticket",
                           capacity, &x.cid)
             .ok,
         "create category");
    return x;
  }

  void Go(const Act& x) {
    Need(act.SubmitReview(org, x.activity_version_id).ok, "submit review");
    Need(act.Review(adm, x.activity_version_id, true, "").ok, "approve");
    Need(act.Publish(org, x.activity_version_id).ok, "publish");
  }

  Id Reg(Id user_id, const Act& x) {
    Need(reg.Register(user_id, x.sid, x.cid, "", &txt).ok, "register");
    return db.regs().back().id;
  }
};

void Absence() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto id = f.Reg(f.u1, x);
  auto* ended = f.ss.FindSession(x.sid, x.activity_version_id);
  ended->start_time = domain::Now() - 100;
  ended->end_time = domain::Now() - 1;
  ended->registration_start = domain::Now() - 300;
  ended->registration_end = domain::Now() - 200;
  Need(f.bg.RunAbsenceDetection(f.adm) > 0, "absence job ran");
  Need(f.reg.Find(id)->status == RegistrationStatus::kAbsent,
       "absence persisted in record");
  Need(f.tkt.FindByRegistration(id) == nullptr, "absent ticket invalidated");
  Need(f.ntf.UnreadCount(f.u1) == 1, "absence notification");
  Need(f.bg.RunAbsenceDetection(f.adm) == 0, "absence is idempotent");
  const auto xs = f.stat.QueryStats(f.adm, x.activity_id);
  Need(xs.size() == 1 && xs[0].absN == 1 && xs[0].attRt == 0, "absence stats");
  Tmp tmp;
  const bool saved = f.db.Save(tmp.dir.string());
  Need(saved, "save absence: " + f.db.Error());
  infra::DataStore db;
  Need(db.Load(tmp.dir.string()), "load absence data");
  Need(db.regs().front().status == RegistrationStatus::kAbsent &&
           !db.ntfs().front().event_id.empty(),
       "absence and event survive restart");
}

void Deadline() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto a = f.Reg(f.u1, x), b = f.Reg(f.u2, x), c = f.Reg(f.u3, x);
  Need(f.auth.SetStatus(f.adm, f.u2, domain::UserStatus::kDisabled).ok,
       "disable candidate");
  Need(f.reg.Cancel(f.u1, a, &f.txt).ok, "cancel before deadline");
  Need(f.reg.Find(b)->status == RegistrationStatus::kWaitlisted &&
           f.reg.Find(c)->status == RegistrationStatus::kRegistered,
       "skip disabled candidate");
  f.ss.FindSession(x.sid, x.activity_version_id)->registration_end =
      domain::Now() - 1;
  Need(f.auth.SetStatus(f.adm, f.u2, domain::UserStatus::kActive).ok,
       "enable candidate");
  Need(f.reg.Cancel(f.u3, c, &f.txt).ok,
       "late cancellation accepted before end");
  Need(f.reg.Find(b)->status == RegistrationStatus::kWaitlisted,
       "no late promotion");
  Need(f.bg.RunDeadlineNotification(f.adm) == 1, "expire waitlist");
  Need(f.reg.Find(b)->status == RegistrationStatus::kExpired, "expired status");
  Need(!f.reg.Register(f.u1, x.sid, x.cid, "", &f.txt).ok,
       "late registration refused");
  Need(f.tkt.FindByRegistration(b) == nullptr,
       "expired candidate has no ticket");
  Need(f.bg.RunDeadlineNotification(f.adm) == 0, "deadline idempotent");
  Fx g;
  auto y = g.New();
  g.Go(y);
  const auto r1 = g.Reg(g.u1, y);
  g.Reg(g.u2, y);
  g.auth.SetStatus(g.adm, g.u2, domain::UserStatus::kDisabled);
  g.reg.Cancel(g.u1, r1, &g.txt);
  const auto r3 = g.Reg(g.u3, y);
  Need(g.reg.Find(r3)->status == RegistrationStatus::kRegistered,
       "invalid waitlist does not block available seats");
  g.ss.FindSession(y.sid, y.activity_version_id)->end_time = domain::Now() - 1;
  Need(!g.reg.Cancel(g.u3, r3, &g.txt).ok,
       "cannot evade absence after session ends");
  Fx h;
  auto z = h.New();
  h.Go(z);
  const auto r4 = h.Reg(h.u1, z), r5 = h.Reg(h.u2, z);
  h.ss.FindSession(z.sid, z.activity_version_id)->registration_end =
      domain::Now() - 1;
  auto nz = z;
  Need(h.act.CreateVersion(h.org, z.activity_id, &nz.activity_version_id).ok,
       "clone for extended deadline");
  auto* ns = h.ss.FindSession(nz.sid, nz.activity_version_id);
  ns->registration_end = domain::Now() + 100;
  h.Go(nz);
  h.reg.Cancel(h.u1, r4, &h.txt);
  Need(h.reg.Find(r5)->status == RegistrationStatus::kRegistered,
       "active waitlist migrated to new deadline and promoted");
}

void Retry() {
  Fx f;
  f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kDisabled);
  Need(!f.ntf.Notify(f.u1, domain::NotificationType::kPromoted, "hello", "ev1"),
       "failed delivery queued");
  Need(f.db.background_tasks().size() == 1, "one retry task");
  f.bg.RetryFailedTasks(f.adm);
  Need(f.db.background_tasks()[0].status == domain::TaskStatus::kFailed &&
           f.ntf.UnreadCount(f.u1) == 0,
       "failed retry stays failed");
  Tmp tmp;
  Need(f.db.Save(tmp.dir.string()), "save retry data");
  infra::DataStore db;
  Need(db.Load(tmp.dir.string()), "load retry data");
  Need(db.background_tasks()[0].cnt == "hello" &&
           db.background_tasks()[0].user_id == f.u1,
       "retry payload survives restart");
  f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kActive);
  Id user_id = 0;
  Need(f.auth.Login(f.auth.FindUser(f.u1)->account, "abcdef", &user_id).ok,
       "login after reactivation");
  f.bg.RetryFailedTasks(f.adm);
  Need(f.ntf.UnreadCount(f.u1) == 1 &&
           f.db.background_tasks()[0].status == domain::TaskStatus::kSuccess,
       "retry actually delivers");
  f.ntf.MarkAllRead(f.u1);
  f.ntf.Notify(f.u1, domain::NotificationType::kPromoted, "hello", "ev1");
  Need(f.db.ntfs().size() == 1 && f.ntf.UnreadCount(f.u1) == 0,
       "event dedup keeps read state");
  f.ntf.Notify(999, domain::NotificationType::kPromoted, "missing", "ev2");
  for (int i = 0; i < 5; ++i) f.bg.RetryFailedTasks(f.adm);
  Need(f.db.background_tasks().back().retry_count == 3 &&
           f.db.background_tasks().back().status == domain::TaskStatus::kFailed,
       "retry limit without fake success");
}

void History() {
  Fx f;
  auto x = f.New("A1", 2);
  f.Go(x);
  const auto a = f.Reg(f.u1, x);
  auto y = x;
  Need(f.act.CreateVersion(f.org, x.activity_id, &y.activity_version_id).ok,
       "new version");
  f.Go(y);
  const auto b = f.Reg(f.u2, y);
  auto status = f.stat.QueryStats(f.adm, x.activity_id);
  Need(status[0].regN == 2, "stats include historical registrations");
  Need(f.act.CancelActivity(f.org, x.activity_id).ok, "cancel all versions");
  Need(f.reg.Find(a)->status == RegistrationStatus::kCancelled &&
           f.reg.Find(b)->status == RegistrationStatus::kCancelled,
       "all versions cancelled");
  Need(f.tkt.FindByRegistration(a) == nullptr &&
           f.tkt.FindByRegistration(b) == nullptr,
       "all tickets void");
  status = f.stat.QueryStats(f.adm, x.activity_id);
  Need(status[0].cancelled == 2, "cancelled stats retained");
  Tmp tmp;
  const auto p = tmp.dir / "roster.csv";
  Need(f.stat.ExportRoster(f.org, x.activity_id, p.string(), &f.txt).ok,
       "export cancelled activity");
  std::ifstream in(p);
  std::string ln;
  int n = 0;
  while (std::getline(in, ln)) ++n;
  Need(n == 3, "export includes both snapshots");
}

void Cancelled() {
  for (int i = 0; i < 3; ++i) {
    Fx f;
    auto x = f.New();
    if (i > 0)
      Need(f.act.SubmitReview(f.org, x.activity_version_id).ok, "submit");
    if (i > 1)
      Need(f.act.Review(f.adm, x.activity_version_id, true, "").ok, "approve");
    Need(f.act.CancelActivity(f.org, x.activity_id).ok, "cancel unpublished");
    Need(!f.act.EditDraft(f.org, x.activity_version_id, "new", "desc").ok,
         "no edit after cancellation");
    Need(!f.act.SubmitReview(f.org, x.activity_version_id).ok,
         "no submit after cancellation");
    Need(!f.act.Review(f.adm, x.activity_version_id, true, "").ok,
         "no review after cancellation");
    Need(!f.act.Publish(f.org, x.activity_version_id).ok, "no resurrection");
    Need(f.act.FindActivity(x.activity_id)->status ==
             domain::ActivityStatus::kCancelled,
         "cancelled remains terminal");
  }
}

void Conflicts() {
  Fx f;
  auto x = f.New();
  const auto s = *f.ss.FindSession(x.sid, x.activity_version_id);
  Id sid = 0, cid = 0;
  Need(f.ss.CreateSession(f.org, x.activity_version_id, s.location,
                          s.start_time, s.end_time, s.registration_start,
                          s.registration_end, 1, &sid)
           .ok,
       "second session");
  Need(f.ss.CreateCategory(f.org, x.activity_version_id, sid, "ticket", 1, &cid)
           .ok,
       "second category");
  Need(!f.act.SubmitReview(f.org, x.activity_version_id).ok,
       "own overlapping sessions rejected");
  Need(f.ss.CancelSession(f.org, sid).ok, "cancel bad draft session");
  f.Go(x);
  auto y = f.New("A1");
  Need(!f.act.SubmitReview(f.org, y.activity_version_id).ok,
       "other activity conflict");
  Need(f.ss.CancelSession(f.org, x.sid).ok, "cancel published session");
  f.Go(y);
  auto z = y;
  Need(f.act.CreateVersion(f.org, y.activity_id, &z.activity_version_id).ok,
       "new version for recheck");
  Need(f.ss.UpdateSession(f.org, z.activity_version_id, z.sid, "A2",
                          s.start_time, s.end_time, s.registration_start,
                          s.registration_end, 1)
           .ok,
       "move new version");
  Need(f.act.SubmitReview(f.org, z.activity_version_id).ok &&
           f.act.Review(f.adm, z.activity_version_id, true, "").ok,
       "approve new version");
  auto other = f.New("A2");
  f.Go(other);
  Need(!f.act.Publish(f.org, z.activity_version_id).ok,
       "publish rechecks new conflict");
  Need(f.act.FindVersion(z.activity_version_id)->status ==
               VersionStatus::kApprovedPendingPublish &&
           f.act.CurrentVersion(y.activity_id)->id == y.activity_version_id,
       "failed publish preserves both states");
}

void Versions() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto registration_id = f.Reg(f.u1, x);
  const auto old = *f.ss.FindSession(x.sid, x.activity_version_id);
  auto y = x;
  Need(f.act.CreateVersion(f.org, x.activity_id, &y.activity_version_id).ok,
       "clone version");
  Id id = 0;
  Need(!f.act.CreateVersion(f.org, x.activity_id, &id).ok, "one working draft");
  Need(f.act.EditDraft(f.org, y.activity_version_id, "v2", "new desc").ok,
       "edit version title");
  Need(f.act.FindActivity(x.activity_id)->title == "A1",
       "draft title does not leak");
  Need(f.ss.UpdateSession(f.org, y.activity_version_id, y.sid, "A2",
                          old.start_time, old.end_time, old.registration_start,
                          old.registration_end, 2)
           .ok,
       "edit cloned session");
  auto* c = f.ss.FindCategory(y.cid, y.activity_version_id);
  Need(c != nullptr && f.ss.UpdateCategory(f.org, c->id, "v2 ticket", 2).ok,
       "edit cloned category");
  Need(f.act.SubmitReview(f.org, y.activity_version_id).ok, "submit v2");
  Need(f.act.Review(f.adm, y.activity_version_id, false, "change description")
           .ok,
       "reject v2");
  Need(f.act.EditDraft(f.org, y.activity_version_id, "v2", "fixed").ok,
       "repair rejected version");
  f.Go(y);
  Need(f.act.FindVersion(x.activity_version_id)->status ==
               VersionStatus::kHistory &&
           f.act.CurrentVersion(x.activity_id)->id == y.activity_version_id &&
           f.act.FindActivity(x.activity_id)->title == "v2",
       "version switch");
  Need(f.ss.FindSession(x.sid, x.activity_version_id)->location == "A1" &&
           f.ss.FindCategory(x.cid, x.activity_version_id)->name == "ticket" &&
           f.reg.Find(registration_id)->activity_version_id ==
               y.activity_version_id,
       "history unchanged and active registration migrated");
  const auto nr = f.Reg(f.u2, y);
  Need(f.reg.Find(nr)->activity_version_id == y.activity_version_id,
       "new registration uses v2");
  Tmp tmp;
  const auto p = tmp.dir / "snap.csv";
  Need(f.stat.ExportRoster(f.org, x.activity_id, p.string(), &f.txt).ok,
       "export snapshots");
  std::ifstream in(p);
  std::string txt((std::istreambuf_iterator<char>(in)),
                  std::istreambuf_iterator<char>());
  Need(txt.find("A1") == std::string::npos &&
           txt.find("A2") != std::string::npos &&
           txt.find("v2 ticket") != std::string::npos,
       "export uses migrated active registration fields");
}

void Categories() {
  Fx f;
  auto x = f.New("A1", 1);
  const auto s = *f.ss.FindSession(x.sid, x.activity_version_id);
  auto y = x;
  Need(f.ss.CreateSession(f.org, x.activity_version_id, "A2", s.start_time,
                          s.end_time, s.registration_start, s.registration_end,
                          2, &y.sid)
           .ok,
       "second independent session");
  Need(f.ss.CreateCategory(f.org, x.activity_version_id, y.sid, "ticket", 2,
                           &y.cid)
           .ok,
       "independent quota");
  f.Go(x);
  Need(!f.reg.Register(f.u1, x.sid, y.cid, "", &f.txt).ok,
       "cross-session category refused");
  const auto a = f.Reg(f.u1, x), b = f.Reg(f.u2, x);
  const auto c = f.Reg(f.u1, y), d = f.Reg(f.u2, y);
  Need(f.reg.Find(a)->status == RegistrationStatus::kRegistered &&
           f.reg.Find(b)->status == RegistrationStatus::kWaitlisted &&
           f.reg.Find(c)->status == RegistrationStatus::kRegistered &&
           f.reg.Find(d)->status == RegistrationStatus::kRegistered,
       "quotas counted per session");
  f.ss.CancelCategory(f.org, x.cid);
  Need(f.reg.Find(c)->status == RegistrationStatus::kRegistered,
       "category cancel isolated");
}

class SlowBuf : public std::stringbuf {
 public:
  SlowBuf() : std::stringbuf("") {}

 protected:
  int_type underflow() override {
    if (!once_) {
      once_ = true;
      std::this_thread::sleep_for(std::chrono::milliseconds(3200));
      str("0\n");
    }
    return std::stringbuf::underflow();
  }

 private:
  bool once_ = false;
};

void Scheduler() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto id = f.Reg(f.u1, x);
  f.ss.FindSession(x.sid, x.activity_version_id)->end_time = domain::Now() + 1;
  SlowBuf buf;
  auto* old = std::cin.rdbuf(&buf);
  int n = 0;
  ui::io::SetTick([&] {
    ++n;
    f.bg.RunDue();
  });
  const auto ln = ui::io::ReadLine("");
  ui::io::SetTick({});
  std::cin.rdbuf(old);
  Need(ln == "0" && n >= 4, "scheduler ticks while input is idle");
  Need(f.reg.Find(id)->status == RegistrationStatus::kAbsent &&
           f.act.FindActivity(x.activity_id)->status ==
               domain::ActivityStatus::kEnded,
       "automatic absence and ending");
}

void Access() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  f.rls.Close(f.u1);
  Need(!f.reg.Register(f.u1, x.sid, x.cid, "", &f.txt).ok,
       "logged-out registration refused");
  Id id = 0;
  Need(f.auth.Login(f.auth.FindUser(f.u1)->account, "abcdef", &id).ok,
       "login again");
  f.auth.FindUser(f.u1)->must_change_password = true;
  Need(!f.reg.Register(f.u1, x.sid, x.cid, "", &f.txt).ok,
       "forced password gate");
  Need(f.auth.ChangePassword(f.u1, "abcdef", "abcdef2").ok, "change password");
  f.Reg(f.u1, x);
  f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kDisabled);
  Need(!f.reg.Cancel(f.u1, f.db.regs().back().id, &f.txt).ok,
       "disabled account cannot cancel");
  f.rls.Close(f.org);
  Id activity_version_id = 0;
  Need(!f.act.CreateVersion(f.org, x.activity_id, &activity_version_id).ok,
       "logged-out organizer refused");
  Need(f.stat.QueryStats(f.org, x.activity_id).empty(),
       "logged-out stats refused");
  f.auth.SetStatus(f.adm, f.insp, domain::UserStatus::kDisabled);
  Need(!f.tkt.CheckIn(f.insp, f.db.tkts().back().code).ok,
       "disabled inspector refused");
  f.rls.Close(f.adm);
  Need(!f.auth
            .CreateAccount(f.adm, "no", "no", "123456",
                           domain::Role::kOrganizer, &id)
            .ok,
       "logged-out admin refused");
  Fx g;
  auto y = g.New();
  g.rls.AssignRole(g.adm, g.org, domain::Role::kOrdinaryParticipant);
  Need(g.rls.RemoveRole(g.adm, g.org, domain::Role::kOrganizer).ok,
       "remove organizer role");
  Need(!g.act.EditDraft(g.org, y.activity_version_id, "bad", "bad").ok &&
           !g.ss.UpdateCategoryQuota(
                    g.org, g.ss.FindCategory(y.cid, y.activity_version_id)->id,
                    2)
                .ok,
       "ownership alone cannot bypass revoked role");
  infra::DataStore db;
  service::AuditService aud(&db);
  service::RoleService rls(&db, &aud);
  service::TicketService tkt(&db, &rls, &aud);
  app::AppContext ctx;
  ctx.db = &db;
  ctx.tkts = &tkt;
  app::SeedDemoData(&ctx);
  for (const auto& u : db.usrs())
    Need(u.must_change_password, "all demo accounts require password change");
  for (auto& u : db.usrs()) u.must_change_password = false;
  Tmp tmp;
  Need(db.Save(tmp.dir.string()), "save legacy passwords");
  Need(db.Load(tmp.dir.string()), "load legacy passwords");
  for (const auto& u : db.usrs())
    Need(u.must_change_password, "legacy initial passwords require change");
}

void Migration() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  f.Reg(f.u1, x);
  Tmp tmp;
  Need(f.db.Save(tmp.dir.string()), "save fixture");
  const auto s = *f.ss.FindSession(x.sid, x.activity_version_id);
  {
    std::ofstream out(tmp.dir / "category_versions.csv");
    out << "1," << x.cid << ',' << x.activity_version_id << ",ticket,1\n";
  }
  {
    std::ofstream out(tmp.dir / "sessions.csv", std::ios::app);
    out << "2,2," << x.activity_version_id << ",A2," << s.start_time << ','
        << s.end_time << ',' << s.registration_start << ','
        << s.registration_end << ",1\n";
    std::ofstream ls(tmp.dir / "logical_sessions.csv", std::ios::app);
    ls << "2,0\n";
    std::ofstream rs(tmp.dir / "registrations.csv", std::ios::app);
    rs << "2," << f.u2 << ",2," << x.cid << ',' << x.activity_version_id
       << ",1,0,1,0\n";
    std::ofstream ts(tmp.dir / "tickets.csv", std::ios::app);
    ts << "2,2,4bb0f876-6ba4-4ea8-a965-87dc7be328ef,0,0\n";
  }
  infra::DataStore db;
  Need(db.Load(tmp.dir.string()), "load migration fixture");
  Need(db.category_versions().size() == 2,
       "legacy categories expanded per session");
  Need(db.category_versions()[0].logical_category_id !=
               db.category_versions()[1].logical_category_id &&
           db.regs()[1].logical_category_id ==
               db.category_versions()[1].logical_category_id,
       "legacy registration remapped");
  Need(db.Save(tmp.dir.string()), "save migrated schema");
  Need(db.Load(tmp.dir.string()), "reload migrated data");
  Need(db.category_versions().size() == 2 && db.regs().size() == 2,
       "migration is repeatable without duplicates");
  const auto p = tmp.dir / "file";
  std::ofstream(p) << "x";
  Need(!db.Save(p.string()), "save failure reported");
}

bool IsUuid4(const std::string& s) {
  if (s.size() != 36 || s[8] != '-' || s[13] != '-' || s[18] != '-' ||
      s[23] != '-' || s[14] != '4' ||
      (s[19] != '8' && s[19] != '9' && s[19] != 'a' && s[19] != 'b'))
    return false;
  for (std::size_t i = 0; i < s.size(); ++i) {
    if (i == 8 || i == 13 || i == 18 || i == 23) continue;
    if (!std::isxdigit(static_cast<unsigned char>(s[i]))) return false;
  }
  return true;
}

void Compliance() {
  Fx f;
  auto x = f.New("A20", 1);
  const auto ts = domain::Now();
  Id sid = 0;
  Need(!f.ss.CreateSession(f.org, x.activity_version_id, "体育馆", ts + 3600,
                           ts + 7200, ts - 100, ts + 1800, 1, &sid)
            .ok,
       "venue outside A1-A20 refused");
  Need(!f.ss.CreateSession(f.org, x.activity_version_id, "A21", ts + 3600,
                           ts + 7200, ts - 100, ts + 1800, 1, &sid)
            .ok,
       "venue A21 refused");
  f.Go(x);
  const auto registration_id = f.Reg(f.u1, x);
  auto* t = f.tkt.FindByRegistration(registration_id);
  Need(t != nullptr && IsUuid4(t->code), "ticket is UUID v4");
  Need(f.act.Published(f.u1, "A20").size() == 1 &&
           f.act.Published(f.u1, "ticket").size() == 1 &&
           f.act.Published(f.u1, "missing").empty(),
       "browse filter covers venue and category");
  f.ntf.Notify(f.org, domain::NotificationType::kPromoted, "org notice",
               "org-1");
  Need(f.ntf.UnreadCount(f.org) == 1,
       "organizer can receive and view notification");
  Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok, "grant inspector");
  Need(f.rls.RevokeSession(f.adm, f.insp, x.sid).ok &&
           !f.rls.HasValidGrant(f.insp, x.sid),
       "revoke inspector grant");
  f.rls.AssignRole(f.adm, f.insp, domain::Role::kOrdinaryParticipant);
  Need(f.rls.RemoveRole(f.adm, f.insp, domain::Role::kInspector).ok,
       "administrator can remove role");
  f.rls.AssignRole(f.adm, f.adm, domain::Role::kOrdinaryParticipant);
  Need(!f.rls.RemoveRole(f.adm, f.adm, domain::Role::kAdministrator).ok,
       "last active administrator protected");
  const auto before = f.db.audit_logs().size();
  Need(f.stat.QueryStats(f.u2, x.activity_id).empty(),
       "unauthorized stats refused");
  Need(f.db.audit_logs().size() > before &&
           f.db.audit_logs().back().res == domain::AuditResult::kFailure,
       "stats failure audited");
  Tmp tmp;
  Need(f.stat.ExportRoster(f.adm, x.activity_id, (tmp.dir / "r.csv").string(),
                           &f.txt)
               .ok &&
           f.db.audit_logs().back().actn == "导出名单",
       "export success audited");
  Need(!f.ntf.MarkRead(f.u2, 999999) &&
           f.db.audit_logs().back().res == domain::AuditResult::kFailure,
       "notification failure audited");

  Fx g;
  auto y = g.New("A1", 1);
  g.Go(y);
  std::atomic<int> ready{0};
  std::atomic<bool> go{false};
  service::ServiceResult r1, r2;
  std::string d1, d2;
  auto run = [&](Id user_id, service::ServiceResult* r, std::string* d) {
    ++ready;
    while (!go.load()) std::this_thread::yield();
    *r = g.reg.Register(user_id, y.sid, y.cid, "", d);
  };
  std::thread a(run, g.u1, &r1, &d1);
  std::thread b(run, g.u2, &r2, &d2);
  while (ready.load() != 2) std::this_thread::yield();
  go = true;
  a.join();
  b.join();
  Need(r1.ok && r2.ok, "concurrent requests completed");
  int regN = 0;
  int wlN = 0;
  int tktN = 0;
  for (const auto& r : g.db.regs()) {
    if (r.logical_session_id != y.sid) continue;
    if (r.status == RegistrationStatus::kRegistered) ++regN;
    if (r.status == RegistrationStatus::kWaitlisted) ++wlN;
  }
  for (const auto& q : g.db.tkts())
    if (q.status == domain::TicketStatus::kValid) ++tktN;
  Need(regN == 1 && wlN == 1 && tktN == 1,
       "registration lock prevents overbooking and duplicate ticket issue");
}
}

void RevisionBusiness() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto r1 = f.Reg(f.u1, x), r2 = f.Reg(f.u2, x);
  auto y = x;
  Need(f.act.CreateVersion(f.org, x.activity_id, &y.activity_version_id).ok,
       "clone");
  Need(f.act
           .EditDraft(f.org, y.activity_version_id, "new title",
                      "new description")
           .ok,
       "edit");
  Need(f.act.DescribeVersion(y.activity_version_id).find("new title") !=
           std::string::npos,
       "review version title");
  auto s = *f.ss.FindSession(y.sid, y.activity_version_id);
  Need(f.ss.UpdateSession(f.org, y.activity_version_id, y.sid, "A2",
                          s.start_time, s.end_time, s.registration_start,
                          s.registration_end, 2)
           .ok,
       "expand session");
  Need(f.ss.UpdateCategoryQuota(
               f.org, f.ss.FindCategory(y.cid, y.activity_version_id)->id, 2)
           .ok,
       "expand category");
  Need(f.act.SubmitReview(f.org, y.activity_version_id).ok &&
           f.act.Review(f.adm, y.activity_version_id, true, "").ok,
       "approve");
  Need(f.act.Withdraw(f.org, y.activity_version_id).ok &&
           !f.act.Publish(f.org, y.activity_version_id).ok,
       "withdraw requires reapproval");
  f.Go(y);
  Need(f.reg.Find(r1)->activity_version_id == y.activity_version_id &&
           f.reg.Find(r2)->activity_version_id == y.activity_version_id &&
           f.reg.Find(r2)->status == RegistrationStatus::kRegistered,
       "migration and immediate promotion");
  Need(f.tkt.Describe(r1).find("A2") != std::string::npos,
       "ticket follows new location");
  bool notice = false;
  for (const auto& n : f.ntf.History(f.u1))
    if (n.typ == domain::NotificationType::kVersionChanged) notice = true;
  Need(notice, "migration notice");
  const auto snap = f.stat.QueryStats(f.org, x.activity_id);
  Need(snap[0].regN == 2, "snapshot count");
  Need(f.reg.Cancel(f.u1, r1, &f.txt).ok, "cancel after snapshot");
  Tmp tmp;
  const auto out = tmp.dir / "snap.csv";
  Need(f.stat.ExportRoster(f.org, x.activity_id, out.string(), &f.txt).ok,
       "snapshot export");
  std::ifstream in(out);
  const std::string txt((std::istreambuf_iterator<char>(in)), {});
  Need(txt.find("已取消") == std::string::npos,
       "same snapshot despite later cancel");
  Need(!f.stat.ExportRoster(f.org, x.activity_id, out.string(), &f.txt).ok,
       "no overwrite");
  Need(!f.stat
            .ExportRoster(f.org, x.activity_id,
                          (tmp.dir / "users.csv").string(), &f.txt)
            .ok,
       "reserved data path");
  Need(f.ss.CancelSession(f.org, x.sid).ok, "cancel session");
  Need(f.ss.CancelSession(f.org, x.sid).msg == "已取消，请勿重复取消",
       "duplicate cancel");
  Fx g;
  auto z = g.New();
  g.ss.FindSession(z.sid, z.activity_version_id)->end_time = domain::Now() - 1;
  Need(!g.ss.CancelSession(g.org, z.sid).ok &&
           !g.ss.CancelCategory(g.org, z.cid).ok,
       "ended cancellation refused");
}

void RevisionStorage() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  f.Reg(f.u1, x);
  Tmp tmp;
  const auto dir = tmp.dir / "db";
  Need(f.db.Save(dir.string()), "atomic initial save");
  const auto n = f.db.usrs().size();
  {
    infra::Transaction tx(&f.db);
    f.db.usrs().clear();
  }
  Need(f.db.usrs().size() == n, "transaction rollback");
  {
    std::ofstream bad(dir / "users.csv");
    bad << "broken\n";
  }
  Need(!f.db.Load(dir.string()) && f.db.usrs().size() == n,
       "bad load preserves memory");
  Need(f.db.Save(dir.string()), "replace corrupted disk from intact state");
  std::filesystem::rename(dir, dir.string() + ".campus-backup");
  infra::DataStore copy;
  Need(copy.Load(dir.string()) && copy.usrs().size() == n,
       "recover interrupted directory commit");
  f.ss.FindSession(x.sid, x.activity_version_id)->location = "legacy venue";
  Need(f.db.Save(dir.string()) && copy.Load(dir.string()), "legacy load");
  Need(copy.ssns()[0].location == "legacy venue", "no silent venue rewrite");
  {
    std::ofstream bad(dir / "registrations.csv", std::ios::app);
    bad << "999,999,1,1,1,1,0,1,0\n";
  }
  Need(!copy.Load(dir.string()), "orphan registration rejected");
}

void RevisionTransitions() {
  Fx f;
  auto x = f.New();
  const auto ts = domain::Now();
  Id sid = 0, cid = 0;
  Need(f.ss.CreateSession(f.org, x.activity_version_id, "A2", ts + 10000,
                          ts + 11000, ts - 1000, ts + 9000, 1, &sid)
           .ok,
       "second future session");
  Need(f.ss.CreateCategory(f.org, x.activity_version_id, sid, "ticket", 1, &cid)
           .ok,
       "second category");
  f.Go(x);
  auto* old = f.ss.FindSession(x.sid, x.activity_version_id);
  old->registration_start = ts - 4000;
  old->registration_end = ts - 3000;
  old->start_time = ts - 2000;
  old->end_time = ts - 1000;
  auto y = x;
  Need(f.act.CreateVersion(f.org, x.activity_id, &y.activity_version_id).ok,
       "clone with ended session");
  Need(f.ss.UpdateSession(f.org, y.activity_version_id, sid, "A3", ts + 10000,
                          ts + 11000, ts - 1000, ts + 9000, 1)
           .ok,
       "edit future session only");
  f.Go(y);
  Need(f.ss.FindSession(x.sid, y.activity_version_id)->end_time == ts - 1000,
       "ended session retained");
  Fx g;
  auto z = g.New();
  g.Go(z);
  std::atomic<int> ready{0};
  std::atomic<bool> go{false};
  service::ServiceResult cancel;
  std::thread a([&] {
    ++ready;
    while (!go) std::this_thread::yield();
    std::string det;
    g.reg.Register(g.u1, z.sid, z.cid, "", &det);
  });
  std::thread b([&] {
    ++ready;
    while (!go) std::this_thread::yield();
    cancel = g.ss.CancelSession(g.org, z.sid);
  });
  while (ready < 2) std::this_thread::yield();
  go = true;
  a.join();
  b.join();
  Need(cancel.ok, "concurrent cancellation succeeds");
  for (const auto& r : g.db.regs())
    Need(r.status == RegistrationStatus::kCancelled,
         "no active registration after cancellation");
  for (const auto& t : g.db.tkts())
    Need(t.status == domain::TicketStatus::kInvalid,
         "no valid ticket after cancellation");
}

void RevisionAccess() {
  Fx f;
  Need(f.auth.AllUsers(f.u1).empty() && f.aud.Recent(f.u1, 20).empty(),
       "privileged queries protected");
  Need(f.ntf.Notify(f.u1, domain::NotificationType::kPromoted, "one", "one"),
       "notify");
  const auto id = f.ntf.History(f.u1).front().id;
  Need(!f.ntf.MarkRead(f.u2, id) && f.ntf.MarkRead(f.u1, id),
       "single read ownership");
  Need(f.ntf.Unread(f.u1).empty() && f.ntf.History(f.u1).size() == 1,
       "read history retained");
  f.rls.Close(f.u1);
  Need(f.ntf.History(f.u1).empty() && !f.ntf.MarkRead(f.u1, id),
       "signed out notification rejected");
  Need(f.reg.RegistrationsOf(f.u1).empty(), "signed out registration query");
  f.auth.SetStatus(f.adm, f.u2, domain::UserStatus::kDisabled);
  f.ntf.Notify(f.u2, domain::NotificationType::kPromoted, "retry", "retry");
  for (int i = 0; i < 3; ++i) f.bg.RetryFailedTasks(f.adm);
  f.auth.SetStatus(f.adm, f.u2, domain::UserStatus::kActive);
  Need(f.bg.RetryFailedTasks(f.adm) == 0, "automatic retry ceiling");
  Need(
      f.bg.RetryFailedTasks(f.adm, true) == 1 &&
          f.db.background_tasks().back().status == domain::TaskStatus::kSuccess,
      "manual redelivery beyond ceiling");
}

void RevisionUi() {
  Fx f;
  auto x = f.New();
  f.act.EditDraft(f.org, x.activity_version_id, "REVIEW_TITLE",
                  "REVIEW_DESCRIPTION");
  f.act.SubmitReview(f.org, x.activity_version_id);
  const auto other = f.User(domain::Role::kOrganizer);
  Tmp tmp;
  app::AppContext ctx;
  ctx.ddir = (tmp.dir / "db").string();
  ctx.db = &f.db;
  ctx.aud = &f.aud;
  ctx.auth = &f.auth;
  ctx.rls = &f.rls;
  ctx.ntfs = &f.ntf;
  ctx.acts = &f.act;
  ctx.ssns = &f.ss;
  ctx.regs = &f.reg;
  ctx.tkts = &f.tkt;
  ctx.sts = &f.stat;
  ctx.bg = &f.bg;
  std::istringstream input(
      "u1\nabcdef\n1\n" + std::to_string(x.activity_version_id) +
      "\n2\nreason\n0\nu" + std::to_string(other) + "\nabcdef\n4\n" +
      std::to_string(x.activity_version_id) +
      "\n90\nabcdef\nnewpass\n91\n0\n0\n");
  std::ostringstream output;
  auto* oldIn = std::cin.rdbuf(input.rdbuf());
  auto* oldOut = std::cout.rdbuf(output.rdbuf());
  ui::io::SetTick({});
  ui::ConsoleView(&ctx).Run();
  std::cin.rdbuf(oldIn);
  std::cout.rdbuf(oldOut);
  const auto txt = output.str();
  Need(txt.find("REVIEW_TITLE") != std::string::npos &&
           txt.find("REVIEW_DESCRIPTION") != std::string::npos,
       "review UI displays actual version");
  Need(txt.find("版本不存在或无权访问") != std::string::npos,
       "UI blocks other organizer draft");
  Need(txt.find("密码修改成功") != std::string::npos &&
           txt.find("暂无通知") != std::string::npos,
       "password and notification menu paths");
}

void SingleTicket() {
  Fx f;
  auto x = f.New();
  Id cid = 0;
  Need(!f.ss.CreateCategory(f.org, x.activity_version_id, x.sid, "vip", 1, &cid)
            .ok,
       "second type in same session rejected");
  Need(!f.ss.CreateCategory(f.org, x.activity_version_id, x.sid, "ticket", 1,
                            &cid)
            .ok,
       "duplicate type in same session rejected");
  auto y = x;
  const auto s = *f.ss.FindSession(x.sid, x.activity_version_id);
  Need(f.ss.CreateSession(f.org, x.activity_version_id, "A2", s.start_time,
                          s.end_time, s.registration_start, s.registration_end,
                          1, &y.sid)
           .ok,
       "second session created");
  Need(!f.ss.CreateCategory(f.org, x.activity_version_id, y.sid, "vip", 1, &cid)
            .ok,
       "different type across sessions rejected");
  Need(f.ss.CreateCategory(f.org, x.activity_version_id, y.sid, "ticket", 1,
                           &y.cid)
           .ok,
       "same type with independent quota accepted");
  Need(f.ss.UpdateCategory(f.org,
                           f.ss.FindCategory(x.cid, x.activity_version_id)->id,
                           "entry", 1)
           .ok,
       "rename ticket");
  Need(f.ss.FindCategory(y.cid, x.activity_version_id)->name == "entry",
       "rename applies across version");
  f.ss.FindCategory(y.cid, x.activity_version_id)->name = "vip";
  Need(!f.act.SubmitReview(f.org, x.activity_version_id).ok,
       "review rejects legacy types");
  f.ss.FindCategory(y.cid, x.activity_version_id)->name = "entry";
  f.Go(x);
  const auto a = f.Reg(f.u1, x);
  Need(!f.reg.Register(f.u1, x.sid, 0, "", &f.txt).ok,
       "duplicate registration rejected without category selection");
  Need(f.reg.Register(f.u1, y.sid, 0, "", &f.txt).ok,
       "same participant may register another session");
  const auto b = f.Reg(f.u2, x);
  Need(f.reg.Find(b)->status == RegistrationStatus::kWaitlisted,
       "full session creates waitlist");
  Need(!f.reg.Register(f.u2, x.sid, x.cid, "", &f.txt).ok,
       "duplicate waitlist rejected");
  Need(f.reg.Register(f.u2, y.sid, 0, "", &f.txt).ok,
       "waitlist allowed independently in another session");
  Need(f.reg.Cancel(f.u1, a, &f.txt).ok &&
           f.reg.Find(b)->status == RegistrationStatus::kRegistered,
       "cancel promotes only same session");
  Need(f.reg.Register(f.u1, x.sid, 0, "", &f.txt).ok,
       "cancelled participant may register again");
  Need(f.reg.RemainingSeats(y.sid, 0) == 0, "automatic ticket quota lookup");
  Id activity_version_id = 0;
  Need(f.act.CreateVersion(f.org, x.activity_id, &activity_version_id).ok,
       "new draft");
  Need(f.ss.UpdateCategory(f.org,
                           f.ss.FindCategory(x.cid, activity_version_id)->id,
                           "new entry", 1)
           .ok,
       "rename draft");
  Need(f.ss.FindCategory(x.cid, x.activity_version_id)->name == "entry",
       "published ticket name unchanged until publish");
  Fx g;
  auto z = g.New();
  g.Go(z);
  std::atomic<int> n{0};
  auto run = [&] {
    std::string txt;
    if (g.reg.Register(g.u1, z.sid, 0, "", &txt).ok) ++n;
  };
  std::thread t1(run), t2(run);
  t1.join();
  t2.join();
  Need(n == 1 && g.db.regs().size() == 1,
       "concurrent same-session requests create only one record");
}

void CancellationRules() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto a = f.Reg(f.u1, x), b = f.Reg(f.u2, x);
  auto* s = f.ss.FindSession(x.sid, x.activity_version_id);
  s->start_time = domain::Now();
  Need(!f.reg.Cancel(f.u1, a, &f.txt).ok && !f.reg.Cancel(f.u2, b, &f.txt).ok,
       "start blocks registered and waitlisted cancellation");
  s->start_time = domain::Now() + 1800;
  Need(!f.act.CancelActivity(f.org, x.activity_id).ok,
       "checkin opening blocks activity cancellation without checkins");
  Need(f.reg.Cancel(f.u2, b, &f.txt).ok,
       "personal cancellation still allowed before start");
  Need(f.tkt.InCheckinWindow(*s, s->start_time - 1800) &&
           !f.tkt.InCheckinWindow(*s, s->start_time - 1801),
       "checkin opens exactly thirty minutes before start");
  const auto code = f.tkt.FindByRegistration(a)->code;
  Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok, "grant");
  Need(f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kDisabled).ok,
       "disable ticket owner");
  Need(f.tkt.FindByRegistration(a) == nullptr &&
           !f.tkt.CheckIn(f.insp, code).ok && !f.tkt.Issue(a, &f.txt).ok,
       "disabled account cannot display use or issue tickets");
  Tmp tmp;
  Need(f.db.Save(tmp.dir.string()) && f.db.Load(tmp.dir.string()),
       "disabled account survives restart");
  Need(f.tkt.FindByRegistration(a) == nullptr,
       "ticket remains unusable after reload");
  Need(f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kActive).ok,
       "reactivate owner");
  Need(f.tkt.FindByRegistration(a) != nullptr &&
           f.tkt.FindByRegistration(a)->code == code &&
           f.tkt.CheckIn(f.insp, code).ok,
       "same unexpired code restored and checks in");
  Need(!f.tkt.CheckIn(f.insp, code).ok, "checked ticket cannot be reused");
  f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kDisabled);
  f.ss.FindSession(x.sid, x.activity_version_id)->end_time = domain::Now() - 1;
  f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kActive);
  Need(
      f.tkt.FindByRegistration(a) == nullptr && !f.tkt.CheckIn(f.insp, code).ok,
      "expired ticket not restored");
  Fx g;
  auto y = g.New();
  g.Go(y);
  const auto r = g.Reg(g.u1, y);
  const auto old = g.tkt.FindByRegistration(r)->code;
  Need(g.reg.Cancel(g.u1, r, &g.txt).ok, "cancel before start");
  g.auth.SetStatus(g.adm, g.u1, domain::UserStatus::kDisabled);
  g.auth.SetStatus(g.adm, g.u1, domain::UserStatus::kActive);
  Need(g.tkt.FindByRegistration(r) == nullptr &&
           g.tkt.FindByCode(old)->status == domain::TicketStatus::kInvalid,
       "cancelled ticket never restored");
  Need(g.act.CancelActivity(g.org, y.activity_id).ok,
       "activity cancellation allowed before checkin opens");
}

void IdempotencyCoverage() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  std::string first, replay;
  Need(f.reg.Register(f.u1, x.sid, x.cid, "request-1", &first).ok,
       "initial idempotent registration");
  const auto records = f.db.regs().size(), tickets = f.db.tkts().size();
  Need(f.reg.Register(f.u1, x.sid, x.cid, "request-1", &replay).ok &&
           first == replay && f.db.regs().size() == records &&
           f.db.tkts().size() == tickets,
       "replay returns same result without duplicate effects");
  Need(!f.reg.Register(f.u2, x.sid, x.cid, "request-1", &replay).ok &&
           f.db.regs().size() == records,
       "same key with different user rejected");
  Need(!f.reg.Register(f.u1, x.sid + 999, x.cid, "request-1", &replay).ok,
       "same key with different session rejected");
  Tmp tmp;
  Need(f.db.Save(tmp.dir.string()), "save idempotency");
  Fx restored;
  Need(restored.db.Load(tmp.dir.string()), "reload idempotency");
  Need(restored.reg.Register(f.u1, x.sid, x.cid, "request-1", &replay).ok &&
           replay == first && restored.db.regs().size() == records &&
           restored.db.tkts().size() == tickets,
       "persisted request replay has no new side effects");
  Need(f.reg.Register(f.u2, x.sid, x.cid, "wait-1", &first).ok,
       "idempotent waitlist request");
  Need(f.reg.Register(f.u2, x.sid, x.cid, "wait-1", &replay).ok &&
           first == replay && f.db.regs().size() == records + 1,
       "waitlist replay does not create extra sequence");
}

void ReviewGuards() {
  Fx f;
  auto x = f.New();
  Need(!f.act.Publish(f.org, x.activity_version_id).ok &&
           !f.act.Review(f.adm, x.activity_version_id, true, "").ok &&
           f.act.FindVersion(x.activity_version_id)->status ==
               VersionStatus::kDraft,
       "draft cannot be published or reviewed");
  Need(f.act.SubmitReview(f.org, x.activity_version_id).ok,
       "submit for guard tests");
  Need(f.rls.AssignRole(f.adm, f.org, domain::Role::kAdministrator).ok,
       "creator also administrator");
  for (bool approve : {false, true}) {
    auto result = f.act.Review(f.org, x.activity_version_id, approve, "reason");
    Need(!result.ok && result.msg.find("回避") != std::string::npos &&
             f.act.FindVersion(x.activity_version_id)->status ==
                 VersionStatus::kPendingReview,
         "self review rejected without state change");
  }
  Need(!f.act.Review(f.adm, x.activity_version_id, false, "").ok &&
           f.act.FindVersion(x.activity_version_id)->status ==
               VersionStatus::kPendingReview,
       "empty rejection reason preserves pending state");
  Need(!f.act.EditDraft(f.org, x.activity_version_id, "changed", "changed").ok,
       "pending review is immutable");
  Need(f.act.Review(f.adm, x.activity_version_id, false, "fix details").ok &&
           f.act.FindVersion(x.activity_version_id)->rejection_reason ==
               "fix details",
       "rejection reason retained");
  Need(!f.act.Publish(f.org, x.activity_version_id).ok,
       "rejected version cannot publish");
  Need(f.act.EditDraft(f.org, x.activity_version_id, "fixed", "fixed").ok,
       "rejected version can be repaired");
  f.Go(x);
  Need(!f.act.Publish(f.org, x.activity_version_id).ok &&
           f.act.CurrentVersion(x.activity_id)->id == x.activity_version_id,
       "duplicate publish does not change current version");
}

void AuthenticationEdges() {
  Fx f;
  const auto account = f.auth.FindUser(f.u1)->account;
  const auto original = f.auth.FindUser(f.u1)->password_hash;
  for (const auto& pair :
       {std::make_pair("wrong", "newpass"), std::make_pair("abcdef", "short"),
        std::make_pair("abcdef", "abcdef")}) {
    Need(!f.auth.ChangePassword(f.u1, pair.first, pair.second).ok &&
             f.auth.FindUser(f.u1)->password_hash == original,
         "invalid password change preserves original hash");
  }
  Id id = 0;
  Need(!f.auth.Login("missing-account", "abcdef", &id).ok,
       "unknown account refused");
  for (int i = 0; i < 4; ++i)
    Need(!f.auth.Login(account, "bad", &id).ok, "wrong login counted");
  Need(f.auth.Login(account, "abcdef", &id).ok &&
           f.auth.FindUser(f.u1)->failed_login_count == 0,
       "successful login resets failures");
  for (int i = 0; i < 5; ++i)
    Need(!f.auth.Login(account, "bad", &id).ok, "trigger lock");
  Need(!f.auth.Login(account, "abcdef", &id).ok, "correct password locked");
  f.auth.FindUser(f.u1)->locked_until = domain::Now() - 1;
  Need(f.auth.Login(account, "abcdef", &id).ok &&
           f.auth.FindUser(f.u1)->locked_until == 0,
       "expired lock permits login");
  Need(f.auth.ChangePassword(f.u1, "abcdef", "newpass").ok &&
           !f.auth.Login(account, "abcdef", &id).ok &&
           f.auth.Login(account, "newpass", &id).ok,
       "new password replaces old password");
}

void TicketBoundaries() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto registration_id = f.Reg(f.u1, x);
  const auto code = f.tkt.FindByRegistration(registration_id)->code;
  auto* s = f.ss.FindSession(x.sid, x.activity_version_id);
  const auto original = *s;
  Need(!f.tkt.InCheckinWindow(original, original.start_time - 1801) &&
           f.tkt.InCheckinWindow(original, original.start_time - 1800) &&
           f.tkt.InCheckinWindow(original, original.end_time) &&
           !f.tkt.InCheckinWindow(original, original.end_time + 1),
       "both checkin window boundaries");
  s->start_time = domain::Now() - 10;
  Need(!f.tkt.CheckIn(f.insp, code).ok && f.db.checkin_events().empty(),
       "logged in inspector without grant cannot check in");
  Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok, "authorize inspector");
  Need(!f.tkt.CheckIn(f.u1, code).ok &&
           !f.tkt.CheckIn(f.insp, "not-a-ticket").ok &&
           f.db.checkin_events().empty(),
       "wrong role and unknown code have no checkin effects");
  Need(
      f.tkt.CheckIn(f.insp, code).ok && f.db.checkin_events().size() == 1 &&
          f.reg.Find(registration_id)->status == RegistrationStatus::kCheckedIn,
      "authorized checkin records exactly one event");
  Need(!f.tkt.CheckIn(f.insp, code).ok && f.db.checkin_events().size() == 1,
       "duplicate code cannot create another event");
}

void RegistrationEdges() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  auto* s = f.ss.FindSession(x.sid, x.activity_version_id);
  s->registration_start = domain::Now() + 3600;
  Need(!f.reg.Register(f.u1, x.sid, x.cid, "", &f.txt).ok &&
           f.db.regs().empty() && f.db.tkts().empty(),
       "registration before opening has no effects");
  s->registration_start = domain::Now() - 3600;
  const auto registration_id = f.Reg(f.u1, x);
  const auto ticket = f.tkt.FindByRegistration(registration_id)->code;
  Need(!f.reg.Cancel(f.u2, registration_id, &f.txt).ok &&
           f.reg.Find(registration_id)->status ==
               RegistrationStatus::kRegistered &&
           f.tkt.FindByCode(ticket)->status == domain::TicketStatus::kValid,
       "another participant cannot cancel registration");
  s->registration_end = domain::Now();
  Need(!f.reg.Register(f.u2, x.sid, x.cid, "", &f.txt).ok &&
           f.db.regs().size() == 1,
       "deadline closes new requests");
  Need(f.reg.Cancel(f.u1, registration_id, &f.txt).ok &&
           f.tkt.FindByCode(ticket)->status == domain::TicketStatus::kInvalid,
       "cancellation without waitlist still invalidates ticket");
}

void CsvRoundTrip() {
  const std::vector<std::string> fields = {"", "中文", "a,b", "a\"b", "last"};
  Need(infra::SplitCsv(infra::JoinCsv(fields)) == fields,
       "CSV quoting and Unicode round trip");
  Fx f;
  auto x = f.New();
  const std::string title = "讲座, \"专题\"";
  Need(f.act.EditDraft(f.org, x.activity_version_id, title, "中文简介").ok,
       "special title");
  f.Go(x);
  const auto registration_id = f.Reg(f.u1, x);
  const auto code = f.tkt.FindByRegistration(registration_id)->code;
  Tmp tmp;
  Need(f.db.Save(tmp.dir.string()), "save special fields");
  Fx restored;
  Need(restored.db.Load(tmp.dir.string()), "load special fields");
  Need(restored.act.FindVersion(x.activity_version_id)->title == title &&
           restored.act.FindVersion(x.activity_version_id)->description ==
               "中文简介" &&
           restored.reg.Find(registration_id)->user_id == f.u1 &&
           restored.reg.Find(registration_id)->activity_version_id ==
               x.activity_version_id &&
           restored.tkt.FindByRegistration(registration_id)->code == code,
       "persisted values and relationships preserved");
  Need(f.stat.QueryStats(f.org, x.activity_id).front().regN == 1,
       "roster snapshot");
  const auto path = tmp.dir / "roster.csv";
  Need(f.stat.ExportRoster(f.org, x.activity_id, path.string(), &f.txt).ok,
       "export roster for field inspection");
  std::ifstream in(path);
  std::string header, row, extra;
  Need(static_cast<bool>(std::getline(in, header)) &&
           static_cast<bool>(std::getline(in, row)) && !std::getline(in, extra),
       "exactly one roster row");
  const auto values = infra::SplitCsv(row);
  Need(values.size() == 8 && values[0] == std::to_string(f.u1) &&
           values[2] == f.auth.FindUser(f.u1)->account &&
           values[4] == "ticket" && values[5] == "已报名" &&
           values[6] == "有效",
       "roster contains correct identity category and safe ticket status");
}

void ConcurrentIdempotency() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  std::atomic<int> ready{0};
  std::atomic<bool> go{false};
  service::ServiceResult results[2];
  std::string output[2];
  auto request = [&](int i) {
    ++ready;
    while (!go.load()) std::this_thread::yield();
    results[i] = f.reg.Register(f.u1, x.sid, x.cid, "shared", &output[i]);
  };
  std::thread a(request, 0), b(request, 1);
  while (ready.load() < 2) std::this_thread::yield();
  go = true;
  a.join();
  b.join();
  Need(results[0].ok && results[1].ok && output[0] == output[1] &&
           f.db.regs().size() == 1 && f.db.tkts().size() == 1 &&
           f.db.idempotency_records().size() == 1,
       "concurrent replay creates exactly one registration ticket and key");
}

void PromotionPrivacy() {
  Fx f;
  auto x = f.New();
  f.Go(x);
  const auto first = f.Reg(f.u1, x), waiting = f.Reg(f.u2, x);
  std::string details;
  const auto result = f.reg.Cancel(f.u1, first, &details);
  const auto* ticket = f.tkt.FindByRegistration(waiting);
  Need(result.ok && ticket != nullptr, "cancel promotes and issues ticket");
  Need(details.find(ticket->code) == std::string::npos &&
           result.msg.find(ticket->code) == std::string::npos,
       "cancelling participant never receives promoted participant code");
  bool delivered = false;
  for (const auto& notification : f.ntf.History(f.u2))
    if (notification.typ == domain::NotificationType::kPromoted &&
        notification.cnt.find(ticket->code) != std::string::npos)
      delivered = true;
  Need(delivered &&
           f.tkt.Describe(waiting).find(ticket->code) != std::string::npos,
       "promoted owner still receives and can view ticket");
  for (const auto& notification : f.ntf.History(f.u1))
    Need(notification.cnt.find(ticket->code) == std::string::npos,
         "other user's notification does not leak ticket");
}

void StrictDates() {
  for (const auto* input :
       {"2026-02-30 12:00", "2026-02-29 12:00", "2026-04-31 12:00",
        "2026-13-01 12:00", "2026-00-01 12:00", "2026-01-00 12:00",
        "2026-11-25 24:00", "2026-11-25 12:60", "2026-11-25 12:00junk",
        "2026-1-25 12:00", "2026/11/25 12:00", "2026-11-25 12:00 ", ""}) {
    domain::Timestamp value = 123;
    Need(!domain::ParseTime(input, &value) && value == 123,
         std::string("invalid date refused without changing output: ") + input);
  }
  for (const auto* input :
       {"2024-02-29 12:00", "2026-01-01 00:00", "2026-12-31 23:59"}) {
    domain::Timestamp value = 0;
    Need(domain::ParseTime(input, &value) && domain::FormatTime(value) == input,
         std::string("valid date round trip: ") + input);
  }
  Need(!domain::ParseTime("2026-11-25 12:00", nullptr), "null output refused");
}

class ConsoleCapture {
 public:
  explicit ConsoleCapture(const std::string& text) : input_(text) {
    old_input_ = std::cin.rdbuf(input_.rdbuf());
    old_output_ = std::cout.rdbuf(output_.rdbuf());
    ui::io::SetTick({});
  }
  ~ConsoleCapture() {
    std::cin.rdbuf(old_input_);
    std::cout.rdbuf(old_output_);
  }

 private:
  std::istringstream input_;
  std::ostringstream output_;
  std::streambuf* old_input_;
  std::streambuf* old_output_;
};

void StrictConsoleInput() {
  {
    ConsoleCapture capture(
        "1abc\n999999999999999999999999\n 2 \n3.5\n4xyz\n 7 \n");
    Need(ui::io::ReadInt("") == 2, "integer rejects junk and overflow");
    Need(ui::io::ReadId("") == 7, "ID rejects fractions and suffixes");
  }
  for (const auto initial :
       {domain::UserStatus::kActive, domain::UserStatus::kDisabled}) {
    for (const int choice : {0, 3, -1, 1, 2}) {
      Fx f;
      Tmp tmp;
      Need(f.auth.SetStatus(f.adm, f.u1, initial).ok, "set initial status");
      const auto audit_count = f.db.audit_logs().size();
      app::AppContext ctx;
      ctx.db = &f.db;
      ctx.auth = &f.auth;
      ctx.rls = &f.rls;
      ctx.aud = &f.aud;
      ctx.ddir = (tmp.dir / "db").string();
      {
        ConsoleCapture capture("u1\nabcdef\n5\n" + std::to_string(f.u1) + "\n" +
                               std::to_string(choice) + "\n0\n0\n");
        ui::ConsoleView(&ctx).Run();
      }
      const bool valid = choice == 1 || choice == 2;
      const auto expected = valid
                                ? (choice == 1 ? domain::UserStatus::kActive
                                               : domain::UserStatus::kDisabled)
                                : initial;
      Need(f.auth.FindUser(f.u1)->status == expected,
           "only explicit valid menu choices change account status");
      if (!valid)
        for (std::size_t i = audit_count; i < f.db.audit_logs().size(); ++i)
          Need(f.db.audit_logs()[i].actn != "修改账号状态",
               "invalid option never calls status mutation service");
    }
  }
}

void CheckedInCancellationGuards() {
  Fx f;
  const auto x = f.New("A1", 2);
  f.Go(x);
  const auto checked = f.Reg(f.u1, x);
  const auto registered = f.Reg(f.u2, x);
  const auto waiting = f.Reg(f.u3, x);
  const auto code = f.tkt.FindByRegistration(checked)->code;
  const auto other_code = f.tkt.FindByRegistration(registered)->code;
  f.ss.FindSession(x.sid, x.activity_version_id)->start_time =
      domain::Now() + 600;
  f.ss.FindSession(x.sid, x.activity_version_id)->registration_end =
      domain::Now() + 300;
  Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
           f.tkt.CheckIn(f.insp, code).ok,
       "check in before session starts");
  const auto notification_count = f.db.ntfs().size();
  auto verify = [&] {
    Need(!f.reg.Cancel(f.u1, checked, &f.txt).ok,
         "checked-in participant cannot cancel before session starts");
    Need(!f.act.CancelActivity(f.org, x.activity_id).ok,
         "activity with check-in cannot be cancelled");
    const auto session_result = f.ss.CancelSession(f.org, x.sid);
    const auto category_result = f.ss.CancelCategory(f.org, x.cid);
    Need(!session_result.ok &&
             session_result.msg.find("签到") != std::string::npos &&
             !category_result.ok &&
             category_result.msg.find("签到") != std::string::npos,
         "session and category reject because of check-in");
    Need(!f.ss.FindLogicalSession(x.sid)->cancelled &&
             !f.ss.FindLogicalCategory(x.cid)->cancelled,
         "rejected cancellation preserves logical entities");
    Need(
        f.reg.Find(checked)->status == RegistrationStatus::kCheckedIn &&
            f.reg.Find(registered)->status == RegistrationStatus::kRegistered &&
            f.reg.Find(waiting)->status == RegistrationStatus::kWaitlisted &&
            f.tkt.FindByRegistration(registered)->code == other_code &&
            f.db.checkin_events().size() == 1 &&
            f.db.ntfs().size() == notification_count,
        "rejection preserves registrations tickets check-in and notifications");
    Need(f.db.audit_logs().back().res == domain::AuditResult::kFailure,
         "rejected cancellation is audited");
  };
  verify();
  Tmp tmp;
  Need(f.db.Save(tmp.dir.string()) && f.db.Load(tmp.dir.string()),
       "save and reload checked-in state");
  verify();

  const auto y = f.New("A2");
  f.Go(y);
  const auto cancelled = f.Reg(f.u1, y);
  Need(f.ss.CancelSession(f.org, y.sid).ok &&
           f.reg.Find(cancelled)->status == RegistrationStatus::kCancelled &&
           f.tkt.FindByRegistration(cancelled) == nullptr,
       "unrelated session without check-in can still cancel and void ticket");
  const auto z = f.New("A3");
  f.Go(z);
  const auto category_registration = f.Reg(f.u1, z);
  Need(f.ss.CancelCategory(f.org, z.cid).ok &&
           f.reg.Find(category_registration)->status ==
               RegistrationStatus::kCancelled,
       "unrelated category without check-in can still cancel");
}

void PublishedStateVersionGuards() {
  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    Id draft_version_id = 0;
    Need(f.act.CreateVersion(f.org, x.activity_id, &draft_version_id).ok,
         "create draft before check-in");
    const auto now = domain::Now();
    Need(f.ss.UpdateSession(f.org, draft_version_id, x.sid, "A2", now + 86400,
                            now + 90000, now - 3600, now + 85000, 1)
             .ok,
         "prepare changed draft before check-in");
    auto* current = f.ss.FindSession(x.sid, x.activity_version_id);
    current->start_time = now + 600;
    current->registration_end = now + 300;
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
             f.tkt.CheckIn(f.insp, code).ok,
         "check in on current published session");
    Need(!f.ss.UpdateSession(f.org, draft_version_id, x.sid, "A3", now + 90000,
                             now + 93600, now - 3600, now + 89000, 1)
              .ok,
         "check-in freezes later session edits");
    Need(!f.act.SubmitReview(f.org, draft_version_id).ok,
         "publish validation rejects draft prepared before check-in");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    const auto now = domain::Now();
    auto* current = f.ss.FindSession(x.sid, x.activity_version_id);
    current->start_time = now + 600;
    current->registration_end = now + 300;
    Id unchanged_version_id = 0;
    Need(f.act.CreateVersion(f.org, x.activity_id, &unchanged_version_id).ok,
         "clone unchanged session");
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
             f.tkt.CheckIn(f.insp, code).ok,
         "check in before unchanged version publish");
    Need(f.act.SubmitReview(f.org, unchanged_version_id).ok &&
             f.act.Review(f.adm, unchanged_version_id, true, "").ok &&
             f.act.Publish(f.org, unchanged_version_id).ok,
         "unchanged checked-in session may remain in a new version");
    Need(f.reg.Find(registration_id)->activity_version_id ==
                 x.activity_version_id &&
             f.reg.Find(registration_id)->status ==
                 RegistrationStatus::kCheckedIn,
         "checked-in record keeps its original version snapshot");
  }

  {
    Fx f;
    const auto x = f.New();
    const auto now = domain::Now();
    Id other_session_id = 0;
    Id other_category_id = 0;
    Need(f.ss.CreateSession(f.org, x.activity_version_id, "A2", now + 10000,
                            now + 12000, now - 100, now + 9000, 1,
                            &other_session_id)
                 .ok &&
             f.ss.CreateCategory(f.org, x.activity_version_id, other_session_id,
                                 "ticket", 1, &other_category_id)
                 .ok,
         "create second session");
    f.Go(x);
    Id draft_version_id = 0;
    Need(f.act.CreateVersion(f.org, x.activity_id, &draft_version_id).ok,
         "create version before session ends");
    Need(f.ss.UpdateSession(f.org, draft_version_id, x.sid, "A3", now + 86400,
                            now + 90000, now - 3600, now + 85000, 1)
             .ok,
         "prepare future replacement before current session ends");
    auto* current = f.ss.FindSession(x.sid, x.activity_version_id);
    current->start_time = now - 600;
    current->end_time = now - 1;
    current->registration_start = now - 1200;
    current->registration_end = now - 900;
    Need(!f.act.SubmitReview(f.org, draft_version_id).ok,
         "ended logical session cannot be reopened by prepared draft");
  }

  {
    Fx f;
    const auto x = f.New();
    const auto now = domain::Now();
    Id other_session_id = 0;
    Id other_category_id = 0;
    Need(f.ss.CreateSession(f.org, x.activity_version_id, "A2", now + 10000,
                            now + 12000, now - 100, now + 9000, 1,
                            &other_session_id)
                 .ok &&
             f.ss.CreateCategory(f.org, x.activity_version_id, other_session_id,
                                 "ticket", 1, &other_category_id)
                 .ok,
         "create second category");
    f.Go(x);
    Id draft_version_id = 0;
    Need(f.act.CreateVersion(f.org, x.activity_id, &draft_version_id).ok,
         "clone category draft");
    const auto other_category_version_id =
        f.ss.FindCategory(other_category_id, draft_version_id)->id;
    Need(f.ss.UpdateCategory(f.org, other_category_version_id, "renamed", 1).ok,
         "prepare unified rename before session ends");
    for (auto& session : f.db.ssns()) {
      if (session.logical_session_id != x.sid) continue;
      session.start_time = now - 600;
      session.end_time = now - 1;
      session.registration_start = now - 1200;
      session.registration_end = now - 900;
    }
    Need(!f.ss.UpdateCategory(f.org, other_category_version_id, "again", 1).ok,
         "unified rename cannot directly modify an ended session");
    Need(!f.act.SubmitReview(f.org, draft_version_id).ok,
         "publish validation rejects rename prepared before session end");
    Need(f.ss.FindCategory(x.cid, x.activity_version_id)->name == "ticket",
         "current ended category remains unchanged");
  }
}

void FirstTenAuditFixes() {
  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    Need(f.rls.AssignRole(f.adm, f.u1, domain::Role::kOrganizer).ok,
         "add a second role before removal test");
    Need(!f.rls.RemoveRole(f.adm, f.u1, domain::Role::kOrdinaryParticipant).ok,
         "participant role cannot be removed during an active registration");
    Need(f.reg.Cancel(f.u1, registration_id, &f.txt).ok &&
             f.rls.RemoveRole(f.adm, f.u1, domain::Role::kOrdinaryParticipant)
                 .ok,
         "participant role can be removed after the registration is closed");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    f.db.user_roles().erase(
        std::remove_if(f.db.user_roles().begin(), f.db.user_roles().end(),
                       [&](const domain::UserRole& role) {
                         return role.user_id == f.u1 &&
                                role.role_code ==
                                    domain::Role::kOrdinaryParticipant;
                       }),
        f.db.user_roles().end());
    auto* session = f.ss.FindSession(x.sid, x.activity_version_id);
    session->start_time = domain::Now();
    session->end_time = domain::Now() + 600;
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
             f.tkt.FindByRegistration(registration_id) == nullptr &&
             !f.tkt.CheckIn(f.insp, code).ok,
         "ticket layer rejects a stale ticket after participant role loss");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto first = f.Reg(f.u1, x);
    const auto waiting = f.Reg(f.u2, x);
    Need(f.auth.SetStatus(f.adm, f.u2, domain::UserStatus::kDisabled).ok &&
             f.reg.Cancel(f.u1, first, &f.txt).ok &&
             f.reg.Find(waiting)->status == RegistrationStatus::kWaitlisted,
         "disabled waitlist candidate is skipped");
    Need(f.auth.SetStatus(f.adm, f.u2, domain::UserStatus::kActive).ok,
         "reactivate waitlist candidate");
    f.bg.RunDue();
    Need(f.reg.Find(waiting)->status == RegistrationStatus::kRegistered &&
             f.tkt.FindByRegistration(waiting) != nullptr,
         "background tick retries an eligible waitlist candidate");
  }

  {
    Fx f;
    const auto x = f.New();
    f.auth.FindUser(f.u1)->name = "=SUM(1,1)";
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    for (const auto& log : f.db.audit_logs())
      Need(log.det.find(code) == std::string::npos,
           "ticket code is not copied into audit logs");
    Need(!f.tkt.CheckIn(f.insp, "=malicious-ticket").ok,
         "invalid ticket is rejected");
    Need(f.db.audit_logs().back().det.find("=malicious-ticket") ==
             std::string::npos,
         "invalid ticket input is not copied into audit logs");
    Need(!f.stat.QueryStats(f.org, x.activity_id).empty(),
         "create roster snapshot");
    Tmp tmp;
    const auto path = tmp.dir / "safe-roster.csv";
    Need(f.stat.ExportRoster(f.org, x.activity_id, path.string(), &f.txt).ok,
         "export privacy-safe roster");
    std::ifstream in(path);
    std::string header, row;
    Need(static_cast<bool>(std::getline(in, header)) &&
             static_cast<bool>(std::getline(in, row)),
         "read exported roster");
    const auto headings = infra::SplitCsv(header);
    const auto values = infra::SplitCsv(row);
    Need(headings.size() == 8 && headings[6] == "凭证状态" &&
             values.size() == 8 && values[1] == "'=SUM(1,1)" &&
             values[6] == "有效" && row.find(code) == std::string::npos,
         "roster masks credentials and neutralizes spreadsheet formulas");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
             f.rls.HasValidGrant(f.insp, x.sid) &&
             f.ss.CancelSession(f.org, x.sid).ok &&
             !f.rls.HasValidGrant(f.insp, x.sid),
         "session cancellation invalidates inspector grants");

    Fx g;
    const auto y = g.New();
    g.Go(y);
    Need(g.rls.GrantSession(g.adm, g.insp, y.sid).ok &&
             g.act.CancelActivity(g.org, y.activity_id).ok &&
             !g.rls.HasValidGrant(g.insp, y.sid),
         "activity cancellation invalidates inspector grants");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    auto* session = f.ss.FindSession(x.sid, x.activity_version_id);
    session->start_time = domain::Now() - 600;
    session->end_time = domain::Now() - 1;
    session->registration_start = domain::Now() - 1200;
    session->registration_end = domain::Now() - 900;
    Need(f.bg.RunAbsenceDetection(f.adm) == 0 &&
             f.act.FindActivity(x.activity_id)->status ==
                 domain::ActivityStatus::kEnded,
         "absence task count excludes activity-end maintenance");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    Id draft_version_id = 0;
    Need(
        f.act.CreateVersion(f.org, x.activity_id, &draft_version_id).ok &&
            f.act.EditDraft(f.org, draft_version_id, "new metadata", "desc").ok,
        "prepare a metadata revision");
    auto* session = f.ss.FindSession(x.sid, x.activity_version_id);
    session->start_time = domain::Now() - 600;
    session->end_time = domain::Now() - 1;
    session->registration_start = domain::Now() - 1200;
    session->registration_end = domain::Now() - 900;
    Need(!f.act.SubmitReview(f.org, draft_version_id).ok,
         "service rejects revisions after all current sessions ended");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    domain::Ticket duplicate = *f.tkt.FindByRegistration(registration_id);
    duplicate.id = f.db.NextId("ticket");
    duplicate.code = infra::UuidGenerator::V4();
    f.db.tkts().push_back(duplicate);
    Tmp tmp;
    Need(f.db.SaveRaw(tmp.dir.string()), "write intentionally corrupt data");
    infra::DataStore restored;
    Need(!restored.Load(tmp.dir.string()),
         "storage validation rejects two valid tickets for one registration");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    f.Reg(f.u1, x);
    f.Reg(f.u2, x);
    Need(f.act.CancelActivity(f.org, x.activity_id).ok,
         "cancel activity with registered and waitlisted users");
    for (const auto& log : f.db.audit_logs())
      Need(
          !(log.actn == "凭证失效" && log.res == domain::AuditResult::kFailure),
          "waitlisted cancellation does not emit false ticket failure");
  }

  {
    Fx f;
    const auto before = f.db.audit_logs().size();
    Need(!f.auth.ChangePassword(f.u1, "wrong-password", "new-password").ok &&
             f.db.audit_logs().size() == before + 1,
         "wrong old password creates exactly one failure audit");
    f.aud.Log(f.adm, "业务标记", domain::AuditResult::kSuccess, "marker");
    const auto expected_id = f.db.audit_logs().back().id;
    const auto recent = f.aud.Recent(f.adm, 1);
    Need(recent.size() == 1 && recent.front().id == expected_id &&
             f.db.audit_logs().back().actn == "查看审计",
         "recent audit query returns the pre-query business record");
  }
}

void LoginSecurityGuard() {
  Fx f;
  const auto account = f.auth.FindUser(f.u1)->account;
  Id user_id = 0;
  const auto wrong = f.auth.Login(account, "wrong-password", &user_id);
  const auto unknown =
      f.auth.Login("definitely-missing-account", "wrong-password", &user_id);
  Need(!wrong.ok && !unknown.ok && wrong.msg == unknown.msg,
       "unknown and wrong-password logins have the same public response");
  Need(f.db.audit_logs().back().det.find("definitely-missing-account") ==
           std::string::npos,
       "unknown account text is not copied into audit details");

  Need(f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kDisabled).ok,
       "disable user for response test");
  const auto disabled = f.auth.Login(account, "abcdef", &user_id);
  Need(!disabled.ok && disabled.msg == wrong.msg,
       "disabled account has the same public response");
  Need(f.auth.SetStatus(f.adm, f.u1, domain::UserStatus::kActive).ok,
       "reactivate user for lock test");

  auto* user = f.auth.FindUser(f.u1);
  user->failed_login_count = 4;
  user->failed_login_window_start = domain::AddMinutes(domain::Now(), -16);
  user->locked_until = 0;
  Need(!f.auth.Login(account, "wrong-password", &user_id).ok &&
           user->failed_login_count == 1 && user->locked_until == 0,
       "failures outside the window do not accumulate into a lock");

  user->failed_login_count = 4;
  user->failed_login_window_start = domain::Now();
  const auto locked_now = f.auth.Login(account, "wrong-password", &user_id);
  Need(!locked_now.ok && user->locked_until > domain::Now() &&
           user->failed_login_count == 0 &&
           user->failed_login_window_start == 0,
       "five failures inside the window lock the account");
  const auto locked_correct = f.auth.Login(account, "abcdef", &user_id);
  Need(!locked_correct.ok && locked_correct.msg == wrong.msg,
       "locked account does not reveal itself through a distinct response");
  user->locked_until = domain::Now() - 1;
  Need(f.auth.Login(account, "abcdef", &user_id).ok &&
           user->locked_until == 0 && user->failed_login_count == 0 &&
           user->failed_login_window_start == 0,
       "expired lock permits login and clears the old failure window");

  Need(!f.auth.Login(account, "wrong-password", &user_id).ok &&
           user->failed_login_count == 1 && user->failed_login_window_start > 0,
       "new failure opens a persisted failure window");
  const auto saved_window = user->failed_login_window_start;
  Tmp tmp;
  const auto current_dir = tmp.dir / "current";
  Need(f.db.Save(current_dir.string()), "save login failure window");
  infra::DataStore restored;
  Need(restored.Load(current_dir.string()), "reload login failure window");
  const auto restored_user =
      std::find_if(restored.usrs().begin(), restored.usrs().end(),
                   [&](const domain::User& item) { return item.id == f.u1; });
  Need(restored_user != restored.usrs().end() &&
           restored_user->failed_login_count == 1 &&
           restored_user->failed_login_window_start == saved_window,
       "failure window survives persistence");

  const auto legacy_dir = tmp.dir / "legacy";
  Need(f.db.Save(legacy_dir.string()), "save data for legacy conversion");
  const auto users_path = legacy_dir / "users.csv";
  std::ifstream input(users_path);
  std::vector<std::string> legacy_rows;
  std::string line;
  while (std::getline(input, line)) {
    auto fields = infra::SplitCsv(line);
    Need(fields.size() == 9, "new user row contains failure window field");
    fields.pop_back();
    legacy_rows.push_back(infra::JoinCsv(fields));
  }
  input.close();
  std::ofstream output(users_path, std::ios::trunc);
  for (const auto& row : legacy_rows) output << row << '\n';
  output.close();
  infra::DataStore legacy;
  Need(legacy.Load(legacy_dir.string()), "legacy eight-column users load");
  const auto legacy_user =
      std::find_if(legacy.usrs().begin(), legacy.usrs().end(),
                   [&](const domain::User& item) { return item.id == f.u1; });
  Need(legacy_user != legacy.usrs().end() &&
           legacy_user->failed_login_window_start == 0,
       "legacy users default to an empty failure window");
}

void FinalConsistencyFixes() {
  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
             f.rls.AssignRole(f.adm, f.org, domain::Role::kOrdinaryParticipant)
                 .ok,
         "prepare organizer-role removal");
    Need(f.rls.RemoveRole(f.adm, f.org, domain::Role::kOrganizer).ok &&
             !f.rls.HasRole(f.org, domain::Role::kOrganizer) &&
             f.act.FindActivity(x.activity_id)->status ==
                 domain::ActivityStatus::kCancelled &&
             f.reg.Find(registration_id)->status ==
                 domain::RegistrationStatus::kCancelled &&
             f.tkt.FindByCode(code)->status == domain::TicketStatus::kInvalid &&
             !f.rls.HasValidGrant(f.insp, x.sid),
         "removing organizer role atomically cancels owned active activities");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    auto* session = f.ss.FindSession(x.sid, x.activity_version_id);
    session->start_time = domain::Now() + 600;
    session->end_time = domain::Now() + 1200;
    session->registration_end = domain::Now() - 1;
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
             f.tkt.CheckIn(f.insp, code).ok &&
             f.rls.AssignRole(f.adm, f.org, domain::Role::kOrdinaryParticipant)
                 .ok,
         "prepare checked-in organizer-role removal");
    Need(!f.rls.RemoveRole(f.adm, f.org, domain::Role::kOrganizer).ok &&
             f.rls.HasRole(f.org, domain::Role::kOrganizer) &&
             f.act.FindActivity(x.activity_id)->status ==
                 domain::ActivityStatus::kPublished &&
             f.reg.Find(registration_id)->status ==
                 domain::RegistrationStatus::kCheckedIn,
         "checked-in cancellation rule rolls back organizer-role removal");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    f.tkt.FindByRegistration(registration_id)->status =
        domain::TicketStatus::kInvalid;
    Tmp tmp;
    Need(f.db.SaveRaw(tmp.dir.string()),
         "write registration without valid ticket");
    infra::DataStore restored;
    Need(!restored.Load(tmp.dir.string()),
         "storage rejects registered records without exactly one valid ticket");
  }

  {
    Fx f;
    const auto x = f.New("A1");
    const auto y = f.New("A2");
    auto* other_session = f.ss.FindSession(y.sid, y.activity_version_id);
    auto* other_category = f.ss.FindCategory(y.cid, y.activity_version_id);
    other_session->logical_session_id = x.sid;
    other_category->logical_session_id = x.sid;
    Tmp tmp;
    Need(f.db.SaveRaw(tmp.dir.string()),
         "write cross-activity logical session");
    infra::DataStore restored;
    Need(!restored.Load(tmp.dir.string()),
         "storage rejects a logical session shared by different activities");
  }

  {
    Fx f;
    const auto x = f.New("A1");
    const auto y = f.New("A2");
    f.ss.FindCategory(y.cid, y.activity_version_id)->logical_category_id =
        x.cid;
    Tmp tmp;
    Need(f.db.SaveRaw(tmp.dir.string()),
         "write cross-session logical category");
    infra::DataStore restored;
    Need(!restored.Load(tmp.dir.string()),
         "storage rejects a logical category shared by different sessions");
  }

  {
    Fx f;
    Need(f.ntf.Notify(f.u1, domain::NotificationType::kPromoted,
                      "system notification", "audit-actor-success"),
         "deliver notification for audit actor test");
    Need(f.db.audit_logs().back().actn == "投递通知" &&
             f.db.audit_logs().back().user_id == 0,
         "successful notification delivery is audited as a system action");
    Need(f.auth.SetStatus(f.adm, f.u2, domain::UserStatus::kDisabled).ok &&
             !f.ntf.Notify(f.u2, domain::NotificationType::kPromoted,
                           "retry notification", "audit-actor-failure") &&
             f.db.audit_logs().back().actn == "投递通知" &&
             f.db.audit_logs().back().user_id == 0,
         "failed notification delivery is audited as a system action");
  }

  {
    Need(infra::TicketCodeGenerator::IsValid(infra::UuidGenerator::V4()) &&
             !infra::TicketCodeGenerator::IsValid("T-263d1637a9d5"),
         "ticket format accepts UUID v4 and rejects legacy short codes");
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    f.tkt.FindByRegistration(registration_id)->code = "T-263d1637a9d5";
    Tmp tmp;
    Need(f.db.SaveRaw(tmp.dir.string()), "write legacy ticket code");
    infra::DataStore restored;
    Need(!restored.Load(tmp.dir.string()),
         "storage rejects non-UUID ticket credentials");
  }
}

void OrganizerDisableAndSessionFreeze() {
  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok,
         "prepare organizer account disable");
    Need(f.auth.SetStatus(f.adm, f.org, domain::UserStatus::kDisabled).ok &&
             f.auth.FindUser(f.org)->status == domain::UserStatus::kDisabled &&
             f.rls.HasRole(f.org, domain::Role::kOrganizer) &&
             f.act.FindActivity(x.activity_id)->status ==
                 domain::ActivityStatus::kCancelled &&
             f.reg.Find(registration_id)->status ==
                 domain::RegistrationStatus::kCancelled &&
             f.tkt.FindByCode(code)->status == domain::TicketStatus::kInvalid &&
             !f.rls.HasValidGrant(f.insp, x.sid),
         "disabling organizer atomically cancels activities and dependencies");
  }

  {
    Fx f;
    const auto cancellable = f.New("A1");
    f.Go(cancellable);
    const auto x = f.New("A2");
    f.Go(x);
    const auto registration_id = f.Reg(f.u1, x);
    const auto code = f.tkt.FindByRegistration(registration_id)->code;
    auto* session = f.ss.FindSession(x.sid, x.activity_version_id);
    session->start_time = domain::Now() + 600;
    session->end_time = domain::Now() + 1200;
    session->registration_end = domain::Now() - 1;
    Need(f.rls.GrantSession(f.adm, f.insp, x.sid).ok &&
             f.tkt.CheckIn(f.insp, code).ok,
         "prepare checked-in organizer account disable");
    Need(!f.auth.SetStatus(f.adm, f.org, domain::UserStatus::kDisabled).ok &&
             f.auth.FindUser(f.org)->status == domain::UserStatus::kActive &&
             f.act.FindActivity(cancellable.activity_id)->status ==
                 domain::ActivityStatus::kPublished &&
             f.act.FindActivity(x.activity_id)->status ==
                 domain::ActivityStatus::kPublished &&
             f.reg.Find(registration_id)->status ==
                 domain::RegistrationStatus::kCheckedIn &&
             f.tkt.FindByCode(code)->status == domain::TicketStatus::kValid &&
             f.rls.HasValidGrant(f.insp, x.sid),
         "checked-in activity rolls back earlier cancellations and account "
         "disable");
  }

  {
    Fx f;
    const auto x = f.New();
    f.Go(x);
    domain::Id draft_version_id = 0;
    Need(f.act.CreateVersion(f.org, x.activity_id, &draft_version_id).ok,
         "create draft for session freeze");
    auto* current = f.ss.FindSession(x.sid, x.activity_version_id);
    auto* draft = f.ss.FindSession(x.sid, draft_version_id);
    auto* draft_category = f.ss.FindCategory(x.cid, draft_version_id);
    const auto now = domain::Now();
    for (auto* session : {current, draft}) {
      session->start_time = now + 600;
      session->end_time = now + 1800;
      session->registration_start = now - 3600;
      session->registration_end = now + 300;
    }
    Need(!f.ss.UpdateSession(f.org, draft_version_id, x.sid, "A2",
                             draft->start_time, draft->end_time,
                             draft->registration_start, draft->registration_end,
                             draft->capacity)
                 .ok &&
             !f.ss.UpdateCategoryQuota(f.org, draft_category->id,
                                       draft_category->capacity + 1)
                  .ok,
         "direct session and quota edits are frozen thirty minutes before "
         "start");
    Need(f.ss.UpdateSession(f.org, draft_version_id, x.sid, draft->location,
                            draft->start_time, draft->end_time,
                            draft->registration_start, now + 240,
                            draft->capacity)
             .ok,
         "registration window remains editable when frozen fields are "
         "unchanged");

    draft->location = "A2";
    Need(!f.act.SubmitReview(f.org, draft_version_id).ok,
         "pre-edited draft cannot bypass the freeze during submission");
    draft->location = current->location;
    draft_category->capacity += 1;
    Need(!f.act.SubmitReview(f.org, draft_version_id).ok,
         "pre-edited quota cannot bypass the freeze during submission");
    draft_category->capacity =
        f.ss.FindCategory(x.cid, x.activity_version_id)->capacity;
    Need(f.act.EditDraft(f.org, draft_version_id, "title-only-update", "desc")
                 .ok &&
             f.act.SubmitReview(f.org, draft_version_id).ok &&
             f.act.Review(f.adm, draft_version_id, true, "").ok &&
             f.act.Publish(f.org, draft_version_id).ok,
         "title and registration-window-only update remains publishable");
  }
}

int main(int argc, char** argv) {
  try {
    Need(argc == 2, "case number required");
    const int n = std::stoi(argv[1]);
    switch (n) {
      case 35:
        OrganizerDisableAndSessionFreeze();
        break;
      case 34:
        FinalConsistencyFixes();
        break;
      case 33:
        LoginSecurityGuard();
        break;
      case 32:
        FirstTenAuditFixes();
        break;
      case 31:
        PublishedStateVersionGuards();
        break;
      case 30:
        CheckedInCancellationGuards();
        break;
      case 27:
        PromotionPrivacy();
        break;
      case 28:
        StrictDates();
        break;
      case 29:
        StrictConsoleInput();
        break;
      case 20:
        IdempotencyCoverage();
        break;
      case 21:
        ReviewGuards();
        break;
      case 22:
        AuthenticationEdges();
        break;
      case 23:
        TicketBoundaries();
        break;
      case 24:
        RegistrationEdges();
        break;
      case 25:
        CsvRoundTrip();
        break;
      case 26:
        ConcurrentIdempotency();
        break;
      case 19:
        CancellationRules();
        break;
      case 18:
        SingleTicket();
        break;
      case 13:
        RevisionBusiness();
        break;
      case 14:
        RevisionStorage();
        break;
      case 15:
        RevisionAccess();
        break;
      case 16:
        RevisionUi();
        break;
      case 17:
        RevisionTransitions();
        break;
      case 1:
        Absence();
        break;
      case 2:
        Deadline();
        break;
      case 3:
        Retry();
        break;
      case 4:
        History();
        break;
      case 5:
        Cancelled();
        break;
      case 6:
        Conflicts();
        break;
      case 7:
        Versions();
        break;
      case 8:
        Categories();
        break;
      case 9:
        Scheduler();
        break;
      case 10:
        Access();
        break;
      case 11:
        Migration();
        break;
      case 12:
        Compliance();
        break;
      default:
        throw std::runtime_error("unknown case");
    }
    std::cout << "PASS UML " << n << '\n';
    return 0;
  } catch (const std::exception& e) {
    std::cerr << "FAIL: " << e.what() << '\n';
    return 1;
  }
}
