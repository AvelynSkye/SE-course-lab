

#include "infra/data_store.h"

#include <algorithm>
#include <cstddef>
#include <exception>
#include <filesystem>
#include <fstream>
#include <functional>
#include <map>
#include <mutex>
#include <set>
#include <stdexcept>
#include <string>
#include <system_error>
#include <tuple>
#include <utility>
#include <vector>

#include "domain/entity_queries.h"
#include "domain/types.h"
#include "infra/csv_util.h"
#include "infra/security.h"

namespace campus {
namespace infra {

namespace {

typedef std::vector<std::string> Row;
typedef std::function<void(const Row&)> RowHandler;

std::string Text(domain::Id val) { return std::to_string(val); }

std::string Text(int val) { return std::to_string(val); }

std::string Text(bool val) { return val ? "1" : "0"; }

std::string TextTime(domain::Timestamp val) {
  return std::to_string(static_cast<domain::Id>(val));
}

template <typename EnumType>
std::string TextEnum(EnumType val) {
  return std::to_string(static_cast<int>(val));
}

std::string MakeRow(const std::vector<std::string>& flds) {
  return JoinCsv(flds);
}

bool StrictId(const std::string& s, domain::Id* v) {
  std::size_t pos = 0;
  *v = std::stoll(s, &pos);
  if (pos != s.size()) throw std::runtime_error("非法整数");
  return true;
}
bool StrictInt(const std::string& s, int* v) {
  std::size_t pos = 0;
  *v = std::stoi(s, &pos);
  if (pos != s.size()) throw std::runtime_error("非法整数");
  return true;
}
bool StrictBool(const std::string& s, bool* v) {
  if (!ParseBoolValue(s, v)) throw std::runtime_error("非法布尔值");
  return true;
}

void ReadTable(const std::string& pth, const RowHandler& fn) {
  const std::map<std::string, std::string> schemas = {
      {"users.csv", "isssibiii"},
      {"user_roles.csv", "ii"},
      {"activities.csv", "isii"},
      {"activity_versions.csv", "iiiiisss"},
      {"logical_sessions.csv", "ib"},
      {"sessions.csv", "iiisiiiii"},
      {"logical_categories.csv", "ib"},
      {"category_versions.csv", "iiisii"},
      {"session_grants.csv", "iii"},
      {"registrations.csv", "iiiiiiiii"},
      {"tickets.csv", "iisii"},
      {"checkin_events.csv", "iii"},
      {"notifications.csv", "iiisbis"},
      {"audit_logs.csv", "iisisi"},
      {"idempotency_records.csv", "ssssi"},
      {"background_tasks.csv", "issiiiis"}};
  std::ifstream in(pth.c_str());
  if (!in.is_open()) {
    throw std::runtime_error("无法读取数据文件：" + pth);
  }
  std::string ln;
  while (std::getline(in, ln)) {
    if (ln.empty()) {
      continue;
    }
    std::string rec = ln;
    auto quotes = [](const std::string& s) {
      return std::count(s.begin(), s.end(), '"') % 2;
    };
    while (quotes(rec)) {
      if (!std::getline(in, ln)) throw std::runtime_error("CSV 引号未闭合");
      rec += "\n" + ln;
    }
    const auto row = SplitCsv(rec);
    const auto fmt = schemas.at(std::filesystem::path(pth).filename().string());
    if (row.size() > fmt.size()) throw std::runtime_error("数据列数错误");
    for (std::size_t i = 0; i < row.size(); ++i) {
      if (fmt[i] == 's') continue;
      if (fmt[i] == 'b') {
        bool v;
        if (!StrictBool(row[i], &v)) throw std::runtime_error("布尔字段非法");
      } else {
        std::size_t pos = 0;
        const auto num = std::stoll(row[i], &pos);
        (void)num;
        if (pos != row[i].size()) throw std::runtime_error("数字字段非法");
      }
    }
    fn(row);
  }
  if (in.bad()) throw std::runtime_error("读取失败：" + pth);
}

template <typename T>
bool WriteTable(const std::string& pth, const std::vector<T>& xs,
                std::string (*ser)(const T&)) {
  std::ofstream out(pth.c_str());
  if (!out.is_open()) {
    return false;
  }
  for (std::size_t i = 0; i < xs.size(); ++i) {
    out << ser(xs[i]) << "\n";
  }
  out.close();
  return !out.fail();
}

domain::Timestamp ToTimestamp(const std::string& txt) {
  domain::Id val = 0;
  if (!StrictId(txt, &val)) {
    return 0;
  }
  return static_cast<domain::Timestamp>(val);
}

std::string RowOf(const domain::User& usr) {
  return MakeRow({Text(usr.id), usr.account, usr.name, usr.password_hash,
                  TextEnum(usr.status), Text(usr.must_change_password),
                  Text(usr.failed_login_count), TextTime(usr.locked_until),
                  TextTime(usr.failed_login_window_start)});
}

void FillUser(const Row& x, domain::User* usr) {
  if (x.size() < 8) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &usr->id);
  usr->account = x[1];
  usr->name = x[2];
  usr->password_hash = x[3];
  int status = 0;
  if (StrictInt(x[4], &status)) {
    usr->status = static_cast<domain::UserStatus>(status);
  }
  StrictBool(x[5], &usr->must_change_password);
  StrictInt(x[6], &usr->failed_login_count);
  usr->locked_until = ToTimestamp(x[7]);
  if (x.size() >= 9) usr->failed_login_window_start = ToTimestamp(x[8]);
}

std::string RowOf(const domain::UserRole& usrRl) {
  return MakeRow({Text(usrRl.user_id), TextEnum(usrRl.role_code)});
}

void FillUserRole(const Row& x, domain::UserRole* usrRl) {
  if (x.size() < 2) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &usrRl->user_id);
  int rl = 0;
  if (StrictInt(x[1], &rl)) {
    usrRl->role_code = static_cast<domain::Role>(rl);
  }
}

std::string RowOf(const domain::Activity& act) {
  return MakeRow(
      {Text(act.id), act.title, TextEnum(act.status), Text(act.creator_id)});
}

void FillActivity(const Row& x, domain::Activity* act) {
  if (x.size() < 4) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &act->id);
  act->title = x[1];
  int status = 0;
  if (StrictInt(x[2], &status)) {
    act->status = static_cast<domain::ActivityStatus>(status);
  }
  StrictId(x[3], &act->creator_id);
}

std::string RowOf(const domain::ActivityVersion& ver) {
  return MakeRow({Text(ver.id), Text(ver.activity_id), Text(ver.version_number),
                  TextEnum(ver.status), TextTime(ver.published_at),
                  ver.description, ver.rejection_reason, ver.title});
}

void FillActivityVersion(const Row& x, domain::ActivityVersion* ver) {
  if (x.size() < 7) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &ver->id);
  StrictId(x[1], &ver->activity_id);
  StrictInt(x[2], &ver->version_number);
  int status = 0;
  if (StrictInt(x[3], &status)) {
    ver->status = static_cast<domain::VersionStatus>(status);
  }
  ver->published_at = ToTimestamp(x[4]);
  ver->description = x[5];
  ver->rejection_reason = x[6];
  if (x.size() > 7) ver->title = x[7];
}

std::string RowOf(const domain::LogicalSession& lSsn) {
  return MakeRow({Text(lSsn.id), Text(lSsn.cancelled)});
}

void FillLogicalSession(const Row& x, domain::LogicalSession* ssn) {
  if (x.size() < 2) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &ssn->id);
  StrictBool(x[1], &ssn->cancelled);
}

std::string RowOf(const domain::Session& ssn) {
  return MakeRow({Text(ssn.id), Text(ssn.logical_session_id),
                  Text(ssn.activity_version_id), ssn.location,
                  TextTime(ssn.start_time), TextTime(ssn.end_time),
                  TextTime(ssn.registration_start),
                  TextTime(ssn.registration_end), Text(ssn.capacity)});
}

void FillSession(const Row& x, domain::Session* ssn) {
  if (x.size() < 9) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &ssn->id);
  StrictId(x[1], &ssn->logical_session_id);
  StrictId(x[2], &ssn->activity_version_id);
  ssn->location = x[3];
  ssn->start_time = ToTimestamp(x[4]);
  ssn->end_time = ToTimestamp(x[5]);
  ssn->registration_start = ToTimestamp(x[6]);
  ssn->registration_end = ToTimestamp(x[7]);
  StrictInt(x[8], &ssn->capacity);
}

std::string RowOf(const domain::LogicalCategory& cat) {
  return MakeRow({Text(cat.id), Text(cat.cancelled)});
}

void FillLogicalCategory(const Row& x, domain::LogicalCategory* cat) {
  if (x.size() < 2) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &cat->id);
  StrictBool(x[1], &cat->cancelled);
}

std::string RowOf(const domain::CategoryVersion& cat) {
  return MakeRow({Text(cat.id), Text(cat.logical_category_id),
                  Text(cat.activity_version_id), cat.name, Text(cat.capacity),
                  Text(cat.logical_session_id)});
}

void FillCategoryVersion(const Row& x, domain::CategoryVersion* cat) {
  if (x.size() < 5) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &cat->id);
  StrictId(x[1], &cat->logical_category_id);
  StrictId(x[2], &cat->activity_version_id);
  cat->name = x[3];
  StrictInt(x[4], &cat->capacity);
  if (x.size() > 5) StrictId(x[5], &cat->logical_session_id);
}

std::string RowOf(const domain::SessionGrant& grt) {
  return MakeRow(
      {Text(grt.user_id), Text(grt.logical_session_id), TextEnum(grt.status)});
}

void FillSessionGrant(const Row& x, domain::SessionGrant* grt) {
  if (x.size() < 3) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &grt->user_id);
  StrictId(x[1], &grt->logical_session_id);
  int status = 0;
  if (StrictInt(x[2], &status)) {
    grt->status = static_cast<domain::GrantStatus>(status);
  }
}

std::string RowOf(const domain::Registration& reg) {
  return MakeRow({Text(reg.id), Text(reg.user_id), Text(reg.logical_session_id),
                  Text(reg.logical_category_id), Text(reg.activity_version_id),
                  TextEnum(reg.status), Text(reg.waitlist_sequence),
                  TextTime(reg.created_at), TextTime(reg.cancelled_at)});
}

void FillRegistration(const Row& x, domain::Registration* reg) {
  if (x.size() < 9) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &reg->id);
  StrictId(x[1], &reg->user_id);
  StrictId(x[2], &reg->logical_session_id);
  StrictId(x[3], &reg->logical_category_id);
  StrictId(x[4], &reg->activity_version_id);
  int status = 0;
  if (StrictInt(x[5], &status)) {
    reg->status = static_cast<domain::RegistrationStatus>(status);
  }
  StrictId(x[6], &reg->waitlist_sequence);
  reg->created_at = ToTimestamp(x[7]);
  reg->cancelled_at = ToTimestamp(x[8]);
}

std::string RowOf(const domain::Ticket& tkt) {
  return MakeRow({Text(tkt.id), Text(tkt.registration_id), tkt.code,
                  TextEnum(tkt.status), TextTime(tkt.issued_at)});
}

void FillTicket(const Row& x, domain::Ticket* tkt) {
  if (x.size() < 5) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &tkt->id);
  StrictId(x[1], &tkt->registration_id);
  tkt->code = x[2];
  int status = 0;
  if (StrictInt(x[3], &status)) {
    tkt->status = static_cast<domain::TicketStatus>(status);
  }
  tkt->issued_at = ToTimestamp(x[4]);
}

std::string RowOf(const domain::CheckinEvent& ev) {
  return MakeRow(
      {Text(ev.id), Text(ev.registration_id), TextTime(ev.checked_at)});
}

void FillCheckinEvent(const Row& x, domain::CheckinEvent* ev) {
  if (x.size() < 3) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &ev->id);
  StrictId(x[1], &ev->registration_id);
  ev->checked_at = ToTimestamp(x[2]);
}

std::string RowOf(const domain::Notification& ntf) {
  return MakeRow({Text(ntf.id), Text(ntf.user_id), TextEnum(ntf.typ), ntf.cnt,
                  Text(ntf.read), TextTime(ntf.created_at), ntf.event_id});
}

void FillNotification(const Row& x, domain::Notification* ntf) {
  if (x.size() < 6) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &ntf->id);
  StrictId(x[1], &ntf->user_id);
  int typ = 0;
  if (StrictInt(x[2], &typ)) {
    ntf->typ = static_cast<domain::NotificationType>(typ);
  }
  ntf->cnt = x[3];
  StrictBool(x[4], &ntf->read);
  ntf->created_at = ToTimestamp(x[5]);
  ntf->event_id = x.size() > 6 ? x[6] : "legacy:" + std::to_string(ntf->id);
}

std::string RowOf(const domain::AuditLog& lg) {
  return MakeRow({Text(lg.id), Text(lg.user_id), lg.actn, TextEnum(lg.res),
                  lg.det, TextTime(lg.created_at)});
}

void FillAuditLog(const Row& x, domain::AuditLog* lg) {
  if (x.size() < 6) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &lg->id);
  StrictId(x[1], &lg->user_id);
  lg->actn = x[2];
  int res = 0;
  if (StrictInt(x[3], &res)) {
    lg->res = static_cast<domain::AuditResult>(res);
  }
  lg->det = x[4];
  lg->created_at = ToTimestamp(x[5]);
}

std::string RowOf(const domain::IdempotencyRecord& rec) {
  return MakeRow(
      {rec.ky, rec.op, rec.request_hash, rec.res, TextTime(rec.created_at)});
}

void FillIdempotencyRecord(const Row& x, domain::IdempotencyRecord* rec) {
  if (x.size() < 5) throw std::runtime_error("数据列缺失");
  rec->ky = x[0];
  rec->op = x[1];
  rec->request_hash = x[2];
  rec->res = x[3];
  rec->created_at = ToTimestamp(x[4]);
}

std::string RowOf(const domain::BackgroundTask& tsk) {
  return MakeRow({Text(tsk.id), tsk.task_type, tsk.pl, TextEnum(tsk.status),
                  Text(tsk.retry_count), Text(tsk.user_id), TextEnum(tsk.typ),
                  tsk.cnt});
}

void FillBackgroundTask(const Row& x, domain::BackgroundTask* tsk) {
  if (x.size() < 5) throw std::runtime_error("数据列缺失");
  StrictId(x[0], &tsk->id);
  tsk->task_type = x[1];
  tsk->pl = x[2];
  int status = 0;
  if (StrictInt(x[3], &status)) {
    tsk->status = static_cast<domain::TaskStatus>(status);
  }
  StrictInt(x[4], &tsk->retry_count);
  if (x.size() > 7) {
    StrictId(x[5], &tsk->user_id);
    int typ = 0;
    StrictInt(x[6], &typ);
    tsk->typ = static_cast<domain::NotificationType>(typ);
    tsk->cnt = x[7];
  }
}

domain::Id MaxId(const std::vector<domain::User>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::Activity>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::ActivityVersion>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::LogicalSession>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::Session>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::LogicalCategory>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::CategoryVersion>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::Registration>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::Ticket>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::CheckinEvent>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::Notification>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::AuditLog>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

domain::Id MaxId(const std::vector<domain::BackgroundTask>& xs) {
  domain::Id res = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].id > res) {
      res = xs[i].id;
    }
  }
  return res;
}

}

DataStore::DataStore() { Clear(); }

bool DataStore::Load(const std::string& dir) {
  std::lock_guard<std::recursive_mutex> lk(mu_);
  try {
    const std::filesystem::path p(dir), bak(dir + ".campus-backup");
    if (!std::filesystem::exists(p) && std::filesystem::exists(bak))
      std::filesystem::rename(bak, p);
    if (!std::filesystem::exists(p) || std::filesystem::is_empty(p)) {
      Clear();
      return true;
    }
    DataStore tmp;
    if (!tmp.LoadRaw(dir)) return false;
    if (!tmp.Validate()) return false;
    if (std::filesystem::exists(bak))
      std::filesystem::rename(bak, dir + ".recovered-" + UuidGenerator::V4());
    Swap(&tmp);
    return true;
  } catch (const std::exception&) {
    return false;
  }
}

bool DataStore::Save(const std::string& dir) const {
  std::lock_guard<std::recursive_mutex> lk(mu_);
  const std::filesystem::path p(dir), bak(dir + ".campus-backup");
  const std::filesystem::path tmp(dir + ".campus-stage-" + UuidGenerator::V4());
  std::error_code ec;
  bool moved = false;
  try {
    if (std::filesystem::exists(bak)) return false;
    if (std::filesystem::exists(p)) {
      if (!std::filesystem::is_directory(p)) return false;
      std::filesystem::create_directories(tmp);
      std::filesystem::copy(p, tmp, std::filesystem::copy_options::recursive);
    } else {
      std::filesystem::create_directories(tmp);
    }
    if (!SaveRaw(tmp.string())) {
      std::filesystem::remove_all(tmp, ec);
      return false;
    }
    if (std::filesystem::exists(p)) {
      std::filesystem::rename(p, bak);
      moved = true;
    }
    std::filesystem::rename(tmp, p);
    if (moved) std::filesystem::remove_all(bak, ec);
    return true;
  } catch (const std::exception& e) {
    err_ = e.what();
    if (moved && !std::filesystem::exists(p, ec))
      std::filesystem::rename(bak, p, ec);
    std::filesystem::remove_all(tmp, ec);
    return false;
  }
}

void DataStore::CopyTo(DataStore* dst) const {
  std::lock_guard<std::recursive_mutex> lk(mu_);
  dst->cnts_ = cnts_;
  dst->usrs_ = usrs_;
  dst->usrRls_ = usrRls_;
  dst->acts_ = acts_;
  dst->actVers_ = actVers_;
  dst->lSsns_ = lSsns_;
  dst->ssns_ = ssns_;
  dst->lCats_ = lCats_;
  dst->catVers_ = catVers_;
  dst->ssnGrs_ = ssnGrs_;
  dst->regs_ = regs_;
  dst->tkts_ = tkts_;
  dst->chkEvs_ = chkEvs_;
  dst->ntfs_ = ntfs_;
  dst->audLogs_ = audLogs_;
  dst->idemRecs_ = idemRecs_;
  dst->bgTsks_ = bgTsks_;
}

void DataStore::Swap(DataStore* dst) noexcept {
  cnts_.swap(dst->cnts_);
  usrs_.swap(dst->usrs_);
  usrRls_.swap(dst->usrRls_);
  acts_.swap(dst->acts_);
  actVers_.swap(dst->actVers_);
  lSsns_.swap(dst->lSsns_);
  ssns_.swap(dst->ssns_);
  lCats_.swap(dst->lCats_);
  catVers_.swap(dst->catVers_);
  ssnGrs_.swap(dst->ssnGrs_);
  regs_.swap(dst->regs_);
  tkts_.swap(dst->tkts_);
  chkEvs_.swap(dst->chkEvs_);
  ntfs_.swap(dst->ntfs_);
  audLogs_.swap(dst->audLogs_);
  idemRecs_.swap(dst->idemRecs_);
  bgTsks_.swap(dst->bgTsks_);
}

void DataStore::Clear() {
  std::lock_guard<std::recursive_mutex> lk(mu_);
  cnts_.clear();
  usrs_.clear();
  usrRls_.clear();
  acts_.clear();
  actVers_.clear();
  lSsns_.clear();
  ssns_.clear();
  lCats_.clear();
  catVers_.clear();
  ssnGrs_.clear();
  regs_.clear();
  tkts_.clear();
  chkEvs_.clear();
  ntfs_.clear();
  audLogs_.clear();
  idemRecs_.clear();
  bgTsks_.clear();
}

domain::Id DataStore::NextId(const std::string& tbl) {
  std::lock_guard<std::recursive_mutex> lk(mu_);
  domain::Id& cur = cnts_[tbl];
  ++cur;
  return cur;
}

bool DataStore::LoadRaw(const std::string& dir) {
  std::lock_guard<std::recursive_mutex> lk(mu_);
  Clear();
  const std::string pre = dir + "/";
  ReadTable(pre + "users.csv", [this](const Row& x) {
    domain::User usr;
    FillUser(x, &usr);
    usrs_.push_back(usr);
  });
  ReadTable(pre + "user_roles.csv", [this](const Row& x) {
    domain::UserRole usrRl;
    FillUserRole(x, &usrRl);
    usrRls_.push_back(usrRl);
  });
  ReadTable(pre + "activities.csv", [this](const Row& x) {
    domain::Activity act;
    FillActivity(x, &act);
    acts_.push_back(act);
  });
  ReadTable(pre + "activity_versions.csv", [this](const Row& x) {
    domain::ActivityVersion ver;
    FillActivityVersion(x, &ver);
    actVers_.push_back(ver);
  });
  ReadTable(pre + "logical_sessions.csv", [this](const Row& x) {
    domain::LogicalSession ssn;
    FillLogicalSession(x, &ssn);
    lSsns_.push_back(ssn);
  });
  ReadTable(pre + "sessions.csv", [this](const Row& x) {
    domain::Session ssn;
    FillSession(x, &ssn);
    ssns_.push_back(ssn);
  });
  ReadTable(pre + "logical_categories.csv", [this](const Row& x) {
    domain::LogicalCategory cat;
    FillLogicalCategory(x, &cat);
    lCats_.push_back(cat);
  });
  ReadTable(pre + "category_versions.csv", [this](const Row& x) {
    domain::CategoryVersion cat;
    FillCategoryVersion(x, &cat);
    catVers_.push_back(cat);
  });
  ReadTable(pre + "session_grants.csv", [this](const Row& x) {
    domain::SessionGrant grt;
    FillSessionGrant(x, &grt);
    ssnGrs_.push_back(grt);
  });
  ReadTable(pre + "registrations.csv", [this](const Row& x) {
    domain::Registration reg;
    FillRegistration(x, &reg);
    regs_.push_back(reg);
  });
  ReadTable(pre + "tickets.csv", [this](const Row& x) {
    domain::Ticket tkt;
    FillTicket(x, &tkt);
    tkts_.push_back(tkt);
  });
  ReadTable(pre + "checkin_events.csv", [this](const Row& x) {
    domain::CheckinEvent ev;
    FillCheckinEvent(x, &ev);
    chkEvs_.push_back(ev);
  });
  ReadTable(pre + "notifications.csv", [this](const Row& x) {
    domain::Notification ntf;
    FillNotification(x, &ntf);
    ntfs_.push_back(ntf);
  });
  ReadTable(pre + "audit_logs.csv", [this](const Row& x) {
    domain::AuditLog lg;
    FillAuditLog(x, &lg);
    audLogs_.push_back(lg);
  });
  ReadTable(pre + "idempotency_records.csv", [this](const Row& x) {
    domain::IdempotencyRecord rec;
    FillIdempotencyRecord(x, &rec);
    idemRecs_.push_back(rec);
  });
  ReadTable(pre + "background_tasks.csv", [this](const Row& x) {
    domain::BackgroundTask tsk;
    FillBackgroundTask(x, &tsk);
    bgTsks_.push_back(tsk);
  });
  RefreshCounters();
  for (auto& u : usrs_) {
    if (PasswordHasher::Verify(u.account, "123456", u.password_hash))
      u.must_change_password = true;
  }
  for (auto& v : actVers_) {
    if (!v.title.empty()) continue;
    for (const auto& a : acts_)
      if (a.id == v.activity_id) v.title = a.title;
  }
  std::map<std::pair<domain::Id, domain::Id>, domain::Id> rem;
  std::map<domain::Id, domain::Id> first;
  std::vector<domain::CategoryVersion> cs;
  for (const auto& c : catVers_) {
    if (c.logical_session_id != 0) {
      cs.push_back(c);
      continue;
    }
    bool one = true;
    for (const auto& ss : ssns_) {
      if (ss.activity_version_id != c.activity_version_id) continue;
      auto ky = std::make_pair(c.logical_category_id, ss.logical_session_id);
      if (rem.count(ky) == 0) {
        if (first.count(c.logical_category_id) == 0) {
          first[c.logical_category_id] = ss.logical_session_id;
          rem[ky] = c.logical_category_id;
        } else {
          domain::LogicalCategory lc;
          lc.id = NextId("logical_category");
          for (const auto& old : lCats_)
            if (old.id == c.logical_category_id) lc.cancelled = old.cancelled;
          lCats_.push_back(lc);
          rem[ky] = lc.id;
        }
      }
      auto nc = c;
      nc.logical_session_id = ss.logical_session_id;
      nc.logical_category_id = rem[ky];
      if (!one) nc.id = NextId("category_version");
      one = false;
      cs.push_back(nc);
    }
    if (one) cs.push_back(c);
  }
  catVers_ = std::move(cs);
  for (auto& r : regs_) {
    auto it = rem.find({r.logical_category_id, r.logical_session_id});
    if (it != rem.end()) r.logical_category_id = it->second;
  }
  for (auto& r : idemRecs_) {
    const auto a = r.request_hash.find(':');
    const auto b = r.request_hash.find(':', a == std::string::npos ? a : a + 1);
    if (a == std::string::npos || b == std::string::npos) continue;
    domain::Id sid = 0, cid = 0;
    if (!StrictId(r.request_hash.substr(a + 1, b - a - 1), &sid) ||
        !StrictId(r.request_hash.substr(b + 1), &cid))
      continue;
    auto it = rem.find({cid, sid});
    if (it != rem.end())
      r.request_hash =
          r.request_hash.substr(0, b + 1) + std::to_string(it->second);
  }
  RefreshCounters();
  return true;
}

bool DataStore::SaveRaw(const std::string& dir) const {
  std::lock_guard<std::recursive_mutex> lk(mu_);
  std::error_code err;
  std::filesystem::create_directories(dir, err);
  if (err) return false;
  bool ok = true;
  const std::string pre = dir + "/";
  ok = WriteTable<domain::User>(pre + "users.csv", usrs_, RowOf) && ok;
  ok = WriteTable<domain::UserRole>(pre + "user_roles.csv", usrRls_, RowOf) &&
       ok;
  ok = WriteTable<domain::Activity>(pre + "activities.csv", acts_, RowOf) && ok;
  ok = WriteTable<domain::ActivityVersion>(pre + "activity_versions.csv",
                                           actVers_, RowOf) &&
       ok;
  ok = WriteTable<domain::LogicalSession>(pre + "logical_sessions.csv", lSsns_,
                                          RowOf) &&
       ok;
  ok = WriteTable<domain::Session>(pre + "sessions.csv", ssns_, RowOf) && ok;
  ok = WriteTable<domain::LogicalCategory>(pre + "logical_categories.csv",
                                           lCats_, RowOf) &&
       ok;
  ok = WriteTable<domain::CategoryVersion>(pre + "category_versions.csv",
                                           catVers_, RowOf) &&
       ok;
  ok = WriteTable<domain::SessionGrant>(pre + "session_grants.csv", ssnGrs_,
                                        RowOf) &&
       ok;
  ok = WriteTable<domain::Registration>(pre + "registrations.csv", regs_,
                                        RowOf) &&
       ok;
  ok = WriteTable<domain::Ticket>(pre + "tickets.csv", tkts_, RowOf) && ok;
  ok = WriteTable<domain::CheckinEvent>(pre + "checkin_events.csv", chkEvs_,
                                        RowOf) &&
       ok;
  ok = WriteTable<domain::Notification>(pre + "notifications.csv", ntfs_,
                                        RowOf) &&
       ok;
  ok = WriteTable<domain::AuditLog>(pre + "audit_logs.csv", audLogs_, RowOf) &&
       ok;
  ok = WriteTable<domain::IdempotencyRecord>(pre + "idempotency_records.csv",
                                             idemRecs_, RowOf) &&
       ok;
  ok = WriteTable<domain::BackgroundTask>(pre + "background_tasks.csv", bgTsks_,
                                          RowOf) &&
       ok;
  return ok;
}

bool DataStore::Validate() const {
  auto unique = [](const auto& xs) {
    std::set<domain::Id> ids;
    for (const auto& x : xs)
      if (x.id <= 0 || !ids.insert(x.id).second) return false;
    return true;
  };
  auto has = [](const auto& xs, domain::Id id) {
    return std::any_of(xs.begin(), xs.end(),
                       [id](const auto& x) { return x.id == id; });
  };
  auto valid = [](auto v, int max) {
    return static_cast<int>(v) >= 0 && static_cast<int>(v) <= max;
  };
  if (!unique(usrs_)) return false;
  if (!unique(acts_)) return false;
  if (!unique(actVers_)) return false;
  if (!unique(lSsns_)) return false;
  if (!unique(ssns_)) return false;
  if (!unique(lCats_)) return false;
  if (!unique(catVers_)) return false;
  if (!unique(regs_)) return false;
  if (!unique(tkts_)) return false;
  if (!unique(chkEvs_)) return false;
  if (!unique(ntfs_)) return false;
  if (!unique(audLogs_)) return false;
  if (!unique(bgTsks_)) return false;
  std::set<std::string> accts, codes;
  for (const auto& u : usrs_)
    if (u.account.empty() || !accts.insert(u.account).second ||
        !valid(u.status, 1) || u.failed_login_count < 0 || u.locked_until < 0 ||
        u.failed_login_window_start < 0)
      return false;
  std::set<std::pair<domain::Id, int>> user_roles;
  for (const auto& r : usrRls_)
    if (!has(usrs_, r.user_id) || !valid(r.role_code, 3) ||
        !user_roles.insert({r.user_id, static_cast<int>(r.role_code)}).second)
      return false;
  auto has_role = [&](domain::Id user_id, domain::Role role) {
    return user_roles.count({user_id, static_cast<int>(role)}) != 0;
  };
  for (const auto& a : acts_)
    if (!has(usrs_, a.creator_id) || !valid(a.status, 3)) return false;
  std::map<domain::Id, int> current;
  std::map<domain::Id, domain::Id> version_activities;
  std::set<std::pair<domain::Id, int>> version_numbers;
  for (const auto& v : actVers_) {
    if (!has(acts_, v.activity_id) || !valid(v.status, 5) ||
        v.version_number <= 0 ||
        !version_numbers.insert({v.activity_id, v.version_number}).second)
      return false;
    if (v.status == domain::VersionStatus::kCurrentPublished)
      ++current[v.activity_id];
    version_activities[v.id] = v.activity_id;
  }
  for (const auto& activity : acts_) {
    const int count = current[activity.id];
    const bool requires_current =
        activity.status == domain::ActivityStatus::kPublished ||
        activity.status == domain::ActivityStatus::kEnded;
    if ((requires_current && count != 1) || (!requires_current && count != 0))
      return false;
  }
  std::set<std::pair<domain::Id, domain::Id>> ss;
  std::set<std::tuple<domain::Id, domain::Id, domain::Id>> cs;
  std::map<domain::Id, domain::Id> logical_session_activities;
  for (const auto& s : ssns_) {
    if (!has(lSsns_, s.logical_session_id) ||
        !has(actVers_, s.activity_version_id) || s.capacity <= 0 ||
        s.start_time >= s.end_time ||
        s.registration_start >= s.registration_end ||
        s.registration_end > s.start_time ||
        !ss.insert({s.activity_version_id, s.logical_session_id}).second)
      return false;
    const auto activity_id = version_activities[s.activity_version_id];
    const auto mapped = logical_session_activities.find(s.logical_session_id);
    if (mapped != logical_session_activities.end() &&
        mapped->second != activity_id)
      return false;
    logical_session_activities[s.logical_session_id] = activity_id;
  }
  std::map<domain::Id, domain::Id> logical_category_sessions;
  for (const auto& c : catVers_) {
    if (!has(lCats_, c.logical_category_id) ||
        !ss.count({c.activity_version_id, c.logical_session_id}) ||
        c.name.empty() || c.capacity <= 0 ||
        !cs.insert({c.activity_version_id, c.logical_session_id,
                    c.logical_category_id})
             .second)
      return false;
    const auto mapped = logical_category_sessions.find(c.logical_category_id);
    if (mapped != logical_category_sessions.end() &&
        mapped->second != c.logical_session_id)
      return false;
    logical_category_sessions[c.logical_category_id] = c.logical_session_id;
  }
  std::set<std::pair<domain::Id, domain::Id>> grants;
  for (const auto& g : ssnGrs_)
    if (!has(usrs_, g.user_id) || !has(lSsns_, g.logical_session_id) ||
        !valid(g.status, 1) ||
        !grants.insert({g.user_id, g.logical_session_id}).second ||
        (g.status == domain::GrantStatus::kValid &&
         !has_role(g.user_id, domain::Role::kInspector)))
      return false;
  auto logical_session_cancelled = [&](domain::Id id) {
    for (const auto& session : lSsns_)
      if (session.id == id) return session.cancelled;
    return true;
  };
  auto logical_category_cancelled = [&](domain::Id id) {
    for (const auto& category : lCats_)
      if (category.id == id) return category.cancelled;
    return true;
  };
  std::set<std::pair<domain::Id, domain::Id>> active_registrations;
  std::map<std::pair<domain::Id, domain::Id>, int> session_occupancy;
  std::map<std::tuple<domain::Id, domain::Id, domain::Id>, int>
      category_occupancy;
  for (const auto& r : regs_) {
    if (!has(usrs_, r.user_id) ||
        !ss.count({r.activity_version_id, r.logical_session_id}) ||
        !cs.count({r.activity_version_id, r.logical_session_id,
                   r.logical_category_id}) ||
        !valid(r.status, 5))
      return false;
    const bool active = r.status == domain::RegistrationStatus::kRegistered ||
                        r.status == domain::RegistrationStatus::kWaitlisted ||
                        r.status == domain::RegistrationStatus::kCheckedIn;
    if (active &&
        !active_registrations.insert({r.user_id, r.logical_session_id}).second)
      return false;
    if (r.status == domain::RegistrationStatus::kWaitlisted &&
        r.waitlist_sequence <= 0)
      return false;
    if ((r.status == domain::RegistrationStatus::kRegistered ||
         r.status == domain::RegistrationStatus::kWaitlisted) &&
        (logical_session_cancelled(r.logical_session_id) ||
         logical_category_cancelled(r.logical_category_id)))
      return false;
    if (domain::OccupiesSeat(r.status)) {
      ++session_occupancy[{r.activity_version_id, r.logical_session_id}];
      ++category_occupancy[{r.activity_version_id, r.logical_session_id,
                            r.logical_category_id}];
    }
  }
  for (const auto& session : ssns_)
    if (session_occupancy[{session.activity_version_id,
                           session.logical_session_id}] > session.capacity)
      return false;
  for (const auto& category : catVers_)
    if (category_occupancy[{category.activity_version_id,
                            category.logical_session_id,
                            category.logical_category_id}] > category.capacity)
      return false;
  std::map<domain::Id, int> valid_tickets;
  for (const auto& t : tkts_) {
    if (!has(regs_, t.registration_id) || !valid(t.status, 1) ||
        !TicketCodeGenerator::IsValid(t.code) || !codes.insert(t.code).second)
      return false;
    if (t.status == domain::TicketStatus::kValid) {
      if (++valid_tickets[t.registration_id] > 1) return false;
      const auto reg = std::find_if(regs_.begin(), regs_.end(),
                                    [&](const domain::Registration& item) {
                                      return item.id == t.registration_id;
                                    });
      if (reg == regs_.end() ||
          (reg->status != domain::RegistrationStatus::kRegistered &&
           reg->status != domain::RegistrationStatus::kCheckedIn))
        return false;
    }
  }
  for (const auto& registration : regs_) {
    const bool requires_ticket =
        registration.status == domain::RegistrationStatus::kRegistered ||
        registration.status == domain::RegistrationStatus::kCheckedIn;
    if ((requires_ticket && valid_tickets[registration.id] != 1) ||
        (!requires_ticket && valid_tickets[registration.id] != 0))
      return false;
  }
  std::set<domain::Id> checkins;
  for (const auto& e : chkEvs_) {
    const auto reg = std::find_if(regs_.begin(), regs_.end(),
                                  [&](const domain::Registration& item) {
                                    return item.id == e.registration_id;
                                  });
    if (reg == regs_.end() ||
        reg->status != domain::RegistrationStatus::kCheckedIn ||
        !checkins.insert(e.registration_id).second)
      return false;
  }
  for (const auto& registration : regs_)
    if (registration.status == domain::RegistrationStatus::kCheckedIn &&
        checkins.count(registration.id) == 0)
      return false;
  std::set<std::pair<domain::Id, std::string>> notification_events;
  for (const auto& n : ntfs_) {
    if (!has(usrs_, n.user_id) || !valid(n.typ, 6)) return false;
    if (!n.event_id.empty() &&
        !notification_events.insert({n.user_id, n.event_id}).second)
      return false;
  }
  for (const auto& l : audLogs_)
    if (!valid(l.res, 1)) return false;
  std::set<std::string> idempotency_keys;
  for (const auto& record : idemRecs_)
    if (record.ky.empty() || record.op.empty() || record.request_hash.empty() ||
        record.res.empty() || !idempotency_keys.insert(record.ky).second)
      return false;
  for (const auto& t : bgTsks_)
    if (!valid(t.status, 2) || !valid(t.typ, 6) || t.retry_count < 0)
      return false;
  return true;
}

void DataStore::RefreshCounters() {
  cnts_["user"] = MaxId(usrs_);
  cnts_["activity"] = MaxId(acts_);
  cnts_["activity_version"] = MaxId(actVers_);
  cnts_["logical_session"] = MaxId(lSsns_);
  cnts_["session"] = MaxId(ssns_);
  cnts_["logical_category"] = MaxId(lCats_);
  cnts_["category_version"] = MaxId(catVers_);
  cnts_["registration"] = MaxId(regs_);
  cnts_["ticket"] = MaxId(tkts_);
  cnts_["checkin"] = MaxId(chkEvs_);
  cnts_["notification"] = MaxId(ntfs_);
  cnts_["audit_log"] = MaxId(audLogs_);
  cnts_["background_task"] = MaxId(bgTsks_);
}

}
}
