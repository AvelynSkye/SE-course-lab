# 实验三：软件实现与构建

张祎宁 · 241220135 · 校园活动票务与报名系统

基于实验二的用例图、组件图、类图、活动图和两张时序图，实现面向本机使用的 C++17 控制台应用。系统包含普通参与者、组织者、检票员和管理员四类角色，完整覆盖“活动创建与审核发布 → 报名或候补 → 取消与自动递补 → 验票签到 → 名单统计与审计”的主要流程。票据仅作为校园活动入场凭证，不涉及线上付款。

## 安装、构建与验证

在项目根目录打开 PowerShell。已验证环境为 Windows、Visual Studio 2022 Community、MSVC 19.41.34120、CMake 3.29.5、Ninja 1.11.0，项目要求 CMake 3.25 或以上并使用 C++17。

Visual Studio Installer 需要安装“使用 C++ 的桌面开发”，其中包含 MSVC、Windows SDK 和 CMake 工具；风格检查还需要 clang-format。

### 1. 加载编译环境

普通 PowerShell 可以执行：

```powershell
$vsRoot = 'C:\Program Files\Microsoft Visual Studio\2022\Community'
$devShell = Join-Path $vsRoot 'Common7\Tools\Launch-VsDevShell.ps1'
if (!(Test-Path $devShell)) { throw '未找到 Visual Studio 开发环境' }
& $devShell -Arch amd64 -HostArch amd64 -SkipAutomaticLocation

$cmakeBin = Join-Path $vsRoot 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin'
$ninjaBin = Join-Path $vsRoot 'Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja'
$llvmBin = Join-Path $vsRoot 'VC\Tools\Llvm\bin'
$env:PATH = "$cmakeBin;$ninjaBin;$llvmBin;$env:PATH"

Get-Command cl.exe, cmake.exe, ninja.exe, ctest.exe, clang-format.exe
```

也可以直接从开始菜单打开 “Developer PowerShell for VS 2022”，再进入本目录。上述设置只影响当前 PowerShell 会话。

### 2. 配置与编译

```powershell
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
if ($LASTEXITCODE -ne 0) { throw 'CMake 配置失败' }

cmake --build build --parallel
if ($LASTEXITCODE -ne 0) { throw '编译或链接失败' }
```

构建成功后生成：

- `build/campus_ticketing.exe`：主程序；
- `build/campus_tests.exe`：基础业务测试；
- `build/campus_uml_tests.exe`：UML 对照与回归测试。

`build/` 仅包含可重新生成的构建产物。如果项目目录移动后 CMake 提示缓存仍指向旧路径，可以删除 `build/` 后重新执行配置命令，但不要删除业务数据目录 `data/`。

### 3. 运行全部测试

测试会创建和替换临时数据目录。Windows 环境下建议把临时目录设在构建目录内：

```powershell
$env:TEMP = Join-Path (Get-Location) 'build\test-temp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null

ctest --test-dir build -N
ctest --test-dir build --output-on-failure
if ($LASTEXITCODE -ne 0) { throw '测试失败' }
```

当前应列出并执行 36 项测试，即 `campus_tests` 和 `uml_1`～`uml_35`。最近一次测试日志位于 `build/Testing/Temporary/LastTest.log`，失败项记录位于同目录的 `LastTestsFailed.log`。

### 4. 风格检查

项目根目录的 `.clang-format` 基于 Google C++ 风格并采用 80 列限制。配置阶段找到 clang-format 后可以执行：

```powershell
cmake --build build --target format-check
if ($LASTEXITCODE -ne 0) { throw '格式检查失败' }
```

也可以显式检查全部源码和测试，避免其他构建目录中的生成文件被扫描：

```powershell
$sources = @(Get-ChildItem app,domain,infra,service,ui,tests -Recurse -File -Include *.cpp,*.h |
    ForEach-Object { $_.FullName })
$sources += (Resolve-Path .\main.cpp).Path
clang-format --dry-run --Werror -style=file @sources
if ($LASTEXITCODE -ne 0) { throw '源码格式检查失败' }
```

项目还使用 cpplint 2.0.2 做直接头文件依赖专项检查。该工具仅用于代码风格和依赖验证，不参与程序运行：

```powershell
python -m pip install cpplint==2.0.2
$sources = @(Get-ChildItem app,domain,infra,service,ui,tests -Recurse -File -Include *.cpp,*.h |
    ForEach-Object { $_.FullName })
$sources += (Resolve-Path .\main.cpp).Path
python -m cpplint --root=. --filter=-,+build/include_what_you_use @sources
```

完整 cpplint 规则与项目选择的 C++17、命名空间写法等存在规则差异，因此项目以 clang-format、编译器 `/W4` 警告和专项依赖检查为主要风格验证依据。

### 5. 启动程序

必须从项目根目录启动，使程序使用当前目录中的 `data/`：

```powershell
.\build\campus_ticketing.exe
```

不要先进入 `build` 再运行，否则程序会在错误位置寻找或创建 `data/`。角色菜单输入 `0` 返回登录页，登录页再次输入 `0` 正常保存并退出。

C++ 是编译型语言；CMake 负责生成构建配置，Ninja 调度 MSVC 完成编译和链接，CTest 负责注册并运行测试。项目不需要 Python 才能构建或启动，Python 只在可选的 cpplint 检查中使用。

## 从零操作

首次在空数据目录运行时，系统自动创建演示数据。内置演示账号如下，初始密码均为 `123456`：

| 账号 | 角色 | 主要用途 |
| --- | --- | --- |
| `admin` | 管理员 | 审核、账号与角色、检票授权、审计和后台任务 |
| `organizer` | 组织者 | 创建活动、维护场次、送审、发布和统计 |
| `inspector` | 检票员 | 查看授权场次、输入 UUID 凭证验票 |
| `student1` | 普通参与者 | 浏览、报名、取消、查看凭证和通知 |
| `student2` | 普通参与者 | 演示容量不足后的候补和递补 |

首次登录必须修改初始密码，新密码至少6位且不能与初始密码相同。当前控制台不会隐藏密码输入，请只使用实验专用密码。程序采用数字菜单，不是在提示符中输入命令字符串。每个角色菜单中的 `90` 用于修改密码，`91` 查看通知历史，`0` 退出当前登录。

### 四角色菜单入口

| 角色 | 常用菜单 |
| --- | --- |
| 参与者 | 1 浏览活动；2 报名；3 取消报名；4 我的报名；5 凭证；6 通知；7 筛选 |
| 组织者 | 1 活动版本；2 创建；3 编辑草稿；4 场次票额；5 送审；6 发布；7 取消活动；8 统计；9 新版本；11 撤回 |
| 管理员 | 1 审核；2 用户；3 创建账号；4/10 分配或移除角色；5 启停；6/11 授予或撤销检票权限；7 审计；8 后台任务；9 统计 |
| 检票员 | 1 输入凭证签到；2 查看已授权场次 |

### 完整业务演示

以下编号仅说明操作顺序。活动 ID、版本 ID、逻辑场次 ID、类别版本 ID、报名 ID 和用户 ID 是不同编号，必须以程序实际输出为准。

1. 使用 `organizer` 登录并改密，菜单2创建活动，记录活动 ID 和草稿版本 ID。
2. 菜单4进入场次维护，为该版本创建场次并配置唯一票种。地点必须为 `A1`～`A20`，时间格式为 `YYYY-MM-DD HH:MM`。为了演示候补，可把场次容量和票额容量都设为1。
3. 菜单5提交审核并退出。使用 `admin` 登录，菜单1审核通过。审核通过后还需由组织者菜单6正式发布。
4. 使用 `student1` 报名该逻辑场次，系统创建“已报名”记录和 UUID v4 验票凭证。
5. 使用 `student2` 报名同一满额场次，系统创建候补记录并显示候补顺位。
6. 在报名截止和场次开始前，`student1` 取消报名。系统释放名额、递补最早有效候补、作废旧票并为 `student2` 生成新凭证和站内通知。
7. 管理员菜单6把该逻辑场次授权给 `inspector`。在开始前30分钟至结束时间内，检票员输入 `student2` 的完整 UUID 凭证完成首次签到，重复签到会被拒绝。
8. 组织者菜单8或管理员菜单9查询名单统计，并导出到一个尚不存在的 CSV 文件。


## 请求重试和权限

### 报名幂等键

参与者报名时可以填写幂等键，例如：

```text
student1-session-demo-001
```

同一账号、同一逻辑场次和相同请求参数使用原键重试时，系统返回原报名结果，不会再次占位或重复生成票据。同一键配合不同参数会被拒绝。幂等键可以留空，但留空时只依靠“同一场次不能重复有效报名或候补”的业务约束，不提供结果重放保障。取消后重新报名应使用新键。

### 登录与角色权限

- 登录状态保存在当前进程内，退出或账号停用后必须重新登录，不自动重放原操作。
- 15分钟窗口内连续5次登录失败会锁定账号15分钟；对外提示不区分账号不存在、密码错误、停用或锁定。
- 普通参与者只能管理自己的报名、凭证和通知；组织者只能编辑自己创建的活动。
- 管理员不能审核自己创建的活动，审核驳回必须填写原因。
- 检票员必须拥有有效检票员角色和对应逻辑场次授权，且只能在开始前30分钟至结束时间内验票。
- 停用组织者账号或移除组织者角色会自动取消其名下未结束活动，并同步撤销报名、票据和场次授权；若任一活动已进入签到窗口或已有签到记录，整次操作回滚。

### 临近开场和签到后的限制

从当前发布场次开始前30分钟起，时间、地点、场次容量和票额容量被冻结。直接编辑、提交审核和发布复核都会检查该规则，提前准备的旧草稿也不能绕过。

场次已有签到记录后，不能取消场次或活动，也不能修改时间、地点、报名窗口和容量。当前发布场次结束后不能通过新版本改到未来重新开放；已结束场次的票名和票额同样冻结。

## 功能与源码

| 实验二对象/组件 | 实现位置 | 主要行为 |
| --- | --- | --- |
| M1 账号与认证 | `service/auth_service.*`、`infra/security.*` | 登录、强制改密、失败窗口、锁定、启停和停用收尾 |
| M2 角色与授权 | `service/role_service.*` | 四角色、分配移除、场次授权及撤销 |
| M3 活动与版本 | `service/activity_service.*` | 草稿、送审、审核回避、驳回、发布、历史版本和取消 |
| M4 场次与类别 | `service/session_service.*` | 逻辑 ID、地点时间、容量、单票种、冲突及冻结校验 |
| M5 报名与候补 | `service/registration_service.*` | 幂等报名、占位、候补排序、取消和递补 |
| M6 票据与签到 | `service/ticket_service.*` | UUID v4 凭证、作废、验票窗口和首次签到 |
| M7 名单与统计 | `service/stats_service.*` | 到场率、查询快照、名单与 CSV 导出 |
| M8 通知中心 | `service/notification_service.*` | 四类通知、事件去重、未读状态和失败重试 |
| M9 审计与任务 | `service/audit_service.*`、`service/background_task_service.*` | 成功/失败留痕、候补截止、缺席、活动结束和通知重试 |
| 领域实体 | `domain/entities.h`、`domain/enums.*`、`domain/entity_queries.h` | UML 实体、状态枚举和公共查询规则 |
| 数据存储 | `infra/data_store.*`、`infra/csv_util.*` | CSV 保存恢复、临时目录切换、结构与跨表不变量检查 |
| 控制台接入 | `ui/console_*`、`main.cpp`、`app/` | 四角色菜单、服务组装、演示数据和定时维护入口 |

`tests/` 使用隔离临时目录调用真实服务对象，不修改项目中的业务 `data/`。测试既包含基础业务断言，也覆盖幂等重放、并发占位、发布审核、角色权限、签到边界、候补递补、数据损坏拒绝、通知审计和登录锁定等组合场景。

## 测试、代码规模和风格

截至2026年11月26日，MSVC Release 构建成功，CTest 36项全部通过。测试包括1个基础测试程序和35组 UML 对照回归用例；测试项数量不等于断言数量。

本项目仅统计 `app/`、`domain/`、`infra/`、`service/`、`ui/` 和 `main.cpp`：共46个 `.cpp/.h` 文件、7980行、去空行7208行。统计排除测试、构建产物和数据文件，包含预处理指令及少量必要注释，不是严格的有效语句计数；未使用 GUI 设计工具生成代码。

测试重点包括：

- 活动草稿、审核、驳回、撤回、发布、版本迁移和发布前复核；
- 容量互斥、幂等报名、候补排序、取消递补和票据重新生成；
- 场次授权、UUID 验票、时间窗口、重复签到和签到后冻结；
- 参与者、组织者、管理员和检票员的跨角色越权拒绝；
- 登录失败提示统一、15分钟失败窗口、锁定恢复和旧数据兼容；
- CSV 字段往返、公式前缀防护、损坏关联数据拒绝及保存恢复；
- 停用组织者自动取消活动、跨活动失败整体回滚和开场前30分钟冻结。

现有测试没有采集行覆盖率或分支覆盖率，也没有完成真实多用户性能测试，因此“36项通过”不能解释为所有可能输入和线程交错都已穷尽。

## 实现取舍与边界

- 保留实验二的模块划分和状态机，采用模块化单体结构。所有服务共享一个受锁保护的数据仓库，适合本机课程实验，不是跨机器分布式系统。
- 使用 CSV 文件代替服务器数据库。加载时先解析并校验到临时仓库，验证成功后才替换内存数据；保存时先写临时目录再切换，但不承诺硬件断电级持久性。
- 内存业务事务可整体回滚活动、报名、票据、授权、通知和审计；磁盘保存发生在菜单操作后，因此磁盘写入失败时内存修改可能已经成功。
- 当前实现采用“一个活动一种票、每场独立票额”。参与者只选择场次，不选择多个票种；这与实验二图中的多类别表达存在简化。
- 发布新版本时迁移“已报名”和“候补”记录到新版本；已签到记录保留签到时版本。该策略不等于为每条普通报名永久保存完整原始快照。
- 控制台代替 Web 前端，满足实验“不强制图形界面”的要求；未实现浏览器界面、摄像头扫码、多机服务、HTTPS 或独立后台守护进程。
- 后台维护只在程序运行且等待输入时执行，负责候补截止、缺席判定、活动结束和失败通知重试。程序关闭期间不会独立运行，重新启动后补处理到期任务。
- 完整凭证码只向持票人和验票入口展示，不写入名单导出或普通审计详情。名单导出会处理表格公式前缀，避免用户字段被电子表格当作公式执行。
- 密码使用项目自定义摘要以避免明文保存，但不是生产级密码哈希方案。项目假设本机操作系统和数据目录可信，不应保存真实部署密码。


