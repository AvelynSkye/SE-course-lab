

#include "app/seed.h"

#include <cstddef>
#include <string>

#include "app/app_context.h"
#include "domain/datetime.h"
#include "domain/entities.h"
#include "infra/data_store.h"
#include "infra/security.h"
#include "service/ticket_service.h"

namespace campus {
namespace app {

namespace {

domain::Id AddUser(infra::DataStore* db, const std::string& account,
                   const std::string& name, domain::Role rl,
                   bool must_change_password) {
  domain::User usr;
  usr.id = db->NextId("user");
  usr.account = account;
  usr.name = name;
  usr.password_hash = infra::PasswordHasher::Hash(account, "123456");
  usr.status = domain::UserStatus::kActive;
  usr.must_change_password = must_change_password;
  db->usrs().push_back(usr);

  domain::UserRole usrRl;
  usrRl.user_id = usr.id;
  usrRl.role_code = rl;
  db->user_roles().push_back(usrRl);
  return usr.id;
}

domain::Id AddActivity(infra::DataStore* db, const std::string& title,
                       domain::Id creator_id, domain::ActivityStatus status,
                       domain::VersionStatus versionStatus,
                       const std::string& description,
                       domain::Timestamp published_at) {
  domain::Activity act;
  act.id = db->NextId("activity");
  act.title = title;
  act.status = status;
  act.creator_id = creator_id;
  db->acts().push_back(act);

  domain::ActivityVersion ver;
  ver.id = db->NextId("activity_version");
  ver.activity_id = act.id;
  ver.version_number = 1;
  ver.status = versionStatus;
  ver.description = description;
  ver.title = title;
  ver.published_at = published_at;
  db->activity_versions().push_back(ver);
  return ver.id;
}

domain::Id AddSession(infra::DataStore* db, domain::Id activity_version_id,
                      const std::string& location, domain::Timestamp start_time,
                      domain::Timestamp end_time,
                      domain::Timestamp registration_start,
                      domain::Timestamp registration_end, int capacity) {
  domain::LogicalSession lSsn;
  lSsn.id = db->NextId("logical_session");
  lSsn.cancelled = false;
  db->logical_sessions().push_back(lSsn);

  domain::Session ssn;
  ssn.id = db->NextId("session");
  ssn.logical_session_id = lSsn.id;
  ssn.activity_version_id = activity_version_id;
  ssn.location = location;
  ssn.start_time = start_time;
  ssn.end_time = end_time;
  ssn.registration_start = registration_start;
  ssn.registration_end = registration_end;
  ssn.capacity = capacity;
  db->ssns().push_back(ssn);
  return lSsn.id;
}

domain::Id AddCategory(infra::DataStore* db, domain::Id activity_version_id,
                       const std::string& name, int capacity) {
  domain::LogicalCategory lCat;
  lCat.id = db->NextId("logical_category");
  lCat.cancelled = false;
  db->logical_categories().push_back(lCat);

  domain::CategoryVersion cat;
  cat.id = db->NextId("category_version");
  cat.logical_category_id = lCat.id;
  cat.activity_version_id = activity_version_id;
  for (const auto& s : db->ssns())
    if (s.activity_version_id == activity_version_id) {
      cat.logical_session_id = s.logical_session_id;
      break;
    }
  cat.name = name;
  cat.capacity = capacity;
  db->category_versions().push_back(cat);
  return lCat.id;
}

domain::Id AddGrant(infra::DataStore* db, domain::Id inspector_id,
                    domain::Id logical_session_id) {
  domain::SessionGrant grt;
  grt.user_id = inspector_id;
  grt.logical_session_id = logical_session_id;
  grt.status = domain::GrantStatus::kValid;
  db->session_grants().push_back(grt);
  return logical_session_id;
}

domain::Id AddRegistration(infra::DataStore* db, domain::Id user_id,
                           domain::Id logical_session_id,
                           domain::Id logical_category_id,
                           domain::Id activity_version_id,
                           domain::RegistrationStatus status,
                           domain::Timestamp created_at) {
  domain::Registration reg;
  reg.id = db->NextId("registration");
  reg.user_id = user_id;
  reg.logical_session_id = logical_session_id;
  reg.logical_category_id = logical_category_id;
  reg.activity_version_id = activity_version_id;
  reg.status = status;
  reg.waitlist_sequence = 0;
  reg.created_at = created_at;
  reg.cancelled_at = 0;
  db->regs().push_back(reg);
  return reg.id;
}

}

void SeedDemoData(AppContext* ctx) {
  infra::DataStore* db = ctx->db;
  if (!db->usrs().empty()) {
    return;
  }
  const domain::Timestamp ts = domain::Now();

  const domain::Id adm =
      AddUser(db, "admin", "系统管理员", domain::Role::kAdministrator, true);
  (void)adm;
  const domain::Id org =
      AddUser(db, "organizer", "王组织", domain::Role::kOrganizer, true);
  const domain::Id insp =
      AddUser(db, "inspector", "李检票", domain::Role::kInspector, true);
  const domain::Id stu1 = AddUser(db, "student1", "张同学",
                                  domain::Role::kOrdinaryParticipant, true);
  const domain::Id stu2 = AddUser(db, "student2", "李同学",
                                  domain::Role::kOrdinaryParticipant, true);

  const domain::Id ver1 =
      AddActivity(db, "校园歌手大赛", org, domain::ActivityStatus::kPublished,
                  domain::VersionStatus::kCurrentPublished, "校园歌手大赛初赛",
                  domain::AddMinutes(ts, -3 * 24 * 60));
  const domain::Id ssn1 = AddSession(
      db, ver1, "A1", domain::AddMinutes(ts, 24 * 60),
      domain::AddMinutes(ts, 26 * 60), domain::AddMinutes(ts, -2 * 24 * 60),
      domain::AddMinutes(ts, 6 * 60), 3);
  const domain::Id cat1 = AddCategory(db, ver1, "入场券", 1);

  const domain::Id ver2 =
      AddActivity(db, "春日读书会", org, domain::ActivityStatus::kNotPublished,
                  domain::VersionStatus::kDraft, "图书馆共读活动", 0);
  AddSession(db, ver2, "A2", domain::AddMinutes(ts, 3 * 24 * 60),
             domain::AddMinutes(ts, 3 * 24 * 60 + 120),
             domain::AddMinutes(ts, -24 * 60),
             domain::AddMinutes(ts, 2 * 24 * 60), 20);
  AddCategory(db, ver2, "免费票", 20);

  const domain::Id ver3 =
      AddActivity(db, "毕业晚会", org, domain::ActivityStatus::kNotPublished,
                  domain::VersionStatus::kPendingReview, "毕业生欢送晚会", 0);
  AddSession(db, ver3, "A3", domain::AddMinutes(ts, 5 * 24 * 60),
             domain::AddMinutes(ts, 5 * 24 * 60 + 150),
             domain::AddMinutes(ts, -24 * 60),
             domain::AddMinutes(ts, 4 * 24 * 60), 30);
  AddCategory(db, ver3, "入场券", 30);

  const domain::Id ver4 =
      AddActivity(db, "网络安全讲座", org, domain::ActivityStatus::kPublished,
                  domain::VersionStatus::kCurrentPublished, "校园网络安全专题",
                  domain::AddMinutes(ts, -5 * 24 * 60));
  const domain::Id ssn4 = AddSession(
      db, ver4, "A4", domain::AddMinutes(ts, -24 * 60 - 120),
      domain::AddMinutes(ts, -24 * 60), domain::AddMinutes(ts, -5 * 24 * 60),
      domain::AddMinutes(ts, -2 * 24 * 60), 50);
  const domain::Id cat4 = AddCategory(db, ver4, "讲座票", 50);

  const domain::Id ver5 =
      AddActivity(db, "社团招新宣讲", org, domain::ActivityStatus::kPublished,
                  domain::VersionStatus::kCurrentPublished, "社团联合招新",
                  domain::AddMinutes(ts, -6 * 24 * 60));
  const domain::Id ssn5 = AddSession(
      db, ver5, "A5", domain::AddMinutes(ts, -60), domain::AddMinutes(ts, 180),
      domain::AddMinutes(ts, -5 * 24 * 60), domain::AddMinutes(ts, -2 * 60),
      20);
  const domain::Id cat5 = AddCategory(db, ver5, "入场券", 20);

  AddGrant(db, insp, ssn1);
  AddGrant(db, insp, ssn4);
  AddGrant(db, insp, ssn5);

  const domain::Id reg1 = AddRegistration(
      db, stu2, ssn1, cat1, ver1, domain::RegistrationStatus::kRegistered,
      domain::AddMinutes(ts, -24 * 60));
  std::string tktCd;
  ctx->tkts->Issue(reg1, &tktCd);

  const domain::Id reg2 = AddRegistration(
      db, stu1, ssn4, cat4, ver4, domain::RegistrationStatus::kRegistered,
      domain::AddMinutes(ts, -4 * 24 * 60));
  ctx->tkts->Issue(reg2, &tktCd);

  const domain::Id reg3 = AddRegistration(
      db, stu2, ssn5, cat5, ver5, domain::RegistrationStatus::kRegistered,
      domain::AddMinutes(ts, -3 * 24 * 60));
  ctx->tkts->Issue(reg3, &tktCd);
}

}
}
