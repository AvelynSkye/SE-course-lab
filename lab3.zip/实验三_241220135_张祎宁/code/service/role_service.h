

#ifndef SERVICE_ROLE_SERVICE_H_
#define SERVICE_ROLE_SERVICE_H_

#include <set>
#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class ActivityService;
class AuthService;

class RoleService {
 public:
  RoleService(infra::DataStore* db, AuditService* aud);
  void BindActivities(ActivityService* acts) { acts_ = acts; }

  std::vector<domain::Role> RolesOf(domain::Id user_id);
  bool HasRole(domain::Id user_id, domain::Role rl);
  bool Ready(domain::Id user_id);
  bool SignedIn(domain::Id user_id);
  void Open(domain::Id user_id);
  void Close(domain::Id user_id);
  bool CanAccess(domain::Role rl, const std::string& modCd);

  ServiceResult AssignRole(domain::Id operator_id, domain::Id target_user_id,
                           domain::Role rl);
  ServiceResult RemoveRole(domain::Id operator_id, domain::Id target_user_id,
                           domain::Role rl);
  ServiceResult GrantSession(domain::Id operator_id, domain::Id inspector_id,
                             domain::Id logical_session_id);
  ServiceResult RevokeSession(domain::Id operator_id, domain::Id inspector_id,
                              domain::Id logical_session_id);
  std::vector<domain::SessionGrant> GrantsOf(domain::Id user_id);
  bool HasValidGrant(domain::Id inspector_id, domain::Id logical_session_id);
  bool UserExists(domain::Id user_id);

 private:
  friend class AuthService;
  ServiceResult CancelOwnedActivitiesForAccountDisable(
      domain::Id operator_id, domain::Id organizer_id,
      int* cancelled_activities);

  infra::DataStore* db_;
  AuditService* aud_;
  ActivityService* acts_ = nullptr;
  std::set<domain::Id> ins_;
};

}
}

#endif
