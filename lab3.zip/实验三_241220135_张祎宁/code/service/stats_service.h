

#ifndef SERVICE_STATS_SERVICE_H_
#define SERVICE_STATS_SERVICE_H_

#include <map>
#include <memory>
#include <string>
#include <vector>

#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class RoleService;
class AuditService;

struct StatResult {
  domain::Id activity_id = 0;
  std::string title;
  int regN = 0;
  int chkN = 0;
  int wlN = 0;
  int cancelled = 0;
  int absN = 0;
  int expN = 0;
  double attRt = 0.0;

  std::string ToString() const;
};

class StatsService {
 public:
  StatsService(infra::DataStore* db, RoleService* rls, AuditService* aud);

  std::vector<StatResult> QueryStats(domain::Id user_id,
                                     domain::Id activity_id);
  ServiceResult ExportRoster(domain::Id user_id, domain::Id activity_id,
                             const std::string& pth, std::string* sum);

 private:
  infra::DataStore* db_;
  RoleService* rls_;
  AuditService* aud_;
  std::map<std::pair<domain::Id, domain::Id>, std::shared_ptr<infra::DataStore>>
      snaps_;
};

}
}

#endif
