

#ifndef SERVICE_AUTH_SERVICE_H_
#define SERVICE_AUTH_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class RoleService;

class AuthService {
 public:
  AuthService(infra::DataStore* db, AuditService* aud, RoleService* rls);

  ServiceResult Login(const std::string& account, const std::string& pwd,
                      domain::Id* user_id);
  ServiceResult ChangePassword(domain::Id user_id, const std::string& oldPwd,
                               const std::string& newPwd);
  ServiceResult CreateAccount(domain::Id operator_id,
                              const std::string& account,
                              const std::string& name, const std::string& pwd,
                              domain::Role rl, domain::Id* user_id);
  ServiceResult SetStatus(domain::Id operator_id, domain::Id user_id,
                          domain::UserStatus status);

  domain::User* FindUser(domain::Id user_id);
  domain::User* FindByAccount(const std::string& account);
  std::vector<domain::User> AllUsers(domain::Id user_id);

 private:
  bool IsLocked(const domain::User& usr);

  infra::DataStore* db_;
  AuditService* aud_;
  RoleService* rls_;

  static constexpr int kMaxFailCount = 5;
  static constexpr int kLockMinutes = 15;
  static constexpr int kFailWindowMinutes = 15;
  static constexpr int kMinPasswordLength = 6;
};

}
}

#endif
