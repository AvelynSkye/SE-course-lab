

#ifndef SERVICE_SESSION_SERVICE_H_
#define SERVICE_SESSION_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class NotificationService;
class RoleService;
class TicketService;

class SessionService {
 public:
  SessionService(infra::DataStore* db, RoleService* rls, AuditService* aud,
                 NotificationService* ntfs, TicketService* tkts);

  ServiceResult CreateSession(domain::Id organizer_id,
                              domain::Id activity_version_id,
                              const std::string& location,
                              domain::Timestamp start_time,
                              domain::Timestamp end_time,
                              domain::Timestamp registration_start,
                              domain::Timestamp registration_end, int capacity,
                              domain::Id* logical_session_id);
  ServiceResult CreateCategory(domain::Id organizer_id,
                               domain::Id activity_version_id,
                               domain::Id logical_session_id,
                               const std::string& name, int capacity,
                               domain::Id* logical_category_id);
  ServiceResult UpdateSession(domain::Id organizer_id,
                              domain::Id activity_version_id,
                              domain::Id logical_session_id,
                              const std::string& location,
                              domain::Timestamp start_time,
                              domain::Timestamp end_time,
                              domain::Timestamp registration_start,
                              domain::Timestamp registration_end, int capacity);
  ServiceResult UpdateCategory(domain::Id organizer_id,
                               domain::Id category_version_id,
                               const std::string& name, int capacity);
  ServiceResult UpdateCategoryQuota(domain::Id organizer_id,
                                    domain::Id category_version_id,
                                    int capacity);
  ServiceResult CancelSession(domain::Id organizer_id,
                              domain::Id logical_session_id);
  ServiceResult CancelCategory(domain::Id organizer_id,
                               domain::Id logical_category_id);

  std::vector<domain::Session> SessionsOfVersion(
      domain::Id activity_version_id);
  std::vector<domain::CategoryVersion> CategoriesOfVersion(
      domain::Id activity_version_id);
  std::vector<domain::LogicalSession> AllLogicalSessions();
  domain::Session* FindSession(domain::Id logical_session_id,
                               domain::Id activity_version_id);
  domain::CategoryVersion* FindCategory(domain::Id logical_category_id,
                                        domain::Id activity_version_id);
  domain::LogicalSession* FindLogicalSession(domain::Id logical_session_id);
  domain::LogicalCategory* FindLogicalCategory(domain::Id logical_category_id);
  bool VersionEditable(domain::Id organizer_id, domain::Id activity_version_id,
                       std::string* rsn);

 private:
  infra::DataStore* db_;
  RoleService* rls_;
  AuditService* aud_;
  NotificationService* ntfs_;
  TicketService* tkts_;
};

}
}

#endif
