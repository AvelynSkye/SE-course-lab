

#include "service/audit_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "infra/data_store.h"
#include "service/role_service.h"

namespace campus {
namespace service {

AuditService::AuditService(infra::DataStore* db) : db_(db) {}

ServiceResult AuditService::Fail(domain::Id user_id, const std::string& actn,
                                 const std::string& det) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  Log(user_id, actn, domain::AuditResult::kFailure, det);
  return ServiceResult::Fail(det);
}

void AuditService::Log(domain::Id user_id, const std::string& actn,
                       domain::AuditResult res, const std::string& det) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  domain::AuditLog lg;
  lg.id = db_->NextId("audit_log");
  lg.user_id = user_id;
  lg.actn = actn;
  lg.res = res;
  lg.det = det;
  lg.created_at = domain::Now();
  db_->audit_logs().push_back(lg);
}

std::vector<domain::AuditLog> AuditService::Recent(domain::Id user_id,
                                                   int lim) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::AuditLog> res;
  if (rls_ == nullptr || !rls_->Ready(user_id) ||
      !rls_->HasRole(user_id, domain::Role::kAdministrator)) {
    Fail(user_id, "查看审计", "无权限");
    return res;
  }
  const std::vector<domain::AuditLog>& lgs = db_->audit_logs();
  if (lim <= 0) {
    Log(user_id, "查看审计", domain::AuditResult::kSuccess,
        std::to_string(lim));
    return res;
  }
  std::size_t pos = 0;
  if (lgs.size() > static_cast<std::size_t>(lim)) {
    pos = lgs.size() - static_cast<std::size_t>(lim);
  }
  for (std::size_t i = pos; i < lgs.size(); ++i) {
    res.push_back(lgs[i]);
  }
  Log(user_id, "查看审计", domain::AuditResult::kSuccess, std::to_string(lim));
  return res;
}

}
}
