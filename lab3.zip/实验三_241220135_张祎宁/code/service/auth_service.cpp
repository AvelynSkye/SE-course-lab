

#include "service/auth_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "domain/entity_queries.h"
#include "infra/data_store.h"
#include "infra/security.h"
#include "service/audit_service.h"
#include "service/role_service.h"

namespace campus {
namespace service {

AuthService::AuthService(infra::DataStore* db, AuditService* aud,
                         RoleService* rls)
    : db_(db), aud_(aud), rls_(rls) {}

bool AuthService::IsLocked(const domain::User& usr) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  return usr.locked_until > domain::Now();
}

ServiceResult AuthService::Login(const std::string& account,
                                 const std::string& pwd, domain::Id* user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  const auto generic_failure = [] {
    return ServiceResult::Fail(
        "登录失败：账号或密码错误、账号不可用，或尝试过于频繁");
  };
  domain::User* usr = FindByAccount(account);
  if (usr == nullptr) {
    const auto dummy_hash =
        infra::PasswordHasher::Hash("missing-account", "dummy-password");
    (void)infra::PasswordHasher::Verify("missing-account", pwd, dummy_hash);
    aud_->Log(0, "登录", domain::AuditResult::kFailure, "未知账号或密码错误");
    return generic_failure();
  }
  if (usr->status == domain::UserStatus::kDisabled) {
    aud_->Log(usr->id, "登录", domain::AuditResult::kFailure, "账号已停用");
    return generic_failure();
  }
  if (IsLocked(*usr)) {
    aud_->Log(usr->id, "登录", domain::AuditResult::kFailure, "账号锁定中");
    return generic_failure();
  }
  const auto ts = domain::Now();
  if (usr->locked_until != 0 && usr->locked_until <= ts) {
    usr->locked_until = 0;
    usr->failed_login_count = 0;
    usr->failed_login_window_start = 0;
  }
  if (!infra::PasswordHasher::Verify(account, pwd, usr->password_hash)) {
    if (usr->failed_login_window_start == 0 ||
        ts < usr->failed_login_window_start ||
        ts >= domain::AddMinutes(usr->failed_login_window_start,
                                 kFailWindowMinutes)) {
      usr->failed_login_count = 0;
      usr->failed_login_window_start = ts;
    }
    ++usr->failed_login_count;
    if (usr->failed_login_count >= kMaxFailCount) {
      usr->locked_until = domain::AddMinutes(ts, kLockMinutes);
      usr->failed_login_count = 0;
      usr->failed_login_window_start = 0;
      aud_->Log(usr->id, "登录", domain::AuditResult::kFailure,
                "连续失败触发锁定");
      return generic_failure();
    }
    aud_->Log(usr->id, "登录", domain::AuditResult::kFailure, "密码错误");
    return generic_failure();
  }
  usr->failed_login_count = 0;
  usr->locked_until = 0;
  usr->failed_login_window_start = 0;
  *user_id = usr->id;
  rls_->Open(usr->id);
  aud_->Log(usr->id, "登录", domain::AuditResult::kSuccess, account);
  if (usr->must_change_password) {
    return ServiceResult::Ok("登录成功，首次登录需修改初始密码");
  }
  return ServiceResult::Ok("登录成功，欢迎 " + usr->name);
}

ServiceResult AuthService::ChangePassword(domain::Id user_id,
                                          const std::string& oldPwd,
                                          const std::string& newPwd) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(user_id, "修改密码", msg);
  };
  if (!rls_->SignedIn(user_id)) return fail("请重新登录后改密");
  domain::User* usr = FindUser(user_id);
  if (usr == nullptr) {
    return fail("用户不存在");
  }
  if (!infra::PasswordHasher::Verify(usr->account, oldPwd,
                                     usr->password_hash)) {
    return fail("原密码错误");
  }
  if (newPwd.size() < static_cast<std::size_t>(kMinPasswordLength)) {
    return fail("新密码长度不能少于 " + std::to_string(kMinPasswordLength) +
                " 位");
  }
  if (newPwd == oldPwd) {
    return fail("新密码不能与原密码相同");
  }
  usr->password_hash = infra::PasswordHasher::Hash(usr->account, newPwd);
  usr->must_change_password = false;
  aud_->Log(user_id, "修改密码", domain::AuditResult::kSuccess, "密码已更新");
  return ServiceResult::Ok("密码修改成功");
}

ServiceResult AuthService::CreateAccount(domain::Id operator_id,
                                         const std::string& account,
                                         const std::string& name,
                                         const std::string& pwd,
                                         domain::Role rl, domain::Id* user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(operator_id, "创建账号", msg);
  };
  if (!rls_->Ready(operator_id) ||
      !rls_->HasRole(operator_id, domain::Role::kAdministrator)) {
    return fail("仅管理员可以创建账号");
  }
  if (account.empty() || name.empty()) {
    return fail("账号与姓名不能为空");
  }
  if (FindByAccount(account) != nullptr) {
    return fail("账号已存在");
  }
  if (pwd.size() < static_cast<std::size_t>(kMinPasswordLength)) {
    return fail("初始密码长度不能少于 6 位");
  }
  domain::User usr;
  usr.id = db_->NextId("user");
  usr.account = account;
  usr.name = name;
  usr.password_hash = infra::PasswordHasher::Hash(account, pwd);
  usr.status = domain::UserStatus::kActive;
  usr.must_change_password = true;
  usr.failed_login_count = 0;
  usr.locked_until = 0;
  usr.failed_login_window_start = 0;
  db_->usrs().push_back(usr);

  domain::UserRole usrRl;
  usrRl.user_id = usr.id;
  usrRl.role_code = rl;
  db_->user_roles().push_back(usrRl);

  *user_id = usr.id;
  aud_->Log(operator_id, "创建账号", domain::AuditResult::kSuccess,
            account + " / " + domain::ToString(rl));
  return ServiceResult::Ok("账号创建成功，初始密码需首次登录后修改");
}

ServiceResult AuthService::SetStatus(domain::Id operator_id, domain::Id user_id,
                                     domain::UserStatus status) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(operator_id, "修改账号状态", msg);
  };
  if (!rls_->Ready(operator_id) ||
      !rls_->HasRole(operator_id, domain::Role::kAdministrator)) {
    return fail("仅管理员可以修改账号状态");
  }
  if (operator_id == user_id) {
    return fail("不能修改自己的账号状态");
  }
  domain::User* usr = FindUser(user_id);
  if (usr == nullptr) {
    return fail("用户不存在");
  }
  infra::Transaction tx(db_);
  int cancelled_activities = 0;
  if (status == domain::UserStatus::kDisabled &&
      rls_->HasRole(user_id, domain::Role::kOrganizer)) {
    const auto cancelled = rls_->CancelOwnedActivitiesForAccountDisable(
        operator_id, user_id, &cancelled_activities);
    if (!cancelled.ok) {
      tx.Rollback();
      return fail("名下活动无法自动取消，账号未停用：" + cancelled.msg);
    }
  }
  usr->status = status;
  if (status == domain::UserStatus::kDisabled) rls_->Close(user_id);
  aud_->Log(operator_id, "修改账号状态", domain::AuditResult::kSuccess,
            usr->account + " -> " + domain::ToString(status) +
                "，自动取消活动 " + std::to_string(cancelled_activities) +
                " 个");
  tx.Commit();
  std::string message = "账号状态已更新为" + domain::ToString(status);
  if (status == domain::UserStatus::kDisabled) {
    message += "，已有票暂不可使用";
    if (cancelled_activities > 0) message += "，名下未结束活动已自动取消";
  } else {
    message += "，未取消、未过期的票恢复可用";
  }
  return ServiceResult::Ok(message);
}

domain::User* AuthService::FindUser(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::User>& usrs = db_->usrs();
  return domain::FindById(usrs, user_id);
}

domain::User* AuthService::FindByAccount(const std::string& account) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::User>& usrs = db_->usrs();
  for (std::size_t i = 0; i < usrs.size(); ++i) {
    if (usrs[i].account == account) {
      return &usrs[i];
    }
  }
  return nullptr;
}

std::vector<domain::User> AuthService::AllUsers(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(user_id) ||
      !rls_->HasRole(user_id, domain::Role::kAdministrator)) {
    aud_->Fail(user_id, "查看用户", "无权限");
    return {};
  }
  aud_->Log(user_id, "查看用户", domain::AuditResult::kSuccess, "用户列表");
  return db_->usrs();
}

}
}
