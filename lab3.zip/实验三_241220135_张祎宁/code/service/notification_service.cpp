

#include "service/notification_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "infra/data_store.h"
#include "infra/security.h"
#include "service/audit_service.h"
#include "service/role_service.h"

namespace campus {
namespace service {

NotificationService::NotificationService(infra::DataStore* db,
                                         AuditService* aud, RoleService* rls)
    : db_(db), aud_(aud), rls_(rls) {}

std::vector<domain::Notification> NotificationService::History(
    domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Notification> res;
  if (!rls_->Ready(user_id)) {
    aud_->Fail(user_id, "查看通知", "请先登录并完成改密");
    return res;
  }
  for (const auto& n : db_->ntfs())
    if (n.user_id == user_id) res.push_back(n);
  aud_->Log(user_id, "查看通知历史", domain::AuditResult::kSuccess,
            std::to_string(res.size()));
  return res;
}

bool NotificationService::Notify(domain::Id user_id,
                                 domain::NotificationType typ,
                                 const std::string& cnt,
                                 const std::string& event_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  const std::string ky =
      event_id.empty() ? infra::UuidGenerator::V4() : event_id;
  if (Deliver(user_id, typ, cnt, ky)) return true;
  for (const auto& t : db_->background_tasks()) {
    if (t.task_type == "notification_retry" && t.pl == ky &&
        t.user_id == user_id)
      return false;
  }
  domain::BackgroundTask t;
  t.id = db_->NextId("background_task");
  t.task_type = "notification_retry";
  t.pl = ky;
  t.user_id = user_id;
  t.typ = typ;
  t.cnt = cnt;
  t.status = domain::TaskStatus::kFailed;
  db_->background_tasks().push_back(t);
  return false;
}

bool NotificationService::Deliver(domain::Id user_id,
                                  domain::NotificationType typ,
                                  const std::string& cnt,
                                  const std::string& event_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (event_id.empty() || cnt.empty()) {
    aud_->Log(0, "投递通知", domain::AuditResult::kFailure,
              "事件 ID 或内容为空");
    return false;
  }
  for (const auto& n : db_->ntfs()) {
    if (n.user_id == user_id && n.event_id == event_id) return true;
  }
  bool ok = false;
  for (const auto& u : db_->usrs()) {
    if (u.id == user_id && u.status == domain::UserStatus::kActive) ok = true;
  }
  if (!ok) {
    aud_->Log(0, "投递通知", domain::AuditResult::kFailure,
              "接收账号不存在或已停用：" + event_id);
    return false;
  }
  domain::Notification ntf;
  ntf.id = db_->NextId("notification");
  ntf.user_id = user_id;
  ntf.typ = typ;
  ntf.cnt = cnt;
  ntf.read = false;
  ntf.created_at = domain::Now();
  ntf.event_id = event_id;
  db_->ntfs().push_back(ntf);
  aud_->Log(0, "投递通知", domain::AuditResult::kSuccess, event_id);
  return true;
}

std::vector<domain::Notification> NotificationService::Unread(
    domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(user_id)) {
    aud_->Fail(user_id, "访问通知", "请先登录并完成改密");
    return {};
  }
  aud_->Log(user_id, "访问通知", domain::AuditResult::kSuccess,
            "通知查询或标记");
  std::vector<domain::Notification> res;
  std::vector<domain::Notification>& xsAll = db_->ntfs();
  for (std::size_t i = 0; i < xsAll.size(); ++i) {
    if (xsAll[i].user_id == user_id && !xsAll[i].read) {
      res.push_back(xsAll[i]);
    }
  }
  return res;
}

int NotificationService::UnreadCount(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(user_id)) {
    aud_->Fail(user_id, "访问通知", "请先登录并完成改密");
    return {};
  }
  aud_->Log(user_id, "访问通知", domain::AuditResult::kSuccess,
            "通知查询或标记");
  int n = 0;
  std::vector<domain::Notification>& xsAll = db_->ntfs();
  for (std::size_t i = 0; i < xsAll.size(); ++i) {
    if (xsAll[i].user_id == user_id && !xsAll[i].read) {
      ++n;
    }
  }
  return n;
}

bool NotificationService::MarkRead(domain::Id user_id, domain::Id nid) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(user_id)) {
    aud_->Fail(user_id, "访问通知", "请先登录并完成改密");
    return {};
  }
  aud_->Log(user_id, "访问通知", domain::AuditResult::kSuccess,
            "通知查询或标记");
  std::vector<domain::Notification>& xsAll = db_->ntfs();
  for (std::size_t i = 0; i < xsAll.size(); ++i) {
    if (xsAll[i].id == nid && xsAll[i].user_id == user_id) {
      xsAll[i].read = true;
      aud_->Log(user_id, "阅读通知", domain::AuditResult::kSuccess,
                std::to_string(nid));
      return true;
    }
  }
  aud_->Log(user_id, "阅读通知", domain::AuditResult::kFailure,
            "通知不存在或不属于当前用户：" + std::to_string(nid));
  return false;
}

int NotificationService::MarkAllRead(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(user_id)) {
    aud_->Fail(user_id, "访问通知", "请先登录并完成改密");
    return {};
  }
  aud_->Log(user_id, "访问通知", domain::AuditResult::kSuccess,
            "通知查询或标记");
  int n = 0;
  std::vector<domain::Notification>& xsAll = db_->ntfs();
  for (std::size_t i = 0; i < xsAll.size(); ++i) {
    if (xsAll[i].user_id == user_id && !xsAll[i].read) {
      xsAll[i].read = true;
      ++n;
    }
  }
  aud_->Log(user_id, "全部通知已读", domain::AuditResult::kSuccess,
            std::to_string(n));
  return n;
}

}
}
