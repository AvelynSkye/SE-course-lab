

#include "service/session_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "domain/entity_queries.h"
#include "domain/venue.h"
#include "infra/data_store.h"
#include "service/audit_service.h"
#include "service/notification_service.h"
#include "service/role_service.h"
#include "service/ticket_service.h"

namespace campus {
namespace service {

namespace {

bool OwnsVersion(const std::vector<domain::ActivityVersion>& vers,
                 const std::vector<domain::Activity>& acts,
                 domain::Id activity_version_id, domain::Id organizer_id) {
  for (std::size_t i = 0; i < vers.size(); ++i) {
    if (vers[i].id != activity_version_id) {
      continue;
    }
    for (std::size_t j = 0; j < acts.size(); ++j) {
      if (acts[j].id == vers[i].activity_id) {
        return acts[j].creator_id == organizer_id;
      }
    }
  }
  return false;
}

int ActiveRegistrationCount(const std::vector<domain::Registration>& xs,
                            domain::Id logical_session_id,
                            domain::Id logical_category_id) {
  int n = 0;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    const domain::Registration& x = xs[i];
    if (x.logical_session_id != logical_session_id) {
      continue;
    }
    if (logical_category_id != 0 &&
        x.logical_category_id != logical_category_id) {
      continue;
    }
    if (domain::OccupiesSeat(x.status)) {
      ++n;
    }
  }
  return n;
}

bool HasCheckIn(infra::DataStore* db, domain::Id logical_session_id) {
  for (const auto& reg : db->regs()) {
    if (reg.logical_session_id != logical_session_id) continue;
    if (reg.status == domain::RegistrationStatus::kCheckedIn) return true;
    for (const auto& event : db->checkin_events()) {
      if (event.registration_id == reg.id) return true;
    }
  }
  return false;
}

const domain::Session* CurrentPublishedSessionForCandidate(
    infra::DataStore* db, domain::Id candidate_version_id,
    domain::Id logical_session_id) {
  const auto* candidate =
      domain::FindById(db->activity_versions(), candidate_version_id);
  if (candidate == nullptr) return nullptr;
  for (const auto& version : db->activity_versions()) {
    if (version.activity_id != candidate->activity_id ||
        version.status != domain::VersionStatus::kCurrentPublished)
      continue;
    for (const auto& session : db->ssns())
      if (session.activity_version_id == version.id &&
          session.logical_session_id == logical_session_id)
        return &session;
  }
  return nullptr;
}

bool FrozenSessionFieldsChanged(const domain::Session& current,
                                const std::string& location,
                                domain::Timestamp start_time,
                                domain::Timestamp end_time, int capacity) {
  const auto now = domain::Now();
  const bool frozen = now >= domain::AddMinutes(current.start_time, -30) ||
                      now >= domain::AddMinutes(start_time, -30);
  return frozen &&
         (current.location != location || current.start_time != start_time ||
          current.end_time != end_time || current.capacity != capacity);
}

bool Ended(infra::DataStore* db, domain::Id sid) {
  const domain::Session* selected = nullptr;
  bool published = false;
  for (const auto& s : db->ssns()) {
    if (s.logical_session_id != sid) continue;
    for (const auto& v : db->activity_versions()) {
      if (v.id != s.activity_version_id) continue;
      const bool current = v.status == domain::VersionStatus::kCurrentPublished;
      if (selected == nullptr || (current && !published) ||
          (current == published &&
           s.activity_version_id > selected->activity_version_id)) {
        selected = &s;
        published = current;
      }
    }
  }
  return selected == nullptr || selected->end_time <= domain::Now();
}

}

SessionService::SessionService(infra::DataStore* db, RoleService* rls,
                               AuditService* aud, NotificationService* ntfs,
                               TicketService* tkts)
    : db_(db), rls_(rls), aud_(aud), ntfs_(ntfs), tkts_(tkts) {}

bool SessionService::VersionEditable(domain::Id organizer_id,
                                     domain::Id activity_version_id,
                                     std::string* rsn) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    *rsn = "请以有效组织者账号登录并完成改密";
    return false;
  }
  domain::ActivityVersion* ver = nullptr;
  std::vector<domain::ActivityVersion>& vers = db_->activity_versions();
  for (std::size_t i = 0; i < vers.size(); ++i) {
    if (vers[i].id == activity_version_id) {
      ver = &vers[i];
      break;
    }
  }
  if (ver == nullptr) {
    *rsn = "活动版本不存在";
    return false;
  }
  if (ver->status != domain::VersionStatus::kDraft &&
      ver->status != domain::VersionStatus::kReviewRejected) {
    *rsn = "当前版本状态为" + domain::ToString(ver->status) + "，不允许编辑";
    return false;
  }
  std::vector<domain::Activity>& acts = db_->acts();
  for (std::size_t i = 0; i < acts.size(); ++i) {
    if (acts[i].id == ver->activity_id) {
      if (acts[i].status == domain::ActivityStatus::kCancelled ||
          acts[i].status == domain::ActivityStatus::kEnded) {
        *rsn = "活动已取消或结束，不能编辑";
        return false;
      }
      if (acts[i].creator_id != organizer_id) {
        *rsn = "只能维护自己创建的活动";
        return false;
      }
      return true;
    }
  }
  *rsn = "活动不存在";
  return false;
}

ServiceResult SessionService::CreateSession(
    domain::Id organizer_id, domain::Id activity_version_id,
    const std::string& location, domain::Timestamp start_time,
    domain::Timestamp end_time, domain::Timestamp registration_start,
    domain::Timestamp registration_end, int capacity,
    domain::Id* logical_session_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "创建场次", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    return fail("仅组织者可以维护场次");
  }
  std::string rsn;
  if (!VersionEditable(organizer_id, activity_version_id, &rsn)) {
    return fail(rsn);
  }
  if (!domain::ValidVenue(location)) {
    return fail("场次地点必须为 A1 至 A20");
  }
  if (start_time >= end_time) {
    return fail("场次结束时间必须晚于开始时间");
  }
  if (registration_start >= registration_end) {
    return fail("报名截止时间必须晚于报名开始时间");
  }
  if (registration_end > start_time) {
    return fail("报名截止时间不能晚于场次开始时间");
  }
  if (capacity <= 0) {
    return fail("场次容量必须大于 0");
  }

  domain::LogicalSession lSsn;
  lSsn.id = db_->NextId("logical_session");
  lSsn.cancelled = false;
  db_->logical_sessions().push_back(lSsn);

  domain::Session ssn;
  ssn.id = db_->NextId("session");
  ssn.logical_session_id = lSsn.id;
  ssn.activity_version_id = activity_version_id;
  ssn.location = location;
  ssn.start_time = start_time;
  ssn.end_time = end_time;
  ssn.registration_start = registration_start;
  ssn.registration_end = registration_end;
  ssn.capacity = capacity;
  db_->ssns().push_back(ssn);

  *logical_session_id = lSsn.id;
  aud_->Log(organizer_id, "创建场次", domain::AuditResult::kSuccess,
            "版本 " + std::to_string(activity_version_id) + " 场次 " +
                std::to_string(lSsn.id) + " " + location);
  return ServiceResult::Ok("场次创建成功，逻辑场次 ID：" +
                           std::to_string(lSsn.id));
}

ServiceResult SessionService::CreateCategory(domain::Id organizer_id,
                                             domain::Id activity_version_id,
                                             domain::Id logical_session_id,
                                             const std::string& name,
                                             int capacity,
                                             domain::Id* logical_category_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "创建类别", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    return fail("仅组织者可以维护类别");
  }
  std::string rsn;
  if (!VersionEditable(organizer_id, activity_version_id, &rsn)) {
    return fail(rsn);
  }
  if (name.empty()) {
    return fail("类别名称不能为空");
  }
  auto* ssn = FindSession(logical_session_id, activity_version_id);
  auto* ls = FindLogicalSession(logical_session_id);
  if (ssn == nullptr || ls == nullptr || ls->cancelled)
    return fail("请选择该版本内有效的场次");
  if (capacity <= 0) {
    return fail("类别名额必须大于 0");
  }
  for (const auto& c : db_->category_versions()) {
    const auto* lc = FindLogicalCategory(c.logical_category_id);
    const auto* ls = FindLogicalSession(c.logical_session_id);
    if (c.activity_version_id != activity_version_id || lc == nullptr ||
        lc->cancelled || ls == nullptr || ls->cancelled)
      continue;
    if (c.logical_session_id == logical_session_id)
      return fail("该场次已配置票额，不能添加第二种票");
    if (c.name != name)
      return fail("同一活动的所有场次必须使用同一种票：" + c.name);
  }

  domain::LogicalCategory lCat;
  lCat.id = db_->NextId("logical_category");
  lCat.cancelled = false;
  db_->logical_categories().push_back(lCat);

  domain::CategoryVersion cat;
  cat.id = db_->NextId("category_version");
  cat.logical_category_id = lCat.id;
  cat.activity_version_id = activity_version_id;
  cat.logical_session_id = logical_session_id;
  cat.name = name;
  cat.capacity = capacity;
  db_->category_versions().push_back(cat);

  *logical_category_id = lCat.id;
  aud_->Log(organizer_id, "创建类别", domain::AuditResult::kSuccess,
            "版本 " + std::to_string(activity_version_id) + " 类别 " + name);
  return ServiceResult::Ok("类别创建成功，逻辑类别 ID：" +
                           std::to_string(lCat.id));
}

ServiceResult SessionService::UpdateSession(
    domain::Id organizer_id, domain::Id activity_version_id,
    domain::Id logical_session_id, const std::string& location,
    domain::Timestamp start_time, domain::Timestamp end_time,
    domain::Timestamp registration_start, domain::Timestamp registration_end,
    int capacity) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "编辑场次", msg);
  };
  std::string rsn;
  if (!VersionEditable(organizer_id, activity_version_id, &rsn))
    return fail(rsn);
  auto* s = FindSession(logical_session_id, activity_version_id);
  auto* l = FindLogicalSession(logical_session_id);
  if (s == nullptr || l == nullptr || l->cancelled)
    return fail("场次不存在或已取消");
  const auto* current = CurrentPublishedSessionForCandidate(
      db_, activity_version_id, logical_session_id);
  if (current != nullptr &&
      FrozenSessionFieldsChanged(*current, location, start_time, end_time,
                                 capacity))
    return fail("场次已进入开始前30分钟冻结期，不能修改时间、地点或容量");
  if (HasCheckIn(db_, logical_session_id))
    return fail("场次已有签到记录，时间、地点及容量不能修改");
  if (s->end_time <= domain::Now()) return fail("已结束场次不能修改");
  if (!domain::ValidVenue(location) || start_time >= end_time ||
      registration_start >= registration_end || registration_end > start_time ||
      capacity <= 0)
    return fail("地点须为 A1 至 A20，且时间、容量必须合法");
  if (capacity < ActiveRegistrationCount(db_->regs(), logical_session_id, 0))
    return fail("容量不能小于已占用人数");
  s->location = location;
  s->start_time = start_time;
  s->end_time = end_time;
  s->registration_start = registration_start;
  s->registration_end = registration_end;
  s->capacity = capacity;
  aud_->Log(organizer_id, "编辑场次", domain::AuditResult::kSuccess,
            std::to_string(s->id));
  return ServiceResult::Ok("场次已更新");
}

ServiceResult SessionService::UpdateCategory(domain::Id organizer_id,
                                             domain::Id category_version_id,
                                             const std::string& name,
                                             int capacity) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (name.empty())
    return aud_->Fail(organizer_id, "编辑类别", "类别名称不能为空");
  domain::Id activity_version_id = 0;
  for (const auto& c : db_->category_versions())
    if (c.id == category_version_id)
      activity_version_id = c.activity_version_id;
  if (activity_version_id != 0) {
    for (const auto& c : db_->category_versions()) {
      if (c.activity_version_id != activity_version_id || c.name == name)
        continue;
      const auto* session =
          FindSession(c.logical_session_id, activity_version_id);
      if (session != nullptr && session->end_time <= domain::Now())
        return aud_->Fail(organizer_id, "编辑类别",
                          "本版本包含已结束场次，不能统一修改票名");
    }
  }
  auto res = UpdateCategoryQuota(organizer_id, category_version_id, capacity);
  if (!res.ok) return res;
  for (auto& c : db_->category_versions())
    if (c.activity_version_id == activity_version_id) c.name = name;
  aud_->Log(organizer_id, "编辑类别", domain::AuditResult::kSuccess,
            std::to_string(category_version_id));
  return ServiceResult::Ok(
      "本版本所有场次的票名已统一更新，所选场次名额已更新");
}

ServiceResult SessionService::UpdateCategoryQuota(
    domain::Id organizer_id, domain::Id category_version_id, int capacity) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "调整类别名额", msg);
  };
  std::vector<domain::CategoryVersion>& cats = db_->category_versions();
  domain::CategoryVersion* tgt = nullptr;
  for (std::size_t i = 0; i < cats.size(); ++i) {
    if (cats[i].id == category_version_id) {
      tgt = &cats[i];
      break;
    }
  }
  if (tgt == nullptr) {
    return fail("类别版本不存在");
  }
  auto* lc = FindLogicalCategory(tgt->logical_category_id);
  auto* ls = FindLogicalSession(tgt->logical_session_id);
  if (lc == nullptr || lc->cancelled || ls == nullptr || ls->cancelled)
    return fail("类别或所属场次已取消");
  const auto* ss =
      FindSession(tgt->logical_session_id, tgt->activity_version_id);
  if (ss != nullptr && ss->end_time <= domain::Now())
    return fail("已结束场次的类别不能修改");
  std::string rsn;
  if (!VersionEditable(organizer_id, tgt->activity_version_id, &rsn)) {
    return fail(rsn);
  }
  const auto* current = CurrentPublishedSessionForCandidate(
      db_, tgt->activity_version_id, tgt->logical_session_id);
  if (current != nullptr) {
    const auto now = domain::Now();
    const bool frozen =
        now >= domain::AddMinutes(current->start_time, -30) ||
        (ss != nullptr && now >= domain::AddMinutes(ss->start_time, -30));
    if (frozen) {
      const domain::CategoryVersion* current_category = nullptr;
      for (const auto& category : db_->category_versions())
        if (category.activity_version_id == current->activity_version_id &&
            category.logical_session_id == tgt->logical_session_id &&
            category.logical_category_id == tgt->logical_category_id)
          current_category = &category;
      if (current_category == nullptr || current_category->capacity != capacity)
        return fail("场次已进入开始前30分钟冻结期，不能修改票额容量");
    }
  }
  int usedN = 0;
  const std::vector<domain::Session>& ssns = db_->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].activity_version_id != tgt->activity_version_id ||
        ssns[i].logical_session_id != tgt->logical_session_id) {
      continue;
    }
    const int ssnUsedN = ActiveRegistrationCount(
        db_->regs(), ssns[i].logical_session_id, tgt->logical_category_id);
    if (ssnUsedN > usedN) {
      usedN = ssnUsedN;
    }
  }
  if (capacity < usedN) {
    return fail("名额不能小于已占用人数 " + std::to_string(usedN));
  }
  if (capacity <= 0) {
    return fail("名额必须大于 0");
  }
  tgt->capacity = capacity;
  aud_->Log(organizer_id, "调整类别名额", domain::AuditResult::kSuccess,
            "类别 " + tgt->name + " 名额调整为 " + std::to_string(capacity));
  return ServiceResult::Ok("名额已更新");
}

ServiceResult SessionService::CancelSession(domain::Id organizer_id,
                                            domain::Id logical_session_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "取消场次", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    return fail("仅组织者可以取消场次");
  }
  domain::LogicalSession* lSsn = FindLogicalSession(logical_session_id);
  if (lSsn == nullptr) {
    return fail("逻辑场次不存在");
  }
  if (lSsn->cancelled) return fail("已取消，请勿重复取消");
  if (Ended(db_, logical_session_id)) return fail("已结束场次禁止取消");
  bool own = false;
  std::vector<domain::Session>& ssns = db_->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].logical_session_id == logical_session_id &&
        OwnsVersion(db_->activity_versions(), db_->acts(),
                    ssns[i].activity_version_id, organizer_id)) {
      own = true;
      break;
    }
  }
  if (!own) {
    return fail("只能取消自己活动的场次");
  }
  if (HasCheckIn(db_, logical_session_id)) {
    return fail("场次已有签到记录，不能取消");
  }
  lSsn->cancelled = true;
  for (auto& grant : db_->session_grants())
    if (grant.logical_session_id == logical_session_id)
      grant.status = domain::GrantStatus::kInvalid;

  std::vector<domain::Registration>& regs = db_->regs();
  for (std::size_t i = 0; i < regs.size(); ++i) {
    domain::Registration& reg = regs[i];
    if (reg.logical_session_id != logical_session_id) {
      continue;
    }
    if (reg.status == domain::RegistrationStatus::kRegistered ||
        reg.status == domain::RegistrationStatus::kWaitlisted) {
      if (reg.status == domain::RegistrationStatus::kRegistered) {
        tkts_->Void(reg.id);
      }
      reg.status = domain::RegistrationStatus::kCancelled;
      reg.cancelled_at = domain::Now();
      ntfs_->Notify(reg.user_id, domain::NotificationType::kSessionCancelled,
                    "您报名的场次已取消，报名已自动撤销");
    }
  }
  aud_->Log(organizer_id, "取消场次", domain::AuditResult::kSuccess,
            "逻辑场次 " + std::to_string(logical_session_id));
  return ServiceResult::Ok("场次已取消，相关报名已撤销并通知");
}

ServiceResult SessionService::CancelCategory(domain::Id organizer_id,
                                             domain::Id logical_category_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "取消类别", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    return fail("仅组织者可以取消类别");
  }
  domain::LogicalCategory* cat = FindLogicalCategory(logical_category_id);
  if (cat == nullptr) {
    return fail("逻辑类别不存在");
  }
  if (cat->cancelled) return fail("已取消，请勿重复取消");
  bool ended = true;
  for (const auto& c : db_->category_versions())
    if (c.logical_category_id == logical_category_id)
      if (!Ended(db_, c.logical_session_id)) ended = false;
  if (ended) return fail("已结束场次的类别禁止取消");
  bool own = false;
  std::vector<domain::CategoryVersion>& cats = db_->category_versions();
  for (std::size_t i = 0; i < cats.size(); ++i) {
    if (cats[i].logical_category_id == logical_category_id &&
        OwnsVersion(db_->activity_versions(), db_->acts(),
                    cats[i].activity_version_id, organizer_id)) {
      own = true;
      break;
    }
  }
  if (!own) {
    return fail("只能取消自己活动的类别");
  }
  for (const auto& category : cats) {
    if (category.logical_category_id == logical_category_id &&
        HasCheckIn(db_, category.logical_session_id)) {
      return fail("所属场次已有签到记录，不能取消类别");
    }
  }
  cat->cancelled = true;

  std::vector<domain::Registration>& regs = db_->regs();
  for (std::size_t i = 0; i < regs.size(); ++i) {
    domain::Registration& reg = regs[i];
    if (reg.logical_category_id != logical_category_id ||
        (reg.status != domain::RegistrationStatus::kRegistered &&
         reg.status != domain::RegistrationStatus::kWaitlisted)) {
      continue;
    }
    if (reg.status == domain::RegistrationStatus::kRegistered) {
      tkts_->Void(reg.id);
    }
    reg.status = domain::RegistrationStatus::kCancelled;
    reg.cancelled_at = domain::Now();
    ntfs_->Notify(reg.user_id, domain::NotificationType::kCategoryCancelled,
                  "您报名的类别已取消，报名已自动撤销");
  }
  aud_->Log(organizer_id, "取消类别", domain::AuditResult::kSuccess,
            "逻辑类别 " + std::to_string(logical_category_id));
  return ServiceResult::Ok("类别已取消，相关报名已撤销并通知");
}

std::vector<domain::Session> SessionService::SessionsOfVersion(
    domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Session> res;
  std::vector<domain::Session>& ssns = db_->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].activity_version_id == activity_version_id) {
      res.push_back(ssns[i]);
    }
  }
  return res;
}

std::vector<domain::CategoryVersion> SessionService::CategoriesOfVersion(
    domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::CategoryVersion> res;
  std::vector<domain::CategoryVersion>& cats = db_->category_versions();
  for (std::size_t i = 0; i < cats.size(); ++i) {
    if (cats[i].activity_version_id == activity_version_id) {
      res.push_back(cats[i]);
    }
  }
  return res;
}

std::vector<domain::LogicalSession> SessionService::AllLogicalSessions() {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  return db_->logical_sessions();
}

domain::Session* SessionService::FindSession(domain::Id logical_session_id,
                                             domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Session>& ssns = db_->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].logical_session_id == logical_session_id &&
        ssns[i].activity_version_id == activity_version_id) {
      return &ssns[i];
    }
  }
  return nullptr;
}

domain::CategoryVersion* SessionService::FindCategory(
    domain::Id logical_category_id, domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::CategoryVersion>& cats = db_->category_versions();
  for (std::size_t i = 0; i < cats.size(); ++i) {
    if (cats[i].logical_category_id == logical_category_id &&
        cats[i].activity_version_id == activity_version_id) {
      return &cats[i];
    }
  }
  return nullptr;
}

domain::LogicalSession* SessionService::FindLogicalSession(
    domain::Id logical_session_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::LogicalSession>& ssns = db_->logical_sessions();
  return domain::FindById(ssns, logical_session_id);
}

domain::LogicalCategory* SessionService::FindLogicalCategory(
    domain::Id logical_category_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::LogicalCategory>& cats = db_->logical_categories();
  return domain::FindById(cats, logical_category_id);
}

}
}
