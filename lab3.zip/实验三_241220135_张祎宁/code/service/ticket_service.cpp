

#include "service/ticket_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "domain/entity_queries.h"
#include "infra/csv_util.h"
#include "infra/data_store.h"
#include "infra/security.h"
#include "service/audit_service.h"
#include "service/role_service.h"

namespace campus {
namespace service {

namespace {

bool OwnerEligible(infra::DataStore* db, RoleService* rls, domain::Id user_id) {
  for (const auto& u : db->usrs())
    if (u.id == user_id)
      return u.status == domain::UserStatus::kActive &&
             rls->HasRole(user_id, domain::Role::kOrdinaryParticipant);
  return false;
}

}

TicketService::TicketService(infra::DataStore* db, RoleService* rls,
                             AuditService* aud)
    : db_(db), rls_(rls), aud_(aud) {}

ServiceResult TicketService::Issue(domain::Id registration_id,
                                   std::string* code) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(0, "生成凭证", msg);
  };
  domain::Registration* reg = FindRegistration(registration_id);
  if (reg == nullptr) {
    return fail("报名记录不存在");
  }
  if (reg->status != domain::RegistrationStatus::kRegistered)
    return fail("仅已报名记录可以生成凭证");
  if (!OwnerEligible(db_, rls_, reg->user_id))
    return fail("账号已停用或不再具有参与者角色，不能生成凭证");
  std::vector<domain::Ticket>& tkts = db_->tkts();
  for (std::size_t i = 0; i < tkts.size(); ++i) {
    if (tkts[i].registration_id == registration_id) {
      tkts[i].status = domain::TicketStatus::kInvalid;
    }
  }
  domain::Ticket tkt;
  tkt.id = db_->NextId("ticket");
  tkt.registration_id = registration_id;
  do {
    tkt.code = infra::TicketCodeGenerator::Generate();
  } while (FindByCode(tkt.code) != nullptr);
  tkt.status = domain::TicketStatus::kValid;
  tkt.issued_at = domain::Now();
  tkts.push_back(tkt);
  if (code != nullptr) {
    *code = tkt.code;
  }
  aud_->Log(0, "生成凭证", domain::AuditResult::kSuccess,
            "报名 " + std::to_string(registration_id));
  return ServiceResult::Ok(tkt.code);
}

ServiceResult TicketService::Void(domain::Id registration_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  bool fnd = false;
  std::vector<domain::Ticket>& tkts = db_->tkts();
  for (std::size_t i = 0; i < tkts.size(); ++i) {
    if (tkts[i].registration_id == registration_id &&
        tkts[i].status == domain::TicketStatus::kValid) {
      tkts[i].status = domain::TicketStatus::kInvalid;
      fnd = true;
    }
  }
  if (!fnd) {
    return aud_->Fail(0, "凭证失效", "没有可失效的凭证");
  }
  aud_->Log(0, "凭证失效", domain::AuditResult::kSuccess,
            "报名 " + std::to_string(registration_id));
  return ServiceResult::Ok("凭证已失效");
}

domain::Ticket* TicketService::FindByCode(const std::string& code) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Ticket>& tkts = db_->tkts();
  for (std::size_t i = 0; i < tkts.size(); ++i) {
    if (tkts[i].code == code) {
      return &tkts[i];
    }
  }
  return nullptr;
}

domain::Ticket* TicketService::FindByRegistration(domain::Id registration_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  const auto* r = FindRegistration(registration_id);
  if (r == nullptr || !OwnerEligible(db_, rls_, r->user_id) ||
      (r->status != domain::RegistrationStatus::kRegistered &&
       r->status != domain::RegistrationStatus::kCheckedIn))
    return nullptr;
  bool ok = false;
  for (const auto& s : db_->ssns())
    if (s.logical_session_id == r->logical_session_id &&
        s.activity_version_id == r->activity_version_id &&
        domain::Now() <= s.end_time)
      ok = true;
  if (!ok) return nullptr;
  std::vector<domain::Ticket>& tkts = db_->tkts();
  for (std::size_t i = 0; i < tkts.size(); ++i) {
    if (tkts[i].registration_id == registration_id &&
        tkts[i].status == domain::TicketStatus::kValid) {
      return &tkts[i];
    }
  }
  return nullptr;
}

domain::Registration* TicketService::FindRegistration(
    domain::Id registration_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Registration>& regs = db_->regs();
  return domain::FindById(regs, registration_id);
}

bool TicketService::InCheckinWindow(const domain::Session& ssn,
                                    domain::Timestamp ts) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  const domain::Timestamp opn = domain::AddMinutes(ssn.start_time, -30);
  return ts >= opn && ts <= ssn.end_time;
}

ServiceResult TicketService::CheckIn(domain::Id inspector_id,
                                     const std::string& code) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(inspector_id, "验票", msg);
  };
  if (!rls_->Ready(inspector_id) ||
      !rls_->HasRole(inspector_id, domain::Role::kInspector)) {
    return fail("仅检票员可以执行验票");
  }
  const std::string trimmed = infra::Trim(code);
  domain::Ticket* tkt = FindByCode(trimmed);
  if (tkt == nullptr) {
    return fail("凭证码无效");
  }
  if (tkt->status != domain::TicketStatus::kValid) {
    return fail("凭证已失效，可能报名已取消");
  }
  domain::Registration* reg = FindRegistration(tkt->registration_id);
  if (reg == nullptr) {
    return fail("报名记录缺失");
  }
  if (!OwnerEligible(db_, rls_, reg->user_id))
    return fail("持票账号已停用或不再具有参与者角色，凭证不可使用");
  if (reg->status == domain::RegistrationStatus::kCancelled) {
    return fail("报名已取消，不允许入场");
  }
  if (reg->status == domain::RegistrationStatus::kCheckedIn) {
    return fail("重复签到：该凭证已使用");
  }
  if (reg->status != domain::RegistrationStatus::kRegistered) {
    return fail("当前报名状态不可入场");
  }
  if (!rls_->HasValidGrant(inspector_id, reg->logical_session_id)) {
    return fail("您没有该场次的检票授权");
  }
  domain::Session* ssn = nullptr;
  std::vector<domain::Session>& ssns = db_->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].logical_session_id == reg->logical_session_id &&
        ssns[i].activity_version_id == reg->activity_version_id) {
      ssn = &ssns[i];
      break;
    }
  }
  if (ssn == nullptr) {
    return fail("场次信息缺失");
  }
  if (!InCheckinWindow(*ssn, domain::Now())) {
    return fail("不在验票时间窗口内（场次开始前 30 分钟至结束）");
  }
  for (std::size_t i = 0; i < db_->checkin_events().size(); ++i) {
    if (db_->checkin_events()[i].registration_id == reg->id) {
      return fail("重复签到：该报名已有签到记录");
    }
  }
  domain::CheckinEvent ev;
  ev.id = db_->NextId("checkin");
  ev.registration_id = reg->id;
  ev.checked_at = domain::Now();
  db_->checkin_events().push_back(ev);
  reg->status = domain::RegistrationStatus::kCheckedIn;

  std::string atd = std::to_string(reg->user_id);
  std::vector<domain::User>& usrs = db_->usrs();
  for (std::size_t i = 0; i < usrs.size(); ++i) {
    if (usrs[i].id == reg->user_id) {
      atd = usrs[i].name;
      break;
    }
  }
  aud_->Log(inspector_id, "验票", domain::AuditResult::kSuccess,
            "报名 " + std::to_string(reg->id) + " 签到成功");
  return ServiceResult::Ok("签到成功：" + atd + " / " + ssn->location);
}

std::string TicketService::Describe(domain::Id registration_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  domain::Registration* reg = FindRegistration(registration_id);
  if (reg == nullptr) {
    return "报名记录不存在";
  }
  std::string location = "-";
  std::string tmTxt = "-";
  std::vector<domain::Session>& ssns = db_->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].logical_session_id == reg->logical_session_id &&
        ssns[i].activity_version_id == reg->activity_version_id) {
      location = ssns[i].location;
      tmTxt = domain::FormatTime(ssns[i].start_time);
      break;
    }
  }
  std::string code = "无";
  domain::Ticket* tkt = FindByRegistration(registration_id);
  if (tkt != nullptr) {
    code = tkt->code;
  }
  std::string title, cat, pos;
  for (const auto& v : db_->activity_versions())
    if (v.id == reg->activity_version_id) title = v.title;
  for (const auto& c : db_->category_versions())
    if (c.activity_version_id == reg->activity_version_id &&
        c.logical_session_id == reg->logical_session_id &&
        c.logical_category_id == reg->logical_category_id)
      cat = c.name;
  if (reg->status == domain::RegistrationStatus::kWaitlisted) {
    int n = 1;
    for (const auto& r : db_->regs())
      if (r.logical_session_id == reg->logical_session_id &&
          r.logical_category_id == reg->logical_category_id &&
          r.status == domain::RegistrationStatus::kWaitlisted &&
          r.waitlist_sequence < reg->waitlist_sequence)
        ++n;
    pos = " 当前候补排位:" + std::to_string(n);
  }
  return "报名#" + std::to_string(reg->id) + " " + title + " / " + cat + " " +
         location + " " + tmTxt + pos +
         " 状态:" + domain::ToString(reg->status) + " 凭证:" + code;
}

}
}
