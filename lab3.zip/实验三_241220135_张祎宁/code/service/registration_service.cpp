

#include "service/registration_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "domain/entity_queries.h"
#include "infra/data_store.h"
#include "service/audit_service.h"
#include "service/notification_service.h"
#include "service/role_service.h"
#include "service/ticket_service.h"

namespace campus {
namespace service {

namespace {

struct PublishContext {
  domain::ActivityVersion* ver = nullptr;
  domain::Activity* act = nullptr;
  domain::Session* ssn = nullptr;
  domain::CategoryVersion* cat = nullptr;
};

bool LogicalCategoryCancelled(infra::DataStore* db,
                              domain::Id logical_category_id) {
  const std::vector<domain::LogicalCategory>& cats = db->logical_categories();
  return domain::IsCancelledOrMissing(cats, logical_category_id);
}

bool ResolvePublished(infra::DataStore* db, domain::Id logical_session_id,
                      domain::Id logical_category_id, PublishContext* ctx) {
  std::vector<domain::Session>& ssns = db->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].logical_session_id != logical_session_id) {
      continue;
    }
    auto* ver =
        domain::FindById(db->activity_versions(), ssns[i].activity_version_id);
    if (ver == nullptr ||
        ver->status != domain::VersionStatus::kCurrentPublished) {
      continue;
    }
    auto* act = domain::FindById(db->acts(), ver->activity_id);
    if (act == nullptr || act->status != domain::ActivityStatus::kPublished) {
      continue;
    }
    domain::CategoryVersion* cat = nullptr;
    std::vector<domain::CategoryVersion>& cats = db->category_versions();
    for (std::size_t j = 0; j < cats.size(); ++j) {
      if (cats[j].activity_version_id == ver->id &&
          (logical_category_id == 0 ||
           cats[j].logical_category_id == logical_category_id) &&
          !LogicalCategoryCancelled(db, cats[j].logical_category_id) &&
          cats[j].logical_session_id == logical_session_id) {
        cat = &cats[j];
        break;
      }
    }
    if (cat == nullptr) {
      continue;
    }
    ctx->ver = ver;
    ctx->act = act;
    ctx->ssn = &ssns[i];
    ctx->cat = cat;
    return true;
  }
  return false;
}

bool LogicalSessionCancelled(infra::DataStore* db,
                             domain::Id logical_session_id) {
  std::vector<domain::LogicalSession>& ssns = db->logical_sessions();
  return domain::IsCancelledOrMissing(ssns, logical_session_id);
}

bool HasActiveRegistration(const std::vector<domain::Registration>& xs,
                           domain::Id user_id, domain::Id logical_session_id) {
  for (std::size_t i = 0; i < xs.size(); ++i) {
    const domain::Registration& x = xs[i];
    if (x.user_id == user_id && x.logical_session_id == logical_session_id &&
        (domain::OccupiesSeat(x.status) ||
         x.status == domain::RegistrationStatus::kWaitlisted)) {
      return true;
    }
  }
  return false;
}

}

RegistrationService::RegistrationService(infra::DataStore* db, RoleService* rls,
                                         AuditService* aud,
                                         NotificationService* ntfs,
                                         TicketService* tkts)
    : db_(db), rls_(rls), aud_(aud), ntfs_(ntfs), tkts_(tkts) {}

std::string RegistrationService::IdempotencyResult(
    const std::string& ky, const std::string& request_hash, bool* fnd) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  *fnd = false;
  if (ky.empty()) {
    return "";
  }
  std::vector<domain::IdempotencyRecord>& recs = db_->idempotency_records();
  for (std::size_t i = 0; i < recs.size(); ++i) {
    if (recs[i].ky != ky) {
      continue;
    }
    *fnd = true;
    if (recs[i].request_hash != request_hash) {
      return "FAIL|幂等键已被其他报名请求使用";
    }
    return recs[i].res;
  }
  return "";
}

ServiceResult RegistrationService::Register(domain::Id user_id,
                                            domain::Id logical_session_id,
                                            domain::Id logical_category_id,
                                            const std::string& idempotency_key,
                                            std::string* det) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(user_id, "报名", msg);
  };
  if (!rls_->Ready(user_id) ||
      !rls_->HasRole(user_id, domain::Role::kOrdinaryParticipant)) {
    return fail("仅普通参与者可以报名");
  }
  const std::string request_hash = std::to_string(user_id) + ":" +
                                   std::to_string(logical_session_id) + ":" +
                                   std::to_string(logical_category_id);
  bool fnd = false;
  const std::string cch =
      IdempotencyResult(idempotency_key, request_hash, &fnd);
  if (fnd) {
    const bool ok = cch.compare(0, 3, "OK|") == 0;
    *det = cch.substr(ok ? 3 : 5);
    aud_->Log(user_id, "报名幂等命中", domain::AuditResult::kSuccess,
              "键 " + idempotency_key);
    if (ok) {
      return ServiceResult::Ok(*det);
    }
    return fail(*det);
  }

  PublishContext ctx;
  if (!ResolvePublished(db_, logical_session_id, logical_category_id, &ctx)) {
    return fail("未找到已发布的场次与类别组合，请检查 ID");
  }
  logical_category_id = ctx.cat->logical_category_id;
  int n = 0;
  for (const auto& c : db_->category_versions()) {
    if (c.activity_version_id != ctx.ver->id ||
        LogicalCategoryCancelled(db_, c.logical_category_id) ||
        LogicalSessionCancelled(db_, c.logical_session_id))
      continue;
    if (c.name != ctx.cat->name)
      return fail("活动存在多种票，请组织者调整为单一票种后发布");
    if (c.logical_session_id == logical_session_id) ++n;
  }
  if (n != 1) return fail("场次存在多份票额配置，请组织者调整后发布");
  if (LogicalSessionCancelled(db_, logical_session_id)) {
    return fail("该场次已取消");
  }
  const domain::Timestamp ts = domain::Now();
  if (ts < ctx.ssn->registration_start) {
    return fail("报名尚未开始");
  }
  if (ts >= ctx.ssn->registration_end) {
    return fail("报名已截止");
  }
  if (ts >= ctx.ssn->start_time) {
    return fail("场次已开始，无法报名");
  }
  if (HasActiveRegistration(db_->regs(), user_id, logical_session_id)) {
    return fail("您已报名该场次或已在该场次候补队列中");
  }

  domain::Registration reg;
  infra::Transaction tx(db_);
  reg.id = db_->NextId("registration");
  reg.user_id = user_id;
  reg.logical_session_id = logical_session_id;
  reg.logical_category_id = logical_category_id;
  reg.activity_version_id = ctx.ver->id;
  reg.created_at = ts;
  reg.cancelled_at = 0;

  std::string prm;
  while (PromoteOne(logical_session_id, logical_category_id, &prm)) {
  }
  const int rem = RemainingSeats(logical_session_id, logical_category_id);
  ServiceResult res;
  if (rem > 0) {
    reg.status = domain::RegistrationStatus::kRegistered;
    reg.waitlist_sequence = 0;
    db_->regs().push_back(reg);
    std::string code;
    const auto issued = tkts_->Issue(reg.id, &code);
    if (!issued.ok) {
      tx.Rollback();
      return fail(issued.msg);
    }
    *det = "报名成功，凭证码：" + code;
    res = ServiceResult::Ok(*det);
    aud_->Log(user_id, "报名", domain::AuditResult::kSuccess,
              ctx.act->title + " 报名 " + std::to_string(reg.id));
  } else {
    domain::Id maxSeq = 0;
    const std::vector<domain::Registration>& xs = db_->regs();
    for (std::size_t i = 0; i < xs.size(); ++i) {
      if (xs[i].logical_session_id == logical_session_id &&
          xs[i].logical_category_id == logical_category_id &&
          xs[i].waitlist_sequence > maxSeq) {
        maxSeq = xs[i].waitlist_sequence;
      }
    }
    reg.status = domain::RegistrationStatus::kWaitlisted;
    reg.waitlist_sequence = maxSeq + 1;
    db_->regs().push_back(reg);
    *det = "名额已满，已进入候补队列，候补序号 " +
           std::to_string(reg.waitlist_sequence);
    res = ServiceResult::Ok(*det);
    aud_->Log(
        user_id, "进入候补", domain::AuditResult::kSuccess,
        ctx.act->title + " 序号 " + std::to_string(reg.waitlist_sequence));
  }

  if (!idempotency_key.empty()) {
    domain::IdempotencyRecord rec;
    rec.ky = idempotency_key;
    rec.op = "register";
    rec.request_hash = request_hash;
    rec.res = (res.ok ? "OK|" : "FAIL|") + *det;
    rec.created_at = ts;
    db_->idempotency_records().push_back(rec);
  }
  tx.Commit();
  return res;
}

ServiceResult RegistrationService::Cancel(domain::Id user_id,
                                          domain::Id registration_id,
                                          std::string* det) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(user_id, "取消报名", msg);
  };
  if (!rls_->Ready(user_id) ||
      !rls_->HasRole(user_id, domain::Role::kOrdinaryParticipant))
    return fail("请以有效参与者账号登录并完成改密");
  domain::Registration* reg = Find(registration_id);
  if (reg == nullptr) {
    return fail("报名记录不存在");
  }
  if (reg->user_id != user_id) {
    return fail("只能取消自己的报名");
  }
  if (reg->status == domain::RegistrationStatus::kCancelled) {
    return fail("已取消，请勿重复取消");
  }
  if (reg->status != domain::RegistrationStatus::kRegistered &&
      reg->status != domain::RegistrationStatus::kWaitlisted) {
    return fail("当前状态不能取消报名");
  }
  bool fnd = false;
  const auto ts = domain::Now();
  for (const auto& s : db_->ssns()) {
    if (s.logical_session_id != reg->logical_session_id ||
        s.activity_version_id != reg->activity_version_id)
      continue;
    fnd = true;
    if (ts >= s.start_time || ts >= s.end_time)
      return fail("场次已开始，不能取消报名");
  }
  if (!fnd) return fail("场次信息缺失，不能取消报名");
  const domain::Id sid = reg->logical_session_id;
  infra::Transaction tx(db_);
  const domain::Id cid = reg->logical_category_id;
  const bool wasReg = reg->status == domain::RegistrationStatus::kRegistered;
  reg->status = domain::RegistrationStatus::kCancelled;
  reg->cancelled_at = domain::Now();
  if (wasReg) {
    tkts_->Void(registration_id);
  }
  aud_->Log(user_id, "取消报名", domain::AuditResult::kSuccess,
            "报名 " + std::to_string(registration_id));
  *det = "报名已取消";
  if (wasReg) {
    std::string prm;
    while (PromoteOne(sid, cid, &prm)) {
      *det += "；" + prm;
    }
  }
  tx.Commit();
  return ServiceResult::Ok(*det);
}

bool RegistrationService::PromoteOne(domain::Id logical_session_id,
                                     domain::Id logical_category_id,
                                     std::string* det) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  PublishContext ctx;
  if (!ResolvePublished(db_, logical_session_id, logical_category_id, &ctx) ||
      LogicalSessionCancelled(db_, logical_session_id) ||
      domain::Now() >= ctx.ssn->registration_end ||
      domain::Now() >= ctx.ssn->start_time)
    return false;
  if (RemainingSeats(logical_session_id, logical_category_id) <= 0) {
    return false;
  }
  domain::Registration* cand = nullptr;
  std::vector<domain::Registration>& xs = db_->regs();
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].logical_session_id != logical_session_id ||
        xs[i].logical_category_id != logical_category_id ||
        xs[i].status != domain::RegistrationStatus::kWaitlisted) {
      continue;
    }
    bool ok = false;
    for (const auto& u : db_->usrs()) {
      if (u.id == xs[i].user_id && u.status == domain::UserStatus::kActive &&
          !u.must_change_password &&
          rls_->HasRole(u.id, domain::Role::kOrdinaryParticipant))
        ok = true;
    }
    if (!ok) continue;
    for (const auto& s : db_->ssns()) {
      if (s.logical_session_id == xs[i].logical_session_id &&
          s.activity_version_id == xs[i].activity_version_id &&
          (domain::Now() >= s.registration_end ||
           domain::Now() >= s.start_time))
        ok = false;
    }
    if (!ok) continue;
    for (const auto& r : xs)
      if (r.user_id == xs[i].user_id &&
          r.logical_session_id == logical_session_id &&
          (domain::OccupiesSeat(r.status)))
        ok = false;
    if (!ok) continue;
    if (cand == nullptr || xs[i].waitlist_sequence < cand->waitlist_sequence) {
      cand = &xs[i];
    }
  }
  if (cand == nullptr) {
    return false;
  }
  infra::Transaction tx(db_);
  cand->status = domain::RegistrationStatus::kRegistered;
  cand->waitlist_sequence = 0;
  std::string code;
  const auto issued = tkts_->Issue(cand->id, &code);
  if (!issued.ok) return false;
  ntfs_->Notify(cand->user_id, domain::NotificationType::kPromoted,
                "您已从候补递补成功，报名#" + std::to_string(cand->id) +
                    " 凭证码：" + code);
  aud_->Log(0, "候补递补", domain::AuditResult::kSuccess,
            "报名 " + std::to_string(cand->id) + " 递补成功");
  *det = "候补用户已自动递补";
  tx.Commit();
  return true;
}

void RegistrationService::PromoteAvailable(domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::string det;
  for (const auto& c : db_->category_versions()) {
    if (c.activity_version_id == activity_version_id)
      while (PromoteOne(c.logical_session_id, c.logical_category_id, &det)) {
      }
  }
}

std::vector<domain::Registration> RegistrationService::RegistrationsOf(
    domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Registration> res;
  if (!rls_->Ready(user_id)) {
    aud_->Fail(user_id, "查看我的报名", "请先登录并完成改密");
    return res;
  }
  aud_->Log(user_id, "查看我的报名", domain::AuditResult::kSuccess, "报名列表");
  std::vector<domain::Registration>& xs = db_->regs();
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].user_id == user_id) {
      res.push_back(xs[i]);
    }
  }
  return res;
}

domain::Registration* RegistrationService::Find(domain::Id registration_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Registration>& xs = db_->regs();
  return domain::FindById(xs, registration_id);
}

int RegistrationService::SeatCount(domain::Id logical_session_id,
                                   domain::Id logical_category_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  int n = 0;
  const std::vector<domain::Registration>& xs = db_->regs();
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].logical_session_id != logical_session_id ||
        xs[i].logical_category_id != logical_category_id) {
      continue;
    }
    if (domain::OccupiesSeat(xs[i].status)) {
      ++n;
    }
  }
  return n;
}

int RegistrationService::RemainingSeats(domain::Id logical_session_id,
                                        domain::Id logical_category_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  PublishContext ctx;
  if (!ResolvePublished(db_, logical_session_id, logical_category_id, &ctx)) {
    return 0;
  }
  int ssnUsed = 0;
  const std::vector<domain::Registration>& xs = db_->regs();
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].logical_session_id == logical_session_id &&
        (domain::OccupiesSeat(xs[i].status))) {
      ++ssnUsed;
    }
  }
  const int catRem =
      ctx.cat->capacity -
      SeatCount(logical_session_id, ctx.cat->logical_category_id);
  const int ssnRem = ctx.ssn->capacity - ssnUsed;
  if (catRem < ssnRem) {
    return catRem < 0 ? 0 : catRem;
  }
  return ssnRem < 0 ? 0 : ssnRem;
}

}
}
