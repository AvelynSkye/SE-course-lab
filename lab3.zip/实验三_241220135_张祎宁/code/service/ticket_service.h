

#ifndef SERVICE_TICKET_SERVICE_H_
#define SERVICE_TICKET_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class RoleService;

class TicketService {
 public:
  TicketService(infra::DataStore* db, RoleService* rls, AuditService* aud);

  ServiceResult Issue(domain::Id registration_id, std::string* code);
  ServiceResult Void(domain::Id registration_id);
  ServiceResult CheckIn(domain::Id inspector_id, const std::string& code);

  domain::Ticket* FindByCode(const std::string& code);
  domain::Ticket* FindByRegistration(domain::Id registration_id);
  domain::Registration* FindRegistration(domain::Id registration_id);
  std::string Describe(domain::Id registration_id);
  bool InCheckinWindow(const domain::Session& ssn, domain::Timestamp ts);

 private:
  infra::DataStore* db_;
  RoleService* rls_;
  AuditService* aud_;
};

}
}

#endif
