

#ifndef SERVICE_AUDIT_SERVICE_H_
#define SERVICE_AUDIT_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class RoleService;
class AuditService {
 public:
  explicit AuditService(infra::DataStore* db);

  void BindRoles(RoleService* rls) { rls_ = rls; }
  void Log(domain::Id user_id, const std::string& actn, domain::AuditResult res,
           const std::string& det);
  std::vector<domain::AuditLog> Recent(domain::Id user_id, int lim);
  ServiceResult Fail(domain::Id user_id, const std::string& actn,
                     const std::string& det);

 private:
  infra::DataStore* db_;
  RoleService* rls_ = nullptr;
};

}
}

#endif
