#include "service/background_task_service.h"

#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "infra/data_store.h"
#include "service/audit_service.h"
#include "service/notification_service.h"
#include "service/registration_service.h"
#include "service/role_service.h"
#include "service/ticket_service.h"

namespace campus {
namespace service {

BackgroundTaskService::BackgroundTaskService(infra::DataStore* db,
                                             AuditService* aud,
                                             NotificationService* ntfs,
                                             RoleService* rls,
                                             TicketService* tkts)
    : db_(db), aud_(aud), ntfs_(ntfs), rls_(rls), tkts_(tkts) {}

bool BackgroundTaskService::Allowed(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  return user_id == 0 || (rls_->Ready(user_id) &&
                          rls_->HasRole(user_id, domain::Role::kAdministrator));
}

void BackgroundTaskService::Enqueue(const std::string& typ,
                                    const std::string& pl,
                                    domain::TaskStatus status) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  domain::BackgroundTask t;
  t.id = db_->NextId("background_task");
  t.task_type = typ;
  t.pl = pl;
  t.status = status;
  db_->background_tasks().push_back(t);
}

int BackgroundTaskService::PromoteWaitlists() {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  int before = 0;
  for (const auto& registration : db_->regs())
    if (registration.status == domain::RegistrationStatus::kRegistered)
      ++before;
  RegistrationService registrations(db_, rls_, aud_, ntfs_, tkts_);
  for (const auto& version : db_->activity_versions())
    if (version.status == domain::VersionStatus::kCurrentPublished)
      registrations.PromoteAvailable(version.id);
  int after = 0;
  for (const auto& registration : db_->regs())
    if (registration.status == domain::RegistrationStatus::kRegistered) ++after;
  return after - before;
}

int BackgroundTaskService::RunDeadlineNotification(domain::Id operator_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!Allowed(operator_id)) {
    aud_->Log(operator_id, "截止任务", domain::AuditResult::kFailure,
              "无执行权限");
    return 0;
  }
  PromoteWaitlists();
  int n = 0;
  const auto ts = domain::Now();
  for (auto& r : db_->regs()) {
    if (r.status != domain::RegistrationStatus::kWaitlisted) continue;
    for (const auto& s : db_->ssns()) {
      if (s.logical_session_id != r.logical_session_id ||
          s.activity_version_id != r.activity_version_id ||
          ts < s.registration_end)
        continue;
      r.status = domain::RegistrationStatus::kExpired;
      const auto ky = "deadline:" + std::to_string(r.id);
      ntfs_->Notify(r.user_id, domain::NotificationType::kRegistrationDeadline,
                    "报名截止，候补未成功，报名#" + std::to_string(r.id), ky);
      Enqueue("deadline", std::to_string(r.id), domain::TaskStatus::kSuccess);
      aud_->Log(operator_id, "候补截止", domain::AuditResult::kSuccess, ky);
      ++n;
      break;
    }
  }
  return n;
}

int BackgroundTaskService::RunAbsenceDetection(domain::Id operator_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!Allowed(operator_id)) {
    aud_->Log(operator_id, "缺席任务", domain::AuditResult::kFailure,
              "无执行权限");
    return 0;
  }
  int n = 0;
  const auto ts = domain::Now();
  for (auto& r : db_->regs()) {
    if (r.status != domain::RegistrationStatus::kRegistered) continue;
    for (const auto& s : db_->ssns()) {
      if (s.logical_session_id != r.logical_session_id ||
          s.activity_version_id != r.activity_version_id || ts <= s.end_time)
        continue;
      bool chk = false;
      for (const auto& e : db_->checkin_events())
        if (e.registration_id == r.id) chk = true;
      if (chk) {
        r.status = domain::RegistrationStatus::kCheckedIn;
        break;
      }
      r.status = domain::RegistrationStatus::kAbsent;
      for (auto& t : db_->tkts()) {
        if (t.registration_id == r.id)
          t.status = domain::TicketStatus::kInvalid;
      }
      const auto ky = "absence:" + std::to_string(r.id);
      ntfs_->Notify(r.user_id, domain::NotificationType::kAbsent,
                    "场次已结束，您未签到，报名#" + std::to_string(r.id), ky);
      Enqueue("absence", std::to_string(r.id), domain::TaskStatus::kSuccess);
      aud_->Log(operator_id, "缺席判定", domain::AuditResult::kSuccess, ky);
      ++n;
      break;
    }
  }
  for (auto& a : db_->acts()) {
    if (a.status != domain::ActivityStatus::kPublished) continue;
    bool any = false;
    bool end = true;
    for (const auto& v : db_->activity_versions()) {
      if (v.activity_id != a.id ||
          v.status != domain::VersionStatus::kCurrentPublished)
        continue;
      for (const auto& s : db_->ssns()) {
        if (s.activity_version_id != v.id) continue;
        bool off = false;
        for (const auto& l : db_->logical_sessions())
          if (l.id == s.logical_session_id) off = l.cancelled;
        any = true;
        if (!off && ts <= s.end_time) end = false;
      }
    }
    for (const auto& r : db_->regs()) {
      for (const auto& v : db_->activity_versions()) {
        if (v.id == r.activity_version_id && v.activity_id == a.id &&
            (r.status == domain::RegistrationStatus::kRegistered ||
             r.status == domain::RegistrationStatus::kWaitlisted))
          end = false;
      }
    }
    if (any && end) {
      a.status = domain::ActivityStatus::kEnded;
      aud_->Log(operator_id, "活动结束", domain::AuditResult::kSuccess,
                std::to_string(a.id));
    }
  }
  return n;
}

int BackgroundTaskService::RetryFailedTasks(domain::Id operator_id,
                                            bool manual) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!Allowed(operator_id) || (manual && operator_id == 0)) {
    aud_->Log(operator_id, "通知重试", domain::AuditResult::kFailure,
              "无执行权限");
    return 0;
  }
  int n = 0;
  for (auto& t : db_->background_tasks()) {
    if (t.task_type != "notification_retry" ||
        t.status == domain::TaskStatus::kSuccess ||
        (!manual && t.retry_count >= 3))
      continue;
    ++t.retry_count;
    const bool ok = ntfs_->Deliver(t.user_id, t.typ, t.cnt, t.pl);
    t.status = ok ? domain::TaskStatus::kSuccess : domain::TaskStatus::kFailed;
    aud_->Log(
        operator_id, "通知重试",
        ok ? domain::AuditResult::kSuccess : domain::AuditResult::kFailure,
        std::to_string(t.id));
    ++n;
  }
  return n;
}

int BackgroundTaskService::RunDue() {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  int n = RunDeadlineNotification(0) + RunAbsenceDetection(0);
  const auto ts = domain::Now();
  if (ts >= nextTs_) {
    n += RetryFailedTasks(0);
    nextTs_ = domain::AddMinutes(ts, 1);
  }
  return n;
}

std::vector<domain::BackgroundTask> BackgroundTaskService::Tasks(
    domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (user_id == 0 || !Allowed(user_id)) {
    aud_->Fail(user_id, "查看后台任务", "无权限");
    return {};
  }
  aud_->Log(user_id, "查看后台任务", domain::AuditResult::kSuccess, "任务列表");
  return db_->background_tasks();
}

}
}
