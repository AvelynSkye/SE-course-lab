

#ifndef SERVICE_REGISTRATION_SERVICE_H_
#define SERVICE_REGISTRATION_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class NotificationService;
class RoleService;
class TicketService;

class RegistrationService {
 public:
  RegistrationService(infra::DataStore* db, RoleService* rls, AuditService* aud,
                      NotificationService* ntfs, TicketService* tkts);

  ServiceResult Register(domain::Id user_id, domain::Id logical_session_id,
                         domain::Id logical_category_id,
                         const std::string& idempotency_key, std::string* det);
  ServiceResult Cancel(domain::Id user_id, domain::Id registration_id,
                       std::string* det);

  std::vector<domain::Registration> RegistrationsOf(domain::Id user_id);
  domain::Registration* Find(domain::Id registration_id);
  int SeatCount(domain::Id logical_session_id, domain::Id logical_category_id);
  int RemainingSeats(domain::Id logical_session_id,
                     domain::Id logical_category_id);
  void PromoteAvailable(domain::Id activity_version_id);

 private:
  bool PromoteOne(domain::Id logical_session_id, domain::Id logical_category_id,
                  std::string* det);
  std::string IdempotencyResult(const std::string& ky,
                                const std::string& request_hash, bool* fnd);

  infra::DataStore* db_;
  RoleService* rls_;
  AuditService* aud_;
  NotificationService* ntfs_;
  TicketService* tkts_;
};

}
}

#endif
