

#include "service/activity_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "domain/entity_queries.h"
#include "domain/venue.h"
#include "infra/data_store.h"
#include "service/audit_service.h"
#include "service/notification_service.h"
#include "service/registration_service.h"
#include "service/role_service.h"
#include "service/ticket_service.h"

namespace campus {
namespace service {

namespace {

domain::ActivityVersion* FindVersionIn(
    std::vector<domain::ActivityVersion>& vers,
    domain::Id activity_version_id) {
  return domain::FindById(vers, activity_version_id);
}

domain::Activity* FindActivityIn(std::vector<domain::Activity>& acts,
                                 domain::Id activity_id) {
  return domain::FindById(acts, activity_id);
}

std::vector<domain::Session> SessionsIn(
    const std::vector<domain::Session>& ssns, domain::Id activity_version_id) {
  std::vector<domain::Session> res;
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].activity_version_id == activity_version_id) {
      res.push_back(ssns[i]);
    }
  }
  return res;
}

std::vector<domain::CategoryVersion> CategoriesIn(
    const std::vector<domain::CategoryVersion>& cats,
    domain::Id activity_version_id) {
  std::vector<domain::CategoryVersion> res;
  for (std::size_t i = 0; i < cats.size(); ++i) {
    if (cats[i].activity_version_id == activity_version_id) {
      res.push_back(cats[i]);
    }
  }
  return res;
}

bool Overlaps(domain::Timestamp b1, domain::Timestamp e1, domain::Timestamp b2,
              domain::Timestamp e2) {
  return b1 < e2 && b2 < e1;
}

bool ContainsId(const std::vector<domain::Id>& ids, domain::Id val) {
  for (std::size_t i = 0; i < ids.size(); ++i) {
    if (ids[i] == val) {
      return true;
    }
  }
  return false;
}

bool LogicalSessionCancelled(const std::vector<domain::LogicalSession>& ssns,
                             domain::Id logical_session_id) {
  return domain::IsCancelledOrMissing(ssns, logical_session_id);
}

bool LogicalCategoryCancelled(const std::vector<domain::LogicalCategory>& cats,
                              domain::Id logical_category_id) {
  return domain::IsCancelledOrMissing(cats, logical_category_id);
}

bool SameSessionData(const domain::Session& left,
                     const domain::Session& right) {
  return left.logical_session_id == right.logical_session_id &&
         left.location == right.location &&
         left.start_time == right.start_time &&
         left.end_time == right.end_time &&
         left.registration_start == right.registration_start &&
         left.registration_end == right.registration_end &&
         left.capacity == right.capacity;
}

bool SameFrozenSessionData(const domain::Session& left,
                           const domain::Session& right) {
  return left.location == right.location &&
         left.start_time == right.start_time &&
         left.end_time == right.end_time && left.capacity == right.capacity;
}

bool InSessionFreezeWindow(const domain::Session& current,
                           const domain::Session& candidate,
                           domain::Timestamp now) {
  return now >= domain::AddMinutes(current.start_time, -30) ||
         now >= domain::AddMinutes(candidate.start_time, -30);
}

bool HasCheckInEvent(infra::DataStore* db, domain::Id registration_id) {
  for (const auto& event : db->checkin_events())
    if (event.registration_id == registration_id) return true;
  return false;
}

bool MatchesCheckedInSnapshots(infra::DataStore* db,
                               const domain::Session& candidate) {
  for (const auto& registration : db->regs()) {
    if (registration.logical_session_id != candidate.logical_session_id ||
        (registration.status != domain::RegistrationStatus::kCheckedIn &&
         !HasCheckInEvent(db, registration.id)))
      continue;
    bool matched = false;
    for (const auto& session : db->ssns()) {
      if (session.logical_session_id == candidate.logical_session_id &&
          session.activity_version_id == registration.activity_version_id) {
        matched = SameSessionData(session, candidate);
        break;
      }
    }
    if (!matched) return false;
  }
  return true;
}

const domain::Session* CurrentPublishedSession(
    infra::DataStore* db, domain::Id activity_id, domain::Id logical_session_id,
    domain::Id candidate_version_id) {
  for (const auto& session : db->ssns()) {
    if (session.logical_session_id != logical_session_id ||
        session.activity_version_id == candidate_version_id)
      continue;
    for (const auto& version : db->activity_versions()) {
      if (version.id == session.activity_version_id &&
          version.activity_id == activity_id &&
          version.status == domain::VersionStatus::kCurrentPublished)
        return &session;
    }
  }
  return nullptr;
}

const domain::CategoryVersion* CategoryInVersion(
    infra::DataStore* db, domain::Id activity_version_id,
    domain::Id logical_session_id, domain::Id logical_category_id) {
  for (const auto& category : db->category_versions())
    if (category.activity_version_id == activity_version_id &&
        category.logical_session_id == logical_session_id &&
        category.logical_category_id == logical_category_id)
      return &category;
  return nullptr;
}

bool CurrentPublishedActivityEnded(infra::DataStore* db,
                                   domain::Id activity_id) {
  bool any = false;
  const auto ts = domain::Now();
  for (const auto& version : db->activity_versions()) {
    if (version.activity_id != activity_id ||
        version.status != domain::VersionStatus::kCurrentPublished)
      continue;
    for (const auto& session : db->ssns()) {
      if (session.activity_version_id != version.id) continue;
      any = true;
      if (!LogicalSessionCancelled(db->logical_sessions(),
                                   session.logical_session_id) &&
          session.end_time > ts)
        return false;
    }
  }
  return any;
}

}

ActivityService::ActivityService(infra::DataStore* db, RoleService* rls,
                                 AuditService* aud, NotificationService* ntfs,
                                 TicketService* tkts)
    : db_(db), rls_(rls), aud_(aud), ntfs_(ntfs), tkts_(tkts) {
  rls_->BindActivities(this);
}

ServiceResult ActivityService::CreateActivity(domain::Id organizer_id,
                                              const std::string& title,
                                              const std::string& description,
                                              domain::Id* activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "创建活动", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    return fail("仅组织者可以创建活动");
  }
  if (title.empty()) {
    return fail("活动标题不能为空");
  }
  domain::Activity act;
  act.id = db_->NextId("activity");
  act.title = title;
  act.status = domain::ActivityStatus::kNotPublished;
  act.creator_id = organizer_id;
  db_->acts().push_back(act);

  domain::ActivityVersion ver;
  ver.id = db_->NextId("activity_version");
  ver.activity_id = act.id;
  ver.version_number = 1;
  ver.status = domain::VersionStatus::kDraft;
  ver.description = description;
  ver.title = title;
  db_->activity_versions().push_back(ver);

  *activity_id = act.id;
  aud_->Log(organizer_id, "创建活动", domain::AuditResult::kSuccess, title);
  return ServiceResult::Ok("活动创建成功，活动 ID：" + std::to_string(act.id) +
                           "（初始版本为草稿）");
}

ServiceResult ActivityService::EditDraft(domain::Id organizer_id,
                                         domain::Id activity_version_id,
                                         const std::string& title,
                                         const std::string& description) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "编辑活动草稿", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer))
    return fail("请以有效组织者账号登录并完成改密");
  domain::ActivityVersion* ver = FindVersion(activity_version_id);
  if (ver == nullptr) {
    return fail("活动版本不存在");
  }
  domain::Activity* act = FindActivity(ver->activity_id);
  if (act == nullptr) {
    return fail("活动不存在");
  }
  if (act->status == domain::ActivityStatus::kCancelled ||
      act->status == domain::ActivityStatus::kEnded)
    return fail("活动已取消或结束");
  if (act->creator_id != organizer_id) {
    return fail("只能编辑自己创建的活动");
  }
  if (ver->status != domain::VersionStatus::kDraft &&
      ver->status != domain::VersionStatus::kReviewRejected) {
    return fail("当前状态不可编辑：" + domain::ToString(ver->status));
  }
  if (title.empty()) {
    return fail("活动标题不能为空");
  }
  ver->title = title;
  if (act->status == domain::ActivityStatus::kNotPublished) act->title = title;
  ver->description = description;
  ver->status = domain::VersionStatus::kDraft;
  ver->rejection_reason.clear();
  aud_->Log(organizer_id, "编辑活动草稿", domain::AuditResult::kSuccess,
            "版本 " + std::to_string(activity_version_id));
  return ServiceResult::Ok("草稿已保存");
}

ServiceResult ActivityService::ValidateForPublish(
    domain::Id activity_version_id, std::string* rsn) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& txt) {
    *rsn = txt;
    return ServiceResult::Fail(txt);
  };
  auto* v = FindVersion(activity_version_id);
  if (v == nullptr) return fail("活动版本不存在");
  auto* a = FindActivity(v->activity_id);
  if (a == nullptr) return fail("活动不存在");
  if (a->status == domain::ActivityStatus::kCancelled ||
      a->status == domain::ActivityStatus::kEnded)
    return fail("活动已取消或结束");
  if (a->status == domain::ActivityStatus::kPublished &&
      CurrentPublishedActivityEnded(db_, a->id))
    return fail("当前发布活动的全部有效场次已结束，不能再发布新版本");
  if (v->title.empty()) return fail("活动标题为空");
  std::vector<domain::Session> ss;
  for (const auto& x : db_->ssns()) {
    if (x.activity_version_id == activity_version_id &&
        !LogicalSessionCancelled(db_->logical_sessions(), x.logical_session_id))
      ss.push_back(x);
  }
  if (ss.empty()) return fail("至少需要一个有效场次");
  std::vector<domain::Id> ids;
  std::string name;
  for (const auto& x : ss) {
    if (ContainsId(ids, x.logical_session_id)) return fail("场次逻辑 ID 重复");
    ids.push_back(x.logical_session_id);
    if (!domain::ValidVenue(x.location) || x.start_time >= x.end_time ||
        x.registration_start >= x.registration_end ||
        x.registration_end > x.start_time || x.capacity <= 0)
      return fail("场次地点、时间或容量非法");
    if (!MatchesCheckedInSnapshots(db_, x))
      return fail("已有签到记录的场次不能修改时间、地点或容量");
    const auto* current = CurrentPublishedSession(
        db_, a->id, x.logical_session_id, activity_version_id);
    const bool frozen =
        current != nullptr && InSessionFreezeWindow(*current, x, domain::Now());
    if (frozen && !SameFrozenSessionData(*current, x))
      return fail("场次已进入开始前30分钟冻结期，不能修改时间、地点或容量");
    if (current != nullptr && current->end_time <= domain::Now() &&
        !SameSessionData(*current, x))
      return fail("当前发布场次已经结束，不能通过新版本重新开放或修改");
    if (x.end_time <= domain::Now()) {
      bool old = false;
      for (const auto& s : db_->ssns()) {
        auto* ov = FindVersion(s.activity_version_id);
        if (ov != nullptr && ov->activity_id == a->id &&
            s.activity_version_id != activity_version_id &&
            (ov->status == domain::VersionStatus::kCurrentPublished ||
             ov->status == domain::VersionStatus::kHistory) &&
            s.logical_session_id == x.logical_session_id &&
            s.location == x.location && s.start_time == x.start_time &&
            s.end_time == x.end_time &&
            s.registration_start == x.registration_start &&
            s.registration_end == x.registration_end &&
            s.capacity == x.capacity)
          old = true;
      }
      if (!old) return fail("已结束场次只可保留原记录，不能新增或修改");
    }
    int used = 0;
    for (const auto& r : db_->regs()) {
      if (r.logical_session_id == x.logical_session_id &&
          (domain::OccupiesSeat(r.status)))
        ++used;
    }
    if (used > x.capacity) return fail("场次容量小于已占用人数");
    long long sum = 0;
    std::vector<domain::Id> cids;
    for (const auto& c : db_->category_versions()) {
      if (c.activity_version_id != activity_version_id ||
          c.logical_session_id != x.logical_session_id ||
          LogicalCategoryCancelled(db_->logical_categories(),
                                   c.logical_category_id))
        continue;
      if (ContainsId(cids, c.logical_category_id))
        return fail("场次内类别逻辑 ID 重复");
      cids.push_back(c.logical_category_id);
      if (c.name.empty() || c.capacity <= 0) return fail("类别名称或名额非法");
      if (current != nullptr && current->end_time <= domain::Now()) {
        const auto* old_category =
            CategoryInVersion(db_, current->activity_version_id,
                              c.logical_session_id, c.logical_category_id);
        if (old_category == nullptr || old_category->name != c.name ||
            old_category->capacity != c.capacity)
          return fail("已结束场次的票名和名额不能通过新版本修改");
      }
      if (frozen) {
        const auto* frozen_category =
            CategoryInVersion(db_, current->activity_version_id,
                              c.logical_session_id, c.logical_category_id);
        if (frozen_category == nullptr ||
            frozen_category->capacity != c.capacity)
          return fail("场次已进入开始前30分钟冻结期，不能修改票额容量");
      }
      if (!name.empty() && name != c.name)
        return fail("同一活动只能设置一种票");
      name = c.name;
      int cnt = 0;
      for (const auto& r : db_->regs()) {
        if (r.logical_session_id == x.logical_session_id &&
            r.logical_category_id == c.logical_category_id &&
            (domain::OccupiesSeat(r.status)))
          ++cnt;
      }
      if (cnt > c.capacity) return fail("类别名额小于已占用人数");
      sum += c.capacity;
    }
    if (cids.size() != 1) return fail("每个场次必须且只能配置一种票");
    if (sum > x.capacity) return fail("类别名额合计超过所属场次容量");
  }
  for (const auto& c : db_->category_versions()) {
    if (c.activity_version_id != activity_version_id ||
        LogicalCategoryCancelled(db_->logical_categories(),
                                 c.logical_category_id) ||
        LogicalSessionCancelled(db_->logical_sessions(), c.logical_session_id))
      continue;
    if (!ContainsId(ids, c.logical_session_id))
      return fail("类别所属场次不在当前版本");
  }
  for (std::size_t i = 0; i < ss.size(); ++i) {
    for (std::size_t j = i + 1; j < ss.size(); ++j) {
      if (ss[i].location == ss[j].location &&
          Overlaps(ss[i].start_time, ss[i].end_time, ss[j].start_time,
                   ss[j].end_time))
        return fail("同一活动内存在同地点时间冲突");
    }
    for (const auto& y : db_->ssns()) {
      if (LogicalSessionCancelled(db_->logical_sessions(),
                                  y.logical_session_id))
        continue;
      auto* ov = FindVersion(y.activity_version_id);
      if (ov == nullptr || ov->activity_id == a->id ||
          ov->status != domain::VersionStatus::kCurrentPublished)
        continue;
      auto* oa = FindActivity(ov->activity_id);
      if (oa == nullptr || oa->status != domain::ActivityStatus::kPublished)
        continue;
      if (ss[i].location == y.location &&
          Overlaps(ss[i].start_time, ss[i].end_time, y.start_time, y.end_time))
        return fail("与已发布活动存在同地点时间冲突");
    }
  }
  *rsn = "发布前复核通过";
  return ServiceResult::Ok(*rsn);
}

ServiceResult ActivityService::CreateVersion(domain::Id organizer_id,
                                             domain::Id activity_id,
                                             domain::Id* activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "创建新版本", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer))
    return fail("请以有效组织者账号登录并完成改密");
  auto* a = FindActivity(activity_id);
  auto* old = CurrentVersion(activity_id);
  if (a == nullptr || a->creator_id != organizer_id ||
      a->status != domain::ActivityStatus::kPublished || old == nullptr)
    return fail("只能为自己已发布的活动创建新版本");
  int no = 0;
  for (const auto& v : db_->activity_versions()) {
    if (v.activity_id != activity_id) continue;
    if (v.status != domain::VersionStatus::kCurrentPublished &&
        v.status != domain::VersionStatus::kHistory)
      return fail("已有尚未发布的版本，请先处理");
    if (v.version_number > no) no = v.version_number;
  }
  const auto src = old->id;
  domain::ActivityVersion v = *old;
  v.id = db_->NextId("activity_version");
  v.version_number = no + 1;
  v.status = domain::VersionStatus::kDraft;
  v.published_at = 0;
  v.rejection_reason.clear();
  const auto ss = SessionsIn(db_->ssns(), src);
  const auto cs = CategoriesIn(db_->category_versions(), src);
  for (auto x : ss) {
    if (LogicalSessionCancelled(db_->logical_sessions(), x.logical_session_id))
      continue;
    x.id = db_->NextId("session");
    x.activity_version_id = v.id;
    db_->ssns().push_back(x);
  }
  for (auto c : cs) {
    if (LogicalSessionCancelled(db_->logical_sessions(),
                                c.logical_session_id) ||
        LogicalCategoryCancelled(db_->logical_categories(),
                                 c.logical_category_id))
      continue;
    c.id = db_->NextId("category_version");
    c.activity_version_id = v.id;
    db_->category_versions().push_back(c);
  }
  db_->activity_versions().push_back(v);
  *activity_version_id = v.id;
  aud_->Log(organizer_id, "创建新版本", domain::AuditResult::kSuccess,
            std::to_string(v.id));
  return ServiceResult::Ok("新草稿版本 ID：" + std::to_string(v.id));
}

ServiceResult ActivityService::SubmitReview(domain::Id organizer_id,
                                            domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "提交审核", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    return fail("仅组织者可以提交审核");
  }
  domain::ActivityVersion* ver = FindVersion(activity_version_id);
  if (ver == nullptr) {
    return fail("活动版本不存在");
  }
  domain::Activity* act = FindActivity(ver->activity_id);
  if (act == nullptr || act->creator_id != organizer_id) {
    return fail("只能提交自己创建的活动");
  }
  if (ver->status != domain::VersionStatus::kDraft &&
      ver->status != domain::VersionStatus::kReviewRejected) {
    return fail("当前状态不可提交审核：" + domain::ToString(ver->status));
  }
  std::string rsn;
  ServiceResult checked = ValidateForPublish(activity_version_id, &rsn);
  if (!checked.ok) {
    return fail("内容校验未通过：" + rsn);
  }
  ver->status = domain::VersionStatus::kPendingReview;
  ver->rejection_reason.clear();
  aud_->Log(organizer_id, "提交审核", domain::AuditResult::kSuccess,
            "版本 " + std::to_string(activity_version_id));
  return ServiceResult::Ok("已提交审核，等待管理员处理");
}

ServiceResult ActivityService::Review(domain::Id administrator_id,
                                      domain::Id activity_version_id, bool apv,
                                      const std::string& rsn) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(administrator_id, "审核活动", msg);
  };
  if (!rls_->Ready(administrator_id) ||
      !rls_->HasRole(administrator_id, domain::Role::kAdministrator)) {
    return fail("仅管理员可以审核活动");
  }
  domain::ActivityVersion* ver = FindVersion(activity_version_id);
  if (ver == nullptr) {
    return fail("活动版本不存在");
  }
  if (ver->status != domain::VersionStatus::kPendingReview) {
    return fail("该版本不在待审核状态");
  }
  domain::Activity* act = FindActivity(ver->activity_id);
  if (act == nullptr) {
    return fail("活动不存在");
  }

  if (act->status == domain::ActivityStatus::kCancelled ||
      act->status == domain::ActivityStatus::kEnded)
    return fail("活动已取消或结束");
  if (act->creator_id == administrator_id) {
    return fail("审核回避：不能审核自己创建的活动");
  }
  if (apv) {
    ver->status = domain::VersionStatus::kApprovedPendingPublish;
    aud_->Log(administrator_id, "审核活动", domain::AuditResult::kSuccess,
              "通过版本 " + std::to_string(activity_version_id));
    return ServiceResult::Ok("审核通过，等待组织者发布");
  }
  if (rsn.empty()) {
    return fail("驳回时必须填写原因");
  }
  ver->status = domain::VersionStatus::kReviewRejected;
  ver->rejection_reason = rsn;
  aud_->Log(administrator_id, "审核活动", domain::AuditResult::kSuccess,
            "驳回版本 " + std::to_string(activity_version_id) + "：" + rsn);
  return ServiceResult::Ok("已驳回，原因已记录");
}

ServiceResult ActivityService::Publish(domain::Id organizer_id,
                                       domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(organizer_id, "发布活动", msg);
  };
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer))
    return fail("请以有效组织者账号登录并完成改密");
  domain::ActivityVersion* ver = FindVersion(activity_version_id);
  if (ver == nullptr) {
    return fail("活动版本不存在");
  }
  domain::Activity* act = FindActivity(ver->activity_id);
  if (act == nullptr || act->creator_id != organizer_id) {
    return fail("只能发布自己创建的活动");
  }
  if (ver->status != domain::VersionStatus::kApprovedPendingPublish) {
    return fail("只有审核通过待发布的版本才能发布，当前：" +
                domain::ToString(ver->status));
  }
  std::string rsn;
  ServiceResult checked = ValidateForPublish(activity_version_id, &rsn);
  if (!checked.ok) {
    return fail("发布复核失败：" + rsn);
  }
  infra::Transaction tx(db_);
  std::vector<domain::ActivityVersion>& vers = db_->activity_versions();
  for (std::size_t i = 0; i < vers.size(); ++i) {
    if (vers[i].activity_id == act->id && vers[i].id != activity_version_id &&
        vers[i].status == domain::VersionStatus::kCurrentPublished) {
      vers[i].status = domain::VersionStatus::kHistory;
    }
  }
  ver->status = domain::VersionStatus::kCurrentPublished;
  ver->published_at = domain::Now();
  act->status = domain::ActivityStatus::kPublished;
  act->title = ver->title;
  for (auto& r : db_->regs()) {
    auto* prev = FindVersion(r.activity_version_id);
    if (prev == nullptr || prev->activity_id != act->id ||
        r.activity_version_id == activity_version_id ||
        (r.status != domain::RegistrationStatus::kRegistered &&
         r.status != domain::RegistrationStatus::kWaitlisted))
      continue;
    bool found = false;
    for (const auto& c : db_->category_versions())
      if (c.activity_version_id == activity_version_id &&
          c.logical_session_id == r.logical_session_id &&
          c.logical_category_id == r.logical_category_id)
        found = true;
    if (!found) {
      tx.Rollback();
      return fail("新版本缺少有效报名对应的场次或类别");
    }
    const auto old = r.activity_version_id;
    r.activity_version_id = activity_version_id;
    ntfs_->Notify(r.user_id, domain::NotificationType::kVersionChanged,
                  "活动版本已更新，请查看最新场次时间、地点及报名信息，报名#" +
                      std::to_string(r.id),
                  "version:" + std::to_string(activity_version_id) + ":" +
                      std::to_string(r.id));
    aud_->Log(organizer_id, "迁移报名版本", domain::AuditResult::kSuccess,
              std::to_string(r.id) + ":" + std::to_string(old) + "->" +
                  std::to_string(activity_version_id));
  }
  RegistrationService regs(db_, rls_, aud_, ntfs_, tkts_);
  regs.PromoteAvailable(activity_version_id);
  aud_->Log(organizer_id, "发布活动", domain::AuditResult::kSuccess,
            act->title + " 版本 " + std::to_string(activity_version_id));
  tx.Commit();
  return ServiceResult::Ok("发布成功，当前发布版本已更新");
}

ServiceResult ActivityService::Withdraw(domain::Id user_id,
                                        domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto* v = FindVersion(activity_version_id);
  auto* a = v == nullptr ? nullptr : FindActivity(v->activity_id);
  if (!rls_->Ready(user_id) ||
      !rls_->HasRole(user_id, domain::Role::kOrganizer) || a == nullptr ||
      a->creator_id != user_id || a->status == domain::ActivityStatus::kEnded ||
      a->status == domain::ActivityStatus::kCancelled ||
      v->status != domain::VersionStatus::kApprovedPendingPublish)
    return aud_->Fail(user_id, "撤回待发布版本", "无权撤回或版本状态不允许");
  v->status = domain::VersionStatus::kDraft;
  aud_->Log(user_id, "撤回待发布版本", domain::AuditResult::kSuccess,
            std::to_string(activity_version_id));
  return ServiceResult::Ok("已撤回草稿，修改后须重新提交审核");
}

ServiceResult ActivityService::CancelActivity(domain::Id organizer_id,
                                              domain::Id activity_id) {
  return CancelActivityInternal(organizer_id, organizer_id, activity_id, true,
                                "");
}

ServiceResult ActivityService::CancelForRoleRemoval(domain::Id administrator_id,
                                                    domain::Id organizer_id,
                                                    domain::Id activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(administrator_id) ||
      !rls_->HasRole(administrator_id, domain::Role::kAdministrator)) {
    return aud_->Fail(administrator_id, "移除组织者角色",
                      "仅管理员可以移除角色");
  }
  return CancelActivityInternal(administrator_id, organizer_id, activity_id,
                                false, "（移除组织者角色时自动取消）");
}

ServiceResult ActivityService::CancelForAccountDisable(
    domain::Id administrator_id, domain::Id organizer_id,
    domain::Id activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(administrator_id) ||
      !rls_->HasRole(administrator_id, domain::Role::kAdministrator)) {
    return aud_->Fail(administrator_id, "停用组织者账号",
                      "仅管理员可以停用账号");
  }
  return CancelActivityInternal(administrator_id, organizer_id, activity_id,
                                false, "（停用组织者账号时自动取消）");
}

ServiceResult ActivityService::CancelActivityInternal(
    domain::Id actor_id, domain::Id organizer_id, domain::Id activity_id,
    bool require_organizer_session, const std::string& audit_suffix) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(actor_id, "取消活动", msg);
  };
  if (require_organizer_session &&
      (!rls_->Ready(organizer_id) ||
       !rls_->HasRole(organizer_id, domain::Role::kOrganizer))) {
    return fail("请以有效组织者账号登录并完成改密");
  }
  domain::Activity* act = FindActivity(activity_id);
  if (act == nullptr) {
    return fail("活动不存在");
  }
  if (act->creator_id != organizer_id) {
    return fail("只能取消自己创建的活动");
  }
  if (act->status == domain::ActivityStatus::kCancelled) {
    return fail("已取消，请勿重复取消");
  }
  if (act->status == domain::ActivityStatus::kEnded) return fail("活动已结束");
  const auto ts = domain::Now();
  for (const auto& s : db_->ssns()) {
    const auto* v = FindVersion(s.activity_version_id);
    if (v != nullptr && v->activity_id == activity_id &&
        v->status == domain::VersionStatus::kCurrentPublished &&
        !LogicalSessionCancelled(db_->logical_sessions(),
                                 s.logical_session_id) &&
        ts >= domain::AddMinutes(s.start_time, -30))
      return fail("活动已进入签到时间，不能取消");
  }
  for (const auto& e : db_->checkin_events()) {
    for (const auto& r : db_->regs()) {
      if (r.id != e.registration_id) continue;
      const auto* v = FindVersion(r.activity_version_id);
      if (v != nullptr && v->activity_id == activity_id)
        return fail("活动已有签到记录，不能取消");
    }
  }
  act->status = domain::ActivityStatus::kCancelled;
  std::vector<domain::Id> vids;
  for (auto& v : db_->activity_versions()) {
    if (v.activity_id != activity_id) continue;
    vids.push_back(v.id);
    v.status = domain::VersionStatus::kHistory;
  }
  for (const auto& s : db_->ssns()) {
    if (!ContainsId(vids, s.activity_version_id)) continue;
    for (auto& l : db_->logical_sessions())
      if (l.id == s.logical_session_id) l.cancelled = true;
    for (auto& grant : db_->session_grants())
      if (grant.logical_session_id == s.logical_session_id)
        grant.status = domain::GrantStatus::kInvalid;
  }
  for (auto& r : db_->regs()) {
    if (!ContainsId(vids, r.activity_version_id)) continue;
    if (r.status != domain::RegistrationStatus::kRegistered &&
        r.status != domain::RegistrationStatus::kWaitlisted)
      continue;
    if (r.status == domain::RegistrationStatus::kRegistered) tkts_->Void(r.id);
    r.status = domain::RegistrationStatus::kCancelled;
    r.cancelled_at = domain::Now();
    ntfs_->Notify(r.user_id, domain::NotificationType::kActivityCancelled,
                  "活动已取消，报名已撤销：" + act->title,
                  "cancel:" + std::to_string(r.id));
  }
  aud_->Log(actor_id, "取消活动", domain::AuditResult::kSuccess,
            act->title + audit_suffix);
  return ServiceResult::Ok("活动已取消，相关报名已撤销并通知");
}

std::vector<domain::ActivityVersion> ActivityService::PendingVersions(
    domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(user_id) ||
      !rls_->HasRole(user_id, domain::Role::kAdministrator)) {
    aud_->Fail(user_id, "查询活动", "无权限");
    return {};
  }
  aud_->Log(user_id, "查询活动", domain::AuditResult::kSuccess,
            "管理员活动查询");
  std::vector<domain::ActivityVersion> res;
  std::vector<domain::ActivityVersion>& vers = db_->activity_versions();
  for (std::size_t i = 0; i < vers.size(); ++i) {
    if (vers[i].status == domain::VersionStatus::kPendingReview) {
      res.push_back(vers[i]);
    }
  }
  return res;
}

std::vector<domain::Activity> ActivityService::ActivitiesOf(
    domain::Id organizer_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(organizer_id) ||
      !rls_->HasRole(organizer_id, domain::Role::kOrganizer)) {
    aud_->Fail(organizer_id, "查询我的活动", "无权限");
    return {};
  }
  std::vector<domain::Activity> res;
  std::vector<domain::Activity>& acts = db_->acts();
  for (std::size_t i = 0; i < acts.size(); ++i) {
    if (acts[i].creator_id == organizer_id) {
      res.push_back(acts[i]);
    }
  }
  return res;
}

std::vector<domain::Activity> ActivityService::AllActivities(
    domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!rls_->Ready(user_id) ||
      !rls_->HasRole(user_id, domain::Role::kAdministrator)) {
    aud_->Fail(user_id, "查询活动", "无权限");
    return {};
  }
  aud_->Log(user_id, "查询活动", domain::AuditResult::kSuccess,
            "管理员活动查询");
  return db_->acts();
}

std::vector<domain::Activity> ActivityService::Published(
    domain::Id user_id, const std::string& key) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Activity> res;
  if (!rls_->Ready(user_id)) {
    aud_->Fail(user_id, "浏览筛选活动", "请先登录并完成改密");
    return res;
  }
  for (const auto& a : db_->acts()) {
    if (a.status != domain::ActivityStatus::kPublished) continue;
    auto* v = CurrentVersion(a.id);
    if (v == nullptr) continue;
    bool hit = key.empty() || a.title.find(key) != std::string::npos ||
               v->description.find(key) != std::string::npos;
    for (const auto& s : db_->ssns()) {
      if (s.activity_version_id == v->id &&
          !LogicalSessionCancelled(db_->logical_sessions(),
                                   s.logical_session_id) &&
          s.location.find(key) != std::string::npos)
        hit = true;
    }
    for (const auto& c : db_->category_versions()) {
      if (c.activity_version_id == v->id &&
          !LogicalSessionCancelled(db_->logical_sessions(),
                                   c.logical_session_id) &&
          !LogicalCategoryCancelled(db_->logical_categories(),
                                    c.logical_category_id) &&
          c.name.find(key) != std::string::npos)
        hit = true;
    }
    if (hit) res.push_back(a);
  }
  aud_->Log(user_id, "浏览筛选活动", domain::AuditResult::kSuccess,
            key.empty() ? "全部" : key);
  return res;
}

std::vector<domain::ActivityVersion> ActivityService::VersionsOf(
    domain::Id user_id, domain::Id activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  const auto* a = FindActivity(activity_id);
  if (!rls_->Ready(user_id) || a == nullptr ||
      (!rls_->HasRole(user_id, domain::Role::kAdministrator) &&
       !(a->creator_id == user_id &&
         rls_->HasRole(user_id, domain::Role::kOrganizer)))) {
    aud_->Fail(user_id, "查询版本", "无权限");
    return {};
  }
  aud_->Log(user_id, "查询版本", domain::AuditResult::kSuccess,
            std::to_string(activity_id));
  std::vector<domain::ActivityVersion> res;
  std::vector<domain::ActivityVersion>& vers = db_->activity_versions();
  for (std::size_t i = 0; i < vers.size(); ++i) {
    if (vers[i].activity_id == activity_id) {
      res.push_back(vers[i]);
    }
  }
  return res;
}

domain::Activity* ActivityService::FindActivity(domain::Id activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  return FindActivityIn(db_->acts(), activity_id);
}

domain::ActivityVersion* ActivityService::FindVersion(
    domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  return FindVersionIn(db_->activity_versions(), activity_version_id);
}

domain::ActivityVersion* ActivityService::CurrentVersion(
    domain::Id activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::ActivityVersion>& vers = db_->activity_versions();
  for (std::size_t i = 0; i < vers.size(); ++i) {
    if (vers[i].activity_id == activity_id &&
        vers[i].status == domain::VersionStatus::kCurrentPublished) {
      return &vers[i];
    }
  }
  return nullptr;
}

domain::ActivityVersion* ActivityService::LatestVersion(
    domain::Id activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  domain::ActivityVersion* lat = nullptr;
  std::vector<domain::ActivityVersion>& vers = db_->activity_versions();
  for (std::size_t i = 0; i < vers.size(); ++i) {
    if (vers[i].activity_id != activity_id) {
      continue;
    }
    if (lat == nullptr || vers[i].version_number > lat->version_number) {
      lat = &vers[i];
    }
  }
  return lat;
}

std::string ActivityService::DescribeVersion(domain::Id activity_version_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  domain::ActivityVersion* ver = FindVersion(activity_version_id);
  if (ver == nullptr) {
    return "版本不存在";
  }
  return "版本#" + std::to_string(ver->id) + " " + ver->title + " V" +
         std::to_string(ver->version_number) + " [" +
         domain::ToString(ver->status) + "]";
}

}
}
