

#ifndef SERVICE_BACKGROUND_TASK_SERVICE_H_
#define SERVICE_BACKGROUND_TASK_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class NotificationService;
class RoleService;
class TicketService;

class BackgroundTaskService {
 public:
  BackgroundTaskService(infra::DataStore* db, AuditService* aud,
                        NotificationService* ntfs, RoleService* rls,
                        TicketService* tkts);
  int RunDue();

  int RunDeadlineNotification(domain::Id operator_id);
  int RunAbsenceDetection(domain::Id operator_id);
  int RetryFailedTasks(domain::Id operator_id, bool manual = false);
  std::vector<domain::BackgroundTask> Tasks(domain::Id user_id);

 private:
  bool Allowed(domain::Id user_id);
  int PromoteWaitlists();
  void Enqueue(const std::string& task_type, const std::string& pl,
               domain::TaskStatus status);

  infra::DataStore* db_;
  AuditService* aud_;
  NotificationService* ntfs_;
  RoleService* rls_;
  TicketService* tkts_;
  domain::Timestamp nextTs_ = 0;
};

}
}

#endif
