

#ifndef SERVICE_NOTIFICATION_SERVICE_H_
#define SERVICE_NOTIFICATION_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class RoleService;

class NotificationService {
 public:
  NotificationService(infra::DataStore* db, AuditService* aud,
                      RoleService* rls);
  std::vector<domain::Notification> History(domain::Id user_id);

  bool Notify(domain::Id user_id, domain::NotificationType typ,
              const std::string& cnt, const std::string& event_id = "");
  bool Deliver(domain::Id user_id, domain::NotificationType typ,
               const std::string& cnt, const std::string& event_id);
  std::vector<domain::Notification> Unread(domain::Id user_id);
  int UnreadCount(domain::Id user_id);
  bool MarkRead(domain::Id user_id, domain::Id nid);
  int MarkAllRead(domain::Id user_id);

 private:
  infra::DataStore* db_;
  AuditService* aud_;
  RoleService* rls_;
};

}
}

#endif
