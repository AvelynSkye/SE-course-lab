

#include "service/stats_service.h"

#include <cctype>
#include <cstddef>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <memory>
#include <mutex>
#include <string>
#include <system_error>
#include <vector>

#include "domain/datetime.h"
#include "domain/entities.h"
#include "domain/entity_queries.h"
#include "infra/csv_util.h"
#include "infra/data_store.h"
#include "service/audit_service.h"
#include "service/role_service.h"

namespace campus {
namespace service {

namespace {

domain::Activity* FindActivity(infra::DataStore* db, domain::Id activity_id) {
  std::vector<domain::Activity>& acts = db->acts();
  return domain::FindById(acts, activity_id);
}

bool CanAccessActivity(RoleService* rls, domain::Id user_id,
                       const domain::Activity& act) {
  if (!rls->Ready(user_id)) return false;
  if (rls->HasRole(user_id, domain::Role::kAdministrator)) {
    return true;
  }
  return rls->HasRole(user_id, domain::Role::kOrganizer) &&
         act.creator_id == user_id;
}

std::string FindText(const std::vector<domain::User>& usrs, domain::Id user_id,
                     bool wantNm) {
  for (std::size_t i = 0; i < usrs.size(); ++i) {
    if (usrs[i].id == user_id) {
      return wantNm ? usrs[i].name : usrs[i].account;
    }
  }
  return "-";
}

std::string SessionText(infra::DataStore* db, const domain::Registration& reg) {
  std::vector<domain::Session>& ssns = db->ssns();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].logical_session_id == reg.logical_session_id &&
        ssns[i].activity_version_id == reg.activity_version_id) {
      return ssns[i].location + " " + domain::FormatTime(ssns[i].start_time);
    }
  }
  return "-";
}

std::string CategoryText(infra::DataStore* db,
                         const domain::Registration& reg) {
  std::vector<domain::CategoryVersion>& cats = db->category_versions();
  for (std::size_t i = 0; i < cats.size(); ++i) {
    if (cats[i].logical_category_id == reg.logical_category_id &&
        cats[i].activity_version_id == reg.activity_version_id &&
        cats[i].logical_session_id == reg.logical_session_id) {
      return cats[i].name;
    }
  }
  return "-";
}

std::string TicketText(infra::DataStore* db, domain::Id registration_id) {
  std::vector<domain::Ticket>& tkts = db->tkts();
  for (std::size_t i = 0; i < tkts.size(); ++i) {
    if (tkts[i].registration_id == registration_id &&
        tkts[i].status == domain::TicketStatus::kValid) {
      return "有效";
    }
  }
  return "-";
}

std::string SpreadsheetCell(const std::string& value) {
  std::size_t pos = 0;
  while (pos < value.size() &&
         (value[pos] == ' ' || value[pos] == '\t' || value[pos] == '\r'))
    ++pos;
  if (pos < value.size() && (value[pos] == '=' || value[pos] == '+' ||
                             value[pos] == '-' || value[pos] == '@'))
    return "'" + value;
  if (!value.empty() && (value[0] == '\t' || value[0] == '\r'))
    return "'" + value;
  return value;
}

std::string CheckinText(infra::DataStore* db, domain::Id registration_id) {
  std::vector<domain::CheckinEvent>& evs = db->checkin_events();
  for (std::size_t i = 0; i < evs.size(); ++i) {
    if (evs[i].registration_id == registration_id) {
      return domain::FormatTime(evs[i].checked_at);
    }
  }
  return "-";
}

}

std::string StatResult::ToString() const {
  char buf[64] = {0};
  std::snprintf(buf, sizeof(buf), "%.1f%%", attRt * 100.0);
  return "活动《" + title + "》：已报名 " + std::to_string(regN) + "，已签到 " +
         std::to_string(chkN) + "，候补 " + std::to_string(wlN) + "，已取消 " +
         std::to_string(cancelled) + "，缺席 " + std::to_string(absN) +
         "，候补截止 " + std::to_string(expN) + "，到场率 " + buf;
}

StatsService::StatsService(infra::DataStore* db, RoleService* rls,
                           AuditService* aud)
    : db_(db), rls_(rls), aud_(aud) {}

std::vector<StatResult> StatsService::QueryStats(domain::Id user_id,
                                                 domain::Id activity_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<StatResult> results;
  domain::Activity* act = FindActivity(db_, activity_id);
  if (act == nullptr || !CanAccessActivity(rls_, user_id, *act)) {
    aud_->Log(user_id, "查询统计", domain::AuditResult::kFailure,
              "活动不存在或无权访问：" + std::to_string(activity_id));
    return results;
  }
  auto belongs = [&](domain::Id activity_version_id) {
    for (const auto& v : db_->activity_versions())
      if (v.id == activity_version_id && v.activity_id == activity_id)
        return true;
    return false;
  };
  StatResult res;
  res.activity_id = activity_id;
  res.title = act->title;
  {
    std::vector<domain::Registration>& regs = db_->regs();
    for (std::size_t i = 0; i < regs.size(); ++i) {
      if (!belongs(regs[i].activity_version_id)) {
        continue;
      }
      switch (regs[i].status) {
        case domain::RegistrationStatus::kRegistered:
          ++res.regN;
          break;
        case domain::RegistrationStatus::kCheckedIn:
          ++res.chkN;
          break;
        case domain::RegistrationStatus::kWaitlisted:
          ++res.wlN;
          break;
        case domain::RegistrationStatus::kAbsent:
          ++res.absN;
          break;
        case domain::RegistrationStatus::kExpired:
          ++res.expN;
          break;
        case domain::RegistrationStatus::kCancelled:
          ++res.cancelled;
          break;
      }
    }
  }
  const int total = res.regN + res.chkN + res.absN;
  if (total > 0) {
    res.attRt = static_cast<double>(res.chkN) / static_cast<double>(total);
  }
  results.push_back(res);
  auto snap = std::make_shared<infra::DataStore>();
  db_->CopyTo(snap.get());
  snaps_[{user_id, activity_id}] = snap;
  aud_->Log(user_id, "查询统计", domain::AuditResult::kSuccess,
            "活动 " + std::to_string(activity_id));
  return results;
}

ServiceResult StatsService::ExportRoster(domain::Id user_id,
                                         domain::Id activity_id,
                                         const std::string& pth,
                                         std::string* sum) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  domain::Activity* act = FindActivity(db_, activity_id);
  if (act == nullptr) {
    return aud_->Fail(user_id, "导出名单", "活动不存在");
  }
  if (!CanAccessActivity(rls_, user_id, *act)) {
    return aud_->Fail(user_id, "导出名单", "无权导出该活动名单");
  }
  if (snaps_.count({user_id, activity_id}) == 0)
    QueryStats(user_id, activity_id);
  const auto snap = snaps_.at({user_id, activity_id});
  auto belongs = [&](domain::Id activity_version_id) {
    for (const auto& v : snap->activity_versions())
      if (v.id == activity_version_id && v.activity_id == activity_id)
        return true;
    return false;
  };
  std::error_code ec;
  const auto dst = std::filesystem::weakly_canonical(pth, ec);
  if (ec || pth.empty()) return aud_->Fail(user_id, "导出名单", "导出路径无效");
  const std::vector<std::string> reserved = {"users.csv",
                                             "user_roles.csv",
                                             "activities.csv",
                                             "activity_versions.csv",
                                             "logical_sessions.csv",
                                             "sessions.csv",
                                             "logical_categories.csv",
                                             "category_versions.csv",
                                             "session_grants.csv",
                                             "registrations.csv",
                                             "tickets.csv",
                                             "checkin_events.csv",
                                             "notifications.csv",
                                             "audit_logs.csv",
                                             "idempotency_records.csv",
                                             "background_tasks.csv"};
  auto filename = dst.filename().string();
  for (auto& c : filename)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  for (const auto& reserved_name : reserved)
    if (filename == reserved_name)
      return aud_->Fail(user_id, "导出名单",
                        "该文件名由系统数据保留，请更换名称");
  if (std::filesystem::exists(dst, ec) || ec)
    return aud_->Fail(user_id, "导出名单",
                      "目标已存在，请使用新文件名，避免覆盖数据");
  std::ofstream out(dst);
  if (!out.is_open()) {
    return aud_->Fail(user_id, "导出名单", "无法写入文件：" + pth);
  }
  std::vector<std::string> hdr;
  hdr.push_back("用户ID");
  hdr.push_back("姓名");
  hdr.push_back("账号");
  hdr.push_back("场次");
  hdr.push_back("类别");
  hdr.push_back("报名状态");
  hdr.push_back("凭证状态");
  hdr.push_back("签到时间");
  out << infra::JoinCsv(hdr) << "\n";

  int exported = 0;
  std::vector<domain::Registration>& regs = snap->regs();
  for (std::size_t i = 0; i < regs.size(); ++i) {
    const domain::Registration& reg = regs[i];
    if (!belongs(reg.activity_version_id)) {
      continue;
    }
    std::vector<std::string> x;
    x.push_back(std::to_string(reg.user_id));
    x.push_back(FindText(snap->usrs(), reg.user_id, true));
    x.push_back(FindText(snap->usrs(), reg.user_id, false));
    x.push_back(SessionText(snap.get(), reg));
    x.push_back(CategoryText(snap.get(), reg));
    x.push_back(domain::ToString(reg.status));
    x.push_back(TicketText(snap.get(), reg.id));
    x.push_back(CheckinText(snap.get(), reg.id));
    for (auto& cell : x) cell = SpreadsheetCell(cell);
    out << infra::JoinCsv(x) << "\n";
    ++exported;
  }
  out.close();
  if (out.fail()) return aud_->Fail(user_id, "导出名单", "文件写入失败");
  *sum = "已导出 " + std::to_string(exported) + " 条名单记录到 " + pth;
  aud_->Log(user_id, "导出名单", domain::AuditResult::kSuccess, *sum);
  return ServiceResult::Ok(*sum);
}

}
}
