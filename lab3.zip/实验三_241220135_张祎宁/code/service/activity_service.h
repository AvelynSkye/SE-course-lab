

#ifndef SERVICE_ACTIVITY_SERVICE_H_
#define SERVICE_ACTIVITY_SERVICE_H_

#include <string>
#include <vector>

#include "domain/entities.h"
#include "domain/types.h"
#include "service/service_result.h"

namespace campus {
namespace infra {
class DataStore;
}

namespace service {

class AuditService;
class NotificationService;
class RoleService;
class TicketService;

class ActivityService {
 public:
  ActivityService(infra::DataStore* db, RoleService* rls, AuditService* aud,
                  NotificationService* ntfs, TicketService* tkts);

  ServiceResult CreateActivity(domain::Id organizer_id,
                               const std::string& title,
                               const std::string& description,
                               domain::Id* activity_id);
  ServiceResult EditDraft(domain::Id organizer_id,
                          domain::Id activity_version_id,
                          const std::string& title,
                          const std::string& description);
  ServiceResult CreateVersion(domain::Id organizer_id, domain::Id activity_id,
                              domain::Id* activity_version_id);
  ServiceResult SubmitReview(domain::Id organizer_id,
                             domain::Id activity_version_id);
  ServiceResult Review(domain::Id administrator_id,
                       domain::Id activity_version_id, bool apv,
                       const std::string& rsn);
  ServiceResult Publish(domain::Id organizer_id,
                        domain::Id activity_version_id);
  ServiceResult Withdraw(domain::Id organizer_id,
                         domain::Id activity_version_id);
  ServiceResult CancelActivity(domain::Id organizer_id, domain::Id activity_id);
  ServiceResult ValidateForPublish(domain::Id activity_version_id,
                                   std::string* rsn);

  std::vector<domain::ActivityVersion> PendingVersions(domain::Id user_id);
  std::vector<domain::Activity> ActivitiesOf(domain::Id organizer_id);
  std::vector<domain::Activity> AllActivities(domain::Id user_id);
  std::vector<domain::Activity> Published(domain::Id user_id,
                                          const std::string& key);
  std::vector<domain::ActivityVersion> VersionsOf(domain::Id user_id,
                                                  domain::Id activity_id);
  domain::Activity* FindActivity(domain::Id activity_id);
  domain::ActivityVersion* FindVersion(domain::Id activity_version_id);
  domain::ActivityVersion* CurrentVersion(domain::Id activity_id);
  domain::ActivityVersion* LatestVersion(domain::Id activity_id);
  std::string DescribeVersion(domain::Id activity_version_id);

 private:
  friend class RoleService;
  ServiceResult CancelForRoleRemoval(domain::Id administrator_id,
                                     domain::Id organizer_id,
                                     domain::Id activity_id);
  ServiceResult CancelForAccountDisable(domain::Id administrator_id,
                                        domain::Id organizer_id,
                                        domain::Id activity_id);
  ServiceResult CancelActivityInternal(domain::Id actor_id,
                                       domain::Id organizer_id,
                                       domain::Id activity_id,
                                       bool require_organizer_session,
                                       const std::string& audit_suffix);

  infra::DataStore* db_;
  RoleService* rls_;
  AuditService* aud_;
  NotificationService* ntfs_;
  TicketService* tkts_;
};

}
}

#endif
