

#include "service/role_service.h"

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "domain/datetime.h"
#include "infra/data_store.h"
#include "service/activity_service.h"
#include "service/audit_service.h"

namespace campus {
namespace service {

namespace {

bool IsAdministrator(domain::Role rl) {
  return rl == domain::Role::kAdministrator;
}

bool HasOngoingRegistration(infra::DataStore* db, domain::Id user_id) {
  const auto ts = domain::Now();
  for (const auto& reg : db->regs()) {
    if (reg.user_id != user_id ||
        (reg.status != domain::RegistrationStatus::kRegistered &&
         reg.status != domain::RegistrationStatus::kWaitlisted &&
         reg.status != domain::RegistrationStatus::kCheckedIn)) {
      continue;
    }
    bool found = false;
    for (const auto& session : db->ssns()) {
      if (session.logical_session_id == reg.logical_session_id &&
          session.activity_version_id == reg.activity_version_id) {
        found = true;
        if (session.end_time > ts) return true;
      }
    }
    if (!found) return true;
  }
  return false;
}

}

RoleService::RoleService(infra::DataStore* db, AuditService* aud)
    : db_(db), aud_(aud) {
  aud_->BindRoles(this);
}

bool RoleService::SignedIn(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  for (const auto& u : db_->usrs()) {
    if (u.id == user_id) {
      return ins_.count(user_id) != 0 &&
             u.status == domain::UserStatus::kActive &&
             u.locked_until <= domain::Now();
    }
  }
  return false;
}

bool RoleService::Ready(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (!SignedIn(user_id)) return false;
  for (const auto& u : db_->usrs()) {
    if (u.id == user_id) return !u.must_change_password;
  }
  return false;
}

void RoleService::Open(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  ins_.insert(user_id);
}
void RoleService::Close(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  ins_.erase(user_id);
}

std::vector<domain::Role> RoleService::RolesOf(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::Role> rls;
  std::vector<domain::UserRole>& xsAll = db_->user_roles();
  for (std::size_t i = 0; i < xsAll.size(); ++i) {
    if (xsAll[i].user_id == user_id) {
      rls.push_back(xsAll[i].role_code);
    }
  }
  return rls;
}

bool RoleService::HasRole(domain::Id user_id, domain::Role rl) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  const std::vector<domain::Role> rls = RolesOf(user_id);
  for (std::size_t i = 0; i < rls.size(); ++i) {
    if (rls[i] == rl) {
      return true;
    }
  }
  return false;
}

bool RoleService::CanAccess(domain::Role rl, const std::string& modCd) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  if (IsAdministrator(rl)) {
    return true;
  }
  if (rl == domain::Role::kOrdinaryParticipant) {
    return modCd == "M5" || modCd == "M6" || modCd == "M8";
  }
  if (rl == domain::Role::kOrganizer) {
    return modCd == "M3" || modCd == "M4" || modCd == "M7" || modCd == "M8";
  }
  if (rl == domain::Role::kInspector) {
    return modCd == "M6" || modCd == "M8";
  }
  return false;
}

ServiceResult RoleService::AssignRole(domain::Id operator_id,
                                      domain::Id target_user_id,
                                      domain::Role rl) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(operator_id, "分配角色", msg);
  };
  if (!Ready(operator_id) ||
      !HasRole(operator_id, domain::Role::kAdministrator)) {
    return fail("仅管理员可以分配角色");
  }
  if (!UserExists(target_user_id)) {
    return fail("目标用户不存在");
  }
  if (HasRole(target_user_id, rl)) {
    return fail("该用户已拥有此角色");
  }
  domain::UserRole usrRl;
  usrRl.user_id = target_user_id;
  usrRl.role_code = rl;
  db_->user_roles().push_back(usrRl);
  aud_->Log(operator_id, "分配角色", domain::AuditResult::kSuccess,
            "用户 " + std::to_string(target_user_id) + " 获得角色 " +
                domain::ToString(rl));
  return ServiceResult::Ok("角色分配成功");
}

ServiceResult RoleService::RemoveRole(domain::Id operator_id,
                                      domain::Id target_user_id,
                                      domain::Role rl) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(operator_id, "移除角色", msg);
  };
  if (!Ready(operator_id) ||
      !HasRole(operator_id, domain::Role::kAdministrator)) {
    return fail("仅管理员可以移除角色");
  }
  const std::vector<domain::Role> rls = RolesOf(target_user_id);
  if (rl == domain::Role::kAdministrator) {
    int n = 0;
    for (const auto& u : db_->usrs()) {
      if (u.status == domain::UserStatus::kActive && HasRole(u.id, rl)) ++n;
    }
    if (n <= 1 && HasRole(target_user_id, rl))
      return fail("不能移除最后一个启用管理员");
  }
  if (rl == domain::Role::kOrdinaryParticipant &&
      HasOngoingRegistration(db_, target_user_id)) {
    return fail("用户仍有进行中的报名、候补或签到记录，不能移除参与者角色");
  }
  if (rls.size() <= 1) {
    return fail("不能移除用户的最后一个角色");
  }
  std::vector<domain::UserRole>& xsAll = db_->user_roles();
  std::size_t role_index = xsAll.size();
  for (std::size_t i = 0; i < xsAll.size(); ++i) {
    if (xsAll[i].user_id == target_user_id && xsAll[i].role_code == rl) {
      role_index = i;
      break;
    }
  }
  if (role_index == xsAll.size()) return fail("该用户不拥有此角色");

  infra::Transaction tx(db_);
  int cancelled_activities = 0;
  if (rl == domain::Role::kOrganizer) {
    if (acts_ == nullptr) {
      tx.Rollback();
      return fail("活动服务尚未就绪，不能安全移除组织者角色");
    }
    std::vector<domain::Id> activity_ids;
    for (const auto& activity : db_->acts()) {
      if (activity.creator_id == target_user_id &&
          activity.status != domain::ActivityStatus::kCancelled &&
          activity.status != domain::ActivityStatus::kEnded) {
        activity_ids.push_back(activity.id);
      }
    }
    for (const auto activity_id : activity_ids) {
      const auto cancelled =
          acts_->CancelForRoleRemoval(operator_id, target_user_id, activity_id);
      if (!cancelled.ok) {
        tx.Rollback();
        return fail("名下活动无法自动取消，组织者角色未移除：" + cancelled.msg);
      }
      ++cancelled_activities;
    }
  }

  xsAll.erase(xsAll.begin() + static_cast<std::ptrdiff_t>(role_index));
  if (rl == domain::Role::kInspector) {
    for (auto& g : db_->session_grants()) {
      if (g.user_id == target_user_id) g.status = domain::GrantStatus::kInvalid;
    }
  }
  aud_->Log(operator_id, "移除角色", domain::AuditResult::kSuccess,
            "用户 " + std::to_string(target_user_id) + " 移除角色 " +
                domain::ToString(rl) + "，自动取消活动 " +
                std::to_string(cancelled_activities) + " 个");
  tx.Commit();
  return ServiceResult::Ok(cancelled_activities == 0
                               ? "角色已移除"
                               : "角色已移除，名下未结束活动已自动取消");
}

ServiceResult RoleService::CancelOwnedActivitiesForAccountDisable(
    domain::Id operator_id, domain::Id organizer_id,
    int* cancelled_activities) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  *cancelled_activities = 0;
  if (acts_ == nullptr)
    return ServiceResult::Fail("活动服务尚未就绪，不能安全停用组织者账号");
  std::vector<domain::Id> activity_ids;
  for (const auto& activity : db_->acts()) {
    if (activity.creator_id == organizer_id &&
        activity.status != domain::ActivityStatus::kCancelled &&
        activity.status != domain::ActivityStatus::kEnded)
      activity_ids.push_back(activity.id);
  }
  for (const auto activity_id : activity_ids) {
    const auto cancelled =
        acts_->CancelForAccountDisable(operator_id, organizer_id, activity_id);
    if (!cancelled.ok) return cancelled;
    ++*cancelled_activities;
  }
  return ServiceResult::Ok("组织者名下未结束活动已自动取消");
}

ServiceResult RoleService::GrantSession(domain::Id operator_id,
                                        domain::Id inspector_id,
                                        domain::Id logical_session_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(operator_id, "场次授权", msg);
  };
  if (!Ready(operator_id) ||
      !HasRole(operator_id, domain::Role::kAdministrator)) {
    return fail("仅管理员可以授予场次权限");
  }
  if (!HasRole(inspector_id, domain::Role::kInspector)) {
    return fail("目标用户不是检票员");
  }
  bool ssnOk = false;
  std::vector<domain::LogicalSession>& ssns = db_->logical_sessions();
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    if (ssns[i].id == logical_session_id && !ssns[i].cancelled) {
      ssnOk = true;
      break;
    }
  }
  if (!ssnOk) {
    return fail("逻辑场次不存在或已取消");
  }
  std::vector<domain::SessionGrant>& grts = db_->session_grants();
  for (std::size_t i = 0; i < grts.size(); ++i) {
    if (grts[i].user_id == inspector_id &&
        grts[i].logical_session_id == logical_session_id) {
      grts[i].status = domain::GrantStatus::kValid;
      aud_->Log(operator_id, "场次授权", domain::AuditResult::kSuccess,
                "检票员 " + std::to_string(inspector_id) + " 场次 " +
                    std::to_string(logical_session_id));
      return ServiceResult::Ok("场次授权已更新");
    }
  }
  domain::SessionGrant grt;
  grt.user_id = inspector_id;
  grt.logical_session_id = logical_session_id;
  grt.status = domain::GrantStatus::kValid;
  grts.push_back(grt);
  aud_->Log(operator_id, "场次授权", domain::AuditResult::kSuccess,
            "检票员 " + std::to_string(inspector_id) + " 场次 " +
                std::to_string(logical_session_id));
  return ServiceResult::Ok("场次授权成功");
}

std::vector<domain::SessionGrant> RoleService::GrantsOf(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::SessionGrant> res;
  std::vector<domain::SessionGrant>& grts = db_->session_grants();
  for (std::size_t i = 0; i < grts.size(); ++i) {
    if (grts[i].user_id == user_id) {
      res.push_back(grts[i]);
    }
  }
  return res;
}

ServiceResult RoleService::RevokeSession(domain::Id operator_id,
                                         domain::Id inspector_id,
                                         domain::Id logical_session_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  auto fail = [&](const std::string& msg) {
    return aud_->Fail(operator_id, "撤销场次授权", msg);
  };
  if (!Ready(operator_id) ||
      !HasRole(operator_id, domain::Role::kAdministrator))
    return fail("仅管理员可以撤销场次授权");
  for (auto& g : db_->session_grants()) {
    if (g.user_id != inspector_id || g.logical_session_id != logical_session_id)
      continue;
    if (g.status == domain::GrantStatus::kInvalid)
      return fail("场次授权已失效");
    g.status = domain::GrantStatus::kInvalid;
    aud_->Log(operator_id, "撤销场次授权", domain::AuditResult::kSuccess,
              "检票员 " + std::to_string(inspector_id) + " 场次 " +
                  std::to_string(logical_session_id));
    return ServiceResult::Ok("场次授权已撤销");
  }
  return fail("未找到该场次授权");
}

bool RoleService::HasValidGrant(domain::Id inspector_id,
                                domain::Id logical_session_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::SessionGrant>& grts = db_->session_grants();
  for (std::size_t i = 0; i < grts.size(); ++i) {
    if (grts[i].user_id == inspector_id &&
        grts[i].logical_session_id == logical_session_id &&
        grts[i].status == domain::GrantStatus::kValid) {
      return true;
    }
  }
  return false;
}

bool RoleService::UserExists(domain::Id user_id) {
  std::lock_guard<std::recursive_mutex> lk(db_->Mutex());
  std::vector<domain::User>& usrs = db_->usrs();
  for (std::size_t i = 0; i < usrs.size(); ++i) {
    if (usrs[i].id == user_id) {
      return true;
    }
  }
  return false;
}

}
}
