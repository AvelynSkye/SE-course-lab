

#ifndef UI_CONSOLE_VIEW_H_
#define UI_CONSOLE_VIEW_H_

#include <string>
#include <vector>

#include "domain/enums.h"
#include "domain/types.h"

namespace campus {
namespace app {
struct AppContext;
}

namespace ui {

class ConsoleView {
 public:
  explicit ConsoleView(app::AppContext* ctx);

  void Run();

 private:
  void PrintBanner();
  void LoginLoop();
  bool EnsurePasswordChanged(domain::Id user_id);
  domain::Role ChooseRole(const std::vector<domain::Role>& rls);
  void Dispatch(domain::Role rl, domain::Id user_id);

  void ParticipantMenu(domain::Id user_id);
  void OrganizerMenu(domain::Id user_id);
  void InspectorMenu(domain::Id user_id);
  void AdminMenu(domain::Id user_id);

  void ShowPublishedActivities(domain::Id user_id, const std::string& key = "");
  void ShowActivityDetail(domain::Id activity_id);
  void DoRegister(domain::Id user_id);
  void DoCancelRegistration(domain::Id user_id);
  void ShowMyRegistrations(domain::Id user_id);
  void ShowMyTickets(domain::Id user_id);
  void ShowNotifications(domain::Id user_id);
  void ChangePassword(domain::Id user_id);

  void ShowOrganizerVersions(domain::Id user_id);
  void CreateActivity(domain::Id user_id);
  void EditDraft(domain::Id user_id);
  void ManageSessions(domain::Id user_id);
  void SubmitReview(domain::Id user_id);
  void PublishVersion(domain::Id user_id);
  void CancelActivity(domain::Id user_id);
  void ShowStats(domain::Id user_id);
  void ShowVersionDetail(domain::Id activity_version_id);

  void CheckIn(domain::Id user_id);
  void ShowGrants(domain::Id user_id);

  void ReviewVersions(domain::Id user_id);
  void ListUsers(domain::Id user_id);
  void CreateAccount(domain::Id user_id);
  void AssignRole(domain::Id user_id, bool rm = false);
  void ChangeUserStatus(domain::Id user_id);
  void GrantSession(domain::Id user_id, bool rev = false);
  void ShowAuditLogs(domain::Id user_id);
  void BackgroundTasks(domain::Id user_id);
  void ShowTasks(domain::Id user_id);

  app::AppContext* ctx_;
};

}
}

#endif
