

#include "ui/console_view.h"

#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

#include "app/app_context.h"
#include "domain/datetime.h"
#include "domain/entities.h"
#include "infra/data_store.h"
#include "service/activity_service.h"
#include "service/auth_service.h"
#include "service/notification_service.h"
#include "service/registration_service.h"
#include "service/role_service.h"
#include "service/service_result.h"
#include "service/session_service.h"
#include "service/ticket_service.h"
#include "ui/console_io.h"

namespace campus {
namespace ui {

ConsoleView::ConsoleView(app::AppContext* ctx) : ctx_(ctx) {}

void ConsoleView::ChangePassword(domain::Id user_id) {
  const auto old = io::ReadLine("原密码: ");
  const auto pwd = io::ReadLine("新密码: ");
  const auto res = ctx_->auth->ChangePassword(user_id, old, pwd);
  if (res.ok)
    io::PrintOk(res.msg);
  else
    io::PrintFail(res.msg);
}

void ConsoleView::PrintBanner() {
  std::cout << "=================================================="
            << std::endl;
  std::cout << "        校园活动票务与报名系统（控制台版）        "
            << std::endl;
  std::cout << "  四角色：普通参与者 / 组织者 / 检票员 / 管理员   "
            << std::endl;
  std::cout << "=================================================="
            << std::endl;
}

void ConsoleView::Run() {
  PrintBanner();
  LoginLoop();
  if (ctx_->db->Save(ctx_->ddir))
    io::PrintInfo("数据已保存，系统退出。");
  else
    io::PrintFail("数据保存失败。");
}

bool ConsoleView::EnsurePasswordChanged(domain::Id user_id) {
  domain::User* usr = ctx_->auth->FindUser(user_id);
  if (usr == nullptr) {
    return false;
  }
  if (!usr->must_change_password) {
    return true;
  }
  io::PrintInfo("首次登录必须修改初始密码。");
  while (true) {
    const std::string oldPwd = io::ReadLine("原密码: ");
    const std::string newPwd = io::ReadLine("新密码（至少 6 位）: ");
    const service::ServiceResult res =
        ctx_->auth->ChangePassword(user_id, oldPwd, newPwd);
    if (res.ok) {
      io::PrintOk(res.msg);
      return true;
    }
    io::PrintFail(res.msg);
    if (!io::Confirm("是否继续修改密码")) {
      return false;
    }
  }
}

domain::Role ConsoleView::ChooseRole(const std::vector<domain::Role>& rls) {
  io::PrintInfo("该账号拥有多个角色，请选择本次登录身份：");
  for (std::size_t i = 0; i < rls.size(); ++i) {
    std::cout << "  " << (i + 1) << ". " << domain::ToString(rls[i])
              << std::endl;
  }
  while (true) {
    const int ch = io::ReadInt("请选择: ");
    if (ch >= 1 && ch <= static_cast<int>(rls.size())) {
      return rls[static_cast<std::size_t>(ch - 1)];
    }
    io::PrintFail("无效选项");
  }
}

void ConsoleView::LoginLoop() {
  while (true) {
    const std::string account = io::ReadLine("\n账号（输入 0 退出系统）: ");
    if (account == "0") {
      return;
    }
    const std::string pwd = io::ReadLine("密码: ");
    domain::Id user_id = 0;
    const service::ServiceResult res =
        ctx_->auth->Login(account, pwd, &user_id);
    if (!res.ok) {
      io::PrintFail(res.msg);
      continue;
    }
    io::PrintOk(res.msg);
    if (!EnsurePasswordChanged(user_id)) {
      ctx_->rls->Close(user_id);
      continue;
    }
    const std::vector<domain::Role> rls = ctx_->rls->RolesOf(user_id);
    if (rls.empty()) {
      io::PrintFail("该账号尚未分配角色，请联系管理员");
      continue;
    }
    domain::Role rl = rls[0];
    if (rls.size() > 1) {
      rl = ChooseRole(rls);
    }
    Dispatch(rl, user_id);
    ctx_->rls->Close(user_id);
    if (!ctx_->db->Save(ctx_->ddir))
      io::PrintFail("保存失败，内存修改尚未持久化");
  }
}

void ConsoleView::Dispatch(domain::Role rl, domain::Id user_id) {
  switch (rl) {
    case domain::Role::kOrdinaryParticipant:
      ParticipantMenu(user_id);
      break;
    case domain::Role::kOrganizer:
      OrganizerMenu(user_id);
      break;
    case domain::Role::kInspector:
      InspectorMenu(user_id);
      break;
    case domain::Role::kAdministrator:
      AdminMenu(user_id);
      break;
  }
  io::PrintInfo("已退出当前角色菜单。");
}

void ConsoleView::ParticipantMenu(domain::Id user_id) {
  while (true) {
    std::cout << "\n--- 参与者菜单 ---" << std::endl;
    std::cout << "1. 浏览已发布活动与场次" << std::endl;
    std::cout << "2. 报名（选择场次，每场限一份，可报多场）" << std::endl;
    std::cout << "3. 取消报名" << std::endl;
    std::cout << "4. 查看我的报名" << std::endl;
    std::cout << "5. 查看我的验票凭证" << std::endl;
    std::cout << "6. 查看通知" << std::endl;
    std::cout << "7. 按标题 / 简介 / 地点 / 类别筛选" << std::endl;
    std::cout << "90. 修改密码 / 91. 通知历史" << std::endl;
    std::cout << "0. 退出登录" << std::endl;
    const int ch = io::ReadInt("请选择: ");
    switch (ch) {
      case 90:
        ChangePassword(user_id);
        break;
      case 91:
        ShowNotifications(user_id);
        break;
      case 1:
        ShowPublishedActivities(user_id);
        break;
      case 2:
        DoRegister(user_id);
        break;
      case 3:
        DoCancelRegistration(user_id);
        break;
      case 4:
        ShowMyRegistrations(user_id);
        break;
      case 5:
        ShowMyTickets(user_id);
        break;
      case 6:
        ShowNotifications(user_id);
        break;
      case 7:
        ShowPublishedActivities(user_id, io::ReadLine("筛选关键词: "));
        break;
      case 0:
        return;
      default:
        io::PrintFail("无效选项");
        break;
    }
    if (!ctx_->db->Save(ctx_->ddir))
      io::PrintFail("保存失败，内存修改尚未持久化");
  }
}

void ConsoleView::ShowPublishedActivities(domain::Id user_id,
                                          const std::string& key) {
  const std::vector<domain::Activity> acts =
      ctx_->acts->Published(user_id, key);
  bool fnd = false;
  for (std::size_t i = 0; i < acts.size(); ++i) {
    domain::ActivityVersion* ver = ctx_->acts->CurrentVersion(acts[i].id);
    if (ver == nullptr) {
      continue;
    }
    fnd = true;
    std::cout << "\n[活动#" << acts[i].id << "] " << acts[i].title
              << "（当前版本#" << ver->id << "）" << std::endl;
    ShowVersionDetail(ver->id);
  }
  if (!fnd) {
    io::PrintInfo(key.empty() ? "当前没有已发布的活动。"
                              : "没有符合关键词的已发布活动。");
  }
}

void ConsoleView::ShowVersionDetail(domain::Id activity_version_id) {
  const auto* ver = ctx_->acts->FindVersion(activity_version_id);
  if (ver == nullptr) return;
  std::cout << "  标题：" << ver->title << "\n  简介：" << ver->description
            << std::endl;
  const std::vector<domain::Session> ssns =
      ctx_->ssns->SessionsOfVersion(activity_version_id);
  for (std::size_t i = 0; i < ssns.size(); ++i) {
    const domain::Session& ssn = ssns[i];
    domain::LogicalSession* lgl =
        ctx_->ssns->FindLogicalSession(ssn.logical_session_id);
    std::cout << "  场次#" << ssn.logical_session_id << " " << ssn.location
              << " " << domain::FormatTime(ssn.start_time) << " ~ "
              << domain::FormatTime(ssn.end_time) << " 报名截止 "
              << domain::FormatTime(ssn.registration_end) << " 容量 "
              << ssn.capacity;
    if (lgl != nullptr && lgl->cancelled) {
      std::cout << " [已取消]";
    }
    std::cout << std::endl;
  }
  const std::vector<domain::CategoryVersion> cats =
      ctx_->ssns->CategoriesOfVersion(activity_version_id);
  for (std::size_t i = 0; i < cats.size(); ++i) {
    const auto* lc =
        ctx_->ssns->FindLogicalCategory(cats[i].logical_category_id);
    std::cout << "    类别#" << cats[i].logical_category_id << " "
              << cats[i].name << " 名额 " << cats[i].capacity << " 所属场次#"
              << cats[i].logical_session_id << " 类别版本#" << cats[i].id
              << (lc != nullptr && lc->cancelled ? " [已取消]" : "")
              << std::endl;
  }
}

void ConsoleView::DoRegister(domain::Id user_id) {
  ShowPublishedActivities(user_id);
  const domain::Id sid = io::ReadId("请输入场次逻辑 ID: ");
  const domain::Id cid = 0;
  const std::string ky =
      io::ReadLine("幂等键（可空，重复提交演示时填入相同值）: ");
  std::string det;
  const service::ServiceResult res =
      ctx_->regs->Register(user_id, sid, cid, ky, &det);
  if (res.ok) {
    io::PrintOk(res.msg);
    io::PrintInfo("剩余名额：" +
                  std::to_string(ctx_->regs->RemainingSeats(sid, cid)));
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::DoCancelRegistration(domain::Id user_id) {
  ShowMyRegistrations(user_id);
  const domain::Id registration_id = io::ReadId("请输入要取消的报名 ID: ");
  if (!io::Confirm("确认取消该报名")) {
    io::PrintInfo("已放弃操作。");
    return;
  }
  std::string det;
  const service::ServiceResult res =
      ctx_->regs->Cancel(user_id, registration_id, &det);
  if (res.ok) {
    io::PrintOk(res.msg);
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::ShowMyRegistrations(domain::Id user_id) {
  const std::vector<domain::Registration> xs =
      ctx_->regs->RegistrationsOf(user_id);
  if (xs.empty()) {
    io::PrintInfo("暂无报名记录。");
    return;
  }
  for (std::size_t i = 0; i < xs.size(); ++i) {
    std::cout << "  " << ctx_->tkts->Describe(xs[i].id) << std::endl;
  }
}

void ConsoleView::ShowMyTickets(domain::Id user_id) {
  const std::vector<domain::Registration> xs =
      ctx_->regs->RegistrationsOf(user_id);
  bool fnd = false;
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (xs[i].status == domain::RegistrationStatus::kRegistered ||
        xs[i].status == domain::RegistrationStatus::kCheckedIn) {
      std::cout << "  " << ctx_->tkts->Describe(xs[i].id) << std::endl;
      fnd = true;
    }
  }
  if (!fnd) {
    io::PrintInfo("暂无有效凭证。");
  }
}

void ConsoleView::ShowNotifications(domain::Id user_id) {
  const std::vector<domain::Notification> xs = ctx_->ntfs->History(user_id);
  if (xs.empty()) {
    io::PrintInfo("暂无通知。");
    return;
  }
  for (std::size_t i = 0; i < xs.size(); ++i) {
    std::cout << "  #" << xs[i].id << " [" << domain::ToString(xs[i].typ)
              << (xs[i].read ? " 已读] " : " 未读] ")
              << domain::FormatTime(xs[i].created_at) << " " << xs[i].cnt
              << std::endl;
  }
  const auto ch = io::ReadId("标记已读：输入通知 ID，-1 全部标记，0 返回: ");
  if (ch > 0) {
    if (!ctx_->ntfs->MarkRead(user_id, ch))
      io::PrintFail("通知不存在或无权访问");
  }
  if (ch == -1) {
    const int n = ctx_->ntfs->MarkAllRead(user_id);
    io::PrintInfo("已标记 " + std::to_string(n) + " 条通知为已读。");
  }
}

}
}
