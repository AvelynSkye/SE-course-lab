

#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

#include "app/app_context.h"
#include "domain/datetime.h"
#include "domain/entities.h"
#include "infra/data_store.h"
#include "service/activity_service.h"
#include "service/audit_service.h"
#include "service/registration_service.h"
#include "service/role_service.h"
#include "service/service_result.h"
#include "service/session_service.h"
#include "service/stats_service.h"
#include "service/ticket_service.h"
#include "ui/console_io.h"
#include "ui/console_view.h"

namespace campus {
namespace ui {

void ConsoleView::OrganizerMenu(domain::Id user_id) {
  while (true) {
    std::cout << "\n--- 组织者菜单 ---" << std::endl;
    std::cout << "1. 我的活动与版本" << std::endl;
    std::cout << "2. 创建活动" << std::endl;
    std::cout << "3. 编辑草稿 / 被驳回版本" << std::endl;
    std::cout << "4. 场次与票额维护" << std::endl;
    std::cout << "5. 提交审核" << std::endl;
    std::cout << "6. 发布活动（发布前复核）" << std::endl;
    std::cout << "7. 取消活动" << std::endl;
    std::cout << "8. 名单统计与导出" << std::endl;
    std::cout << "9. 从当前发布版本创建新草稿" << std::endl;
    std::cout << "10. 查看通知 / 11. 撤回待发布版本" << std::endl;
    std::cout << "90. 修改密码 / 91. 通知历史" << std::endl;
    std::cout << "0. 退出登录" << std::endl;
    const int ch = io::ReadInt("请选择: ");
    switch (ch) {
      case 90:
        ChangePassword(user_id);
        break;
      case 91:
        ShowNotifications(user_id);
        break;
      case 1:
        ShowOrganizerVersions(user_id);
        break;
      case 2:
        CreateActivity(user_id);
        break;
      case 3:
        EditDraft(user_id);
        break;
      case 4:
        ManageSessions(user_id);
        break;
      case 5:
        SubmitReview(user_id);
        break;
      case 6:
        PublishVersion(user_id);
        break;
      case 7:
        CancelActivity(user_id);
        break;
      case 8:
        ShowStats(user_id);
        break;
      case 9: {
        const auto activity_id = io::ReadId("活动 ID: ");
        domain::Id activity_version_id = 0;
        const auto res = ctx_->acts->CreateVersion(user_id, activity_id,
                                                   &activity_version_id);
        if (res.ok)
          io::PrintOk(res.msg);
        else
          io::PrintFail(res.msg);
        break;
      }
      case 11: {
        const auto activity_version_id = io::ReadId("待发布版本 ID: ");
        const auto res = ctx_->acts->Withdraw(user_id, activity_version_id);
        if (res.ok)
          io::PrintOk(res.msg);
        else
          io::PrintFail(res.msg);
        break;
      }
      case 10:
        ShowNotifications(user_id);
        break;
      case 0:
        return;
      default:
        io::PrintFail("无效选项");
        break;
    }
    if (!ctx_->db->Save(ctx_->ddir))
      io::PrintFail("保存失败，内存修改尚未持久化");
  }
}

void ConsoleView::ShowOrganizerVersions(domain::Id user_id) {
  ctx_->aud->Log(user_id, "查看我的活动版本", domain::AuditResult::kSuccess,
                 "活动版本列表");
  const std::vector<domain::Activity> acts = ctx_->acts->ActivitiesOf(user_id);
  if (acts.empty()) {
    io::PrintInfo("您还没有创建活动。");
    return;
  }
  for (std::size_t i = 0; i < acts.size(); ++i) {
    std::cout << "\n[活动#" << acts[i].id << "] " << acts[i].title << " ["
              << domain::ToString(acts[i].status) << "]" << std::endl;
    const std::vector<domain::ActivityVersion> vers =
        ctx_->acts->VersionsOf(user_id, acts[i].id);
    for (std::size_t j = 0; j < vers.size(); ++j) {
      std::cout << "  版本#" << vers[j].id << " V" << vers[j].version_number
                << " [" << domain::ToString(vers[j].status) << "]";
      if (!vers[j].rejection_reason.empty()) {
        std::cout << " 驳回原因: " << vers[j].rejection_reason;
      }
      std::cout << std::endl;
      if (vers[j].status == domain::VersionStatus::kDraft ||
          vers[j].status == domain::VersionStatus::kReviewRejected ||
          vers[j].status == domain::VersionStatus::kApprovedPendingPublish ||
          vers[j].status == domain::VersionStatus::kCurrentPublished) {
        ShowVersionDetail(vers[j].id);
      }
    }
  }
}

void ConsoleView::CreateActivity(domain::Id user_id) {
  const std::string title = io::ReadLine("活动标题: ");
  const std::string description = io::ReadLine("活动简介: ");
  domain::Id activity_id = 0;
  const service::ServiceResult res =
      ctx_->acts->CreateActivity(user_id, title, description, &activity_id);
  if (!res.ok) {
    io::PrintFail(res.msg);
    return;
  }
  io::PrintOk(res.msg);
  domain::ActivityVersion* ver = ctx_->acts->LatestVersion(activity_id);
  if (ver != nullptr) {
    io::PrintInfo("当前草稿版本 ID：" + std::to_string(ver->id) +
                  "，请使用菜单 4 维护场次与票额");
  }
}

void ConsoleView::EditDraft(domain::Id user_id) {
  ShowOrganizerVersions(user_id);
  const domain::Id activity_version_id = io::ReadId("请输入要编辑的版本 ID: ");
  const domain::ActivityVersion* ver =
      ctx_->acts->FindVersion(activity_version_id);
  if (ver == nullptr) {
    io::PrintFail("版本不存在");
    return;
  }
  const domain::Activity* act = ctx_->acts->FindActivity(ver->activity_id);
  if (act == nullptr || act->creator_id != user_id) {
    io::PrintFail("只能编辑自己创建的活动");
    return;
  }
  const std::string title =
      io::ReadLine("新标题（当前：" + act->title + "）: ");
  const std::string description = io::ReadLine("新简介: ");
  const service::ServiceResult res =
      ctx_->acts->EditDraft(user_id, activity_version_id, title, description);
  if (res.ok) {
    io::PrintOk(res.msg);
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::ManageSessions(domain::Id user_id) {
  const domain::Id activity_version_id = io::ReadId("请输入要维护的版本 ID: ");
  const auto* ver = ctx_->acts->FindVersion(activity_version_id);
  const auto* act =
      ver == nullptr ? nullptr : ctx_->acts->FindActivity(ver->activity_id);
  if (!ctx_->rls->Ready(user_id) ||
      !ctx_->rls->HasRole(user_id, domain::Role::kOrganizer) ||
      act == nullptr || act->creator_id != user_id) {
    const auto res =
        ctx_->aud->Fail(user_id, "访问场次维护", "版本不存在或无权访问");
    io::PrintFail(res.msg);
    return;
  }
  while (true) {
    std::cout << "\n--- 场次与票额维护（版本#" << activity_version_id << "）---"
              << std::endl;
    std::cout << "一个活动一种票，各场次独立配置名额。" << std::endl;
    std::cout << "1. 查看场次与类别" << std::endl;
    std::cout << "2. 新增场次" << std::endl;
    std::cout << "3. 配置场次的唯一票种" << std::endl;
    std::cout << "4. 调整类别名额" << std::endl;
    std::cout << "5. 取消场次" << std::endl;
    std::cout << "6. 取消类别" << std::endl;
    std::cout << "7. 编辑场次" << std::endl;
    std::cout << "8. 统一修改本版本票名及所选场次名额" << std::endl;
    std::cout << "0. 返回" << std::endl;
    const int ch = io::ReadInt("请选择: ");
    if (ch == 0) {
      return;
    }
    if (ch == 1) {
      ctx_->aud->Log(user_id, "查看场次类别", domain::AuditResult::kSuccess,
                     std::to_string(activity_version_id));
      ShowVersionDetail(activity_version_id);
      continue;
    }
    if (ch == 2) {
      const std::string location = io::ReadLine("场次地点（A1 至 A20）: ");
      const domain::Timestamp start_time =
          io::ReadTime("开始时间 (YYYY-MM-DD HH:MM): ");
      const domain::Timestamp end_time =
          io::ReadTime("结束时间 (YYYY-MM-DD HH:MM): ");
      const domain::Timestamp registration_start =
          io::ReadTime("报名开始时间 (YYYY-MM-DD HH:MM): ");
      const domain::Timestamp registration_end =
          io::ReadTime("报名截止时间 (YYYY-MM-DD HH:MM): ");
      const int capacity = io::ReadInt("场次容量: ");
      domain::Id logical_session_id = 0;
      const service::ServiceResult res = ctx_->ssns->CreateSession(
          user_id, activity_version_id, location, start_time, end_time,
          registration_start, registration_end, capacity, &logical_session_id);
      if (res.ok) {
        io::PrintOk(res.msg);
      } else {
        io::PrintFail(res.msg);
      }
      continue;
    }
    if (ch == 3) {
      const auto sid = io::ReadId("所属场次逻辑 ID: ");
      const std::string name = io::ReadLine("票名（同一活动各场次须一致）: ");
      const int capacity = io::ReadInt("类别名额: ");
      domain::Id logical_category_id = 0;
      const service::ServiceResult res =
          ctx_->ssns->CreateCategory(user_id, activity_version_id, sid, name,
                                     capacity, &logical_category_id);
      if (res.ok) {
        io::PrintOk(res.msg);
      } else {
        io::PrintFail(res.msg);
      }
      continue;
    }
    if (ch == 4) {
      const domain::Id category_version_id =
          io::ReadId("类别版本 ID（非逻辑 ID）: ");
      const int capacity = io::ReadInt("新的名额: ");
      const service::ServiceResult res = ctx_->ssns->UpdateCategoryQuota(
          user_id, category_version_id, capacity);
      if (res.ok) {
        io::PrintOk(res.msg);
      } else {
        io::PrintFail(res.msg);
      }
      continue;
    }
    if (ch == 5) {
      const domain::Id logical_session_id = io::ReadId("要取消的场次逻辑 ID: ");
      if (!io::Confirm("确认取消该场次")) {
        continue;
      }
      const service::ServiceResult res =
          ctx_->ssns->CancelSession(user_id, logical_session_id);
      if (res.ok) {
        io::PrintOk(res.msg);
      } else {
        io::PrintFail(res.msg);
      }
      continue;
    }
    if (ch == 6) {
      const domain::Id logical_category_id =
          io::ReadId("要取消的类别逻辑 ID: ");
      if (!io::Confirm("确认取消该类别")) {
        continue;
      }
      const service::ServiceResult res =
          ctx_->ssns->CancelCategory(user_id, logical_category_id);
      if (res.ok) {
        io::PrintOk(res.msg);
      } else {
        io::PrintFail(res.msg);
      }
      continue;
    }
    if (ch == 7) {
      const auto sid = io::ReadId("要编辑的场次逻辑 ID: ");
      const auto location = io::ReadLine("新地点（A1 至 A20）: ");
      const auto beg = io::ReadTime("开始时间 (YYYY-MM-DD HH:MM): ");
      const auto end = io::ReadTime("结束时间 (YYYY-MM-DD HH:MM): ");
      const auto rb = io::ReadTime("报名开始 (YYYY-MM-DD HH:MM): ");
      const auto re = io::ReadTime("报名截止 (YYYY-MM-DD HH:MM): ");
      const auto capacity = io::ReadInt("容量: ");
      const auto res =
          ctx_->ssns->UpdateSession(user_id, activity_version_id, sid, location,
                                    beg, end, rb, re, capacity);
      if (res.ok)
        io::PrintOk(res.msg);
      else
        io::PrintFail(res.msg);
      continue;
    }
    if (ch == 8) {
      const auto cid = io::ReadId("类别版本 ID: ");
      const auto name = io::ReadLine("新名称: ");
      const auto capacity = io::ReadInt("名额: ");
      const auto res = ctx_->ssns->UpdateCategory(user_id, cid, name, capacity);
      if (res.ok)
        io::PrintOk(res.msg);
      else
        io::PrintFail(res.msg);
      continue;
    }
    io::PrintFail("无效选项");
  }
}

void ConsoleView::SubmitReview(domain::Id user_id) {
  ShowOrganizerVersions(user_id);
  const domain::Id activity_version_id =
      io::ReadId("请输入要提交审核的版本 ID: ");
  const service::ServiceResult res =
      ctx_->acts->SubmitReview(user_id, activity_version_id);
  if (res.ok) {
    io::PrintOk(res.msg);
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::PublishVersion(domain::Id user_id) {
  ShowOrganizerVersions(user_id);
  const domain::Id activity_version_id = io::ReadId("请输入要发布的版本 ID: ");
  std::string rsn;
  const service::ServiceResult checked =
      ctx_->acts->ValidateForPublish(activity_version_id, &rsn);
  io::PrintInfo("发布前复核结果：" + rsn);
  if (!checked.ok) {
    ctx_->aud->Fail(user_id, "发布复核", rsn);
    return;
  }
  if (!io::Confirm("确认发布该版本")) {
    return;
  }
  const service::ServiceResult res =
      ctx_->acts->Publish(user_id, activity_version_id);
  if (res.ok) {
    io::PrintOk(res.msg);
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::CancelActivity(domain::Id user_id) {
  ShowOrganizerVersions(user_id);
  const domain::Id activity_id = io::ReadId("请输入要取消的活动 ID: ");
  if (!io::Confirm("确认取消该活动（将撤销全部报名）")) {
    return;
  }
  const service::ServiceResult res =
      ctx_->acts->CancelActivity(user_id, activity_id);
  if (res.ok) {
    io::PrintOk(res.msg);
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::ShowStats(domain::Id user_id) {
  const domain::Id activity_id = io::ReadId("请输入活动 ID: ");
  const std::vector<service::StatResult> sts =
      ctx_->sts->QueryStats(user_id, activity_id);
  if (sts.empty()) {
    io::PrintFail("活动不存在或无权查看");
    return;
  }
  io::PrintInfo(sts[0].ToString());
  if (!io::Confirm("是否导出名单 CSV")) {
    return;
  }
  std::string pth =
      io::ReadLine("导出路径（回车使用默认 " + ctx_->ddir + "/roster.csv）: ");
  if (pth.empty()) {
    pth = ctx_->ddir + "/roster_" + std::to_string(activity_id) + ".csv";
  }
  std::string sum;
  const service::ServiceResult res =
      ctx_->sts->ExportRoster(user_id, activity_id, pth, &sum);
  if (res.ok) {
    io::PrintOk(res.msg);
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::InspectorMenu(domain::Id user_id) {
  while (true) {
    std::cout << "\n--- 检票员菜单 ---" << std::endl;
    std::cout << "1. 输入凭证码验票签到" << std::endl;
    std::cout << "2. 查看我的场次授权" << std::endl;
    std::cout << "90. 修改密码 / 91. 通知历史" << std::endl;
    std::cout << "0. 退出登录" << std::endl;
    const int ch = io::ReadInt("请选择: ");
    switch (ch) {
      case 90:
        ChangePassword(user_id);
        break;
      case 91:
        ShowNotifications(user_id);
        break;
      case 1:
        CheckIn(user_id);
        break;
      case 2:
        ShowGrants(user_id);
        break;
      case 0:
        return;
      default:
        io::PrintFail("无效选项");
        break;
    }
    if (!ctx_->db->Save(ctx_->ddir))
      io::PrintFail("保存失败，内存修改尚未持久化");
  }
}

void ConsoleView::CheckIn(domain::Id user_id) {
  const std::string code = io::ReadLine("请输入或扫描凭证码: ");
  const service::ServiceResult res = ctx_->tkts->CheckIn(user_id, code);
  if (res.ok) {
    io::PrintOk(res.msg);
  } else {
    io::PrintFail(res.msg);
  }
}

void ConsoleView::ShowGrants(domain::Id user_id) {
  const std::vector<domain::SessionGrant> grts = ctx_->rls->GrantsOf(user_id);
  if (grts.empty()) {
    io::PrintInfo("暂无场次授权。");
    return;
  }
  for (std::size_t i = 0; i < grts.size(); ++i) {
    std::cout << "  场次逻辑#" << grts[i].logical_session_id << " ["
              << domain::ToString(grts[i].status) << "]" << std::endl;
  }
}

}
}
