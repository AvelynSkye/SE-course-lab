

#ifndef DOMAIN_ENTITIES_H_
#define DOMAIN_ENTITIES_H_

#include <string>

#include "domain/enums.h"
#include "domain/types.h"

namespace campus {
namespace domain {

struct User {
  Id id = 0;
  std::string account;
  std::string name;
  std::string password_hash;
  UserStatus status = UserStatus::kActive;
  bool must_change_password = false;
  int failed_login_count = 0;
  Timestamp locked_until = 0;
  Timestamp failed_login_window_start = 0;
};

struct UserRole {
  Id user_id = 0;
  Role role_code = Role::kOrdinaryParticipant;
};

struct Activity {
  Id id = 0;
  std::string title;
  ActivityStatus status = ActivityStatus::kNotPublished;
  Id creator_id = 0;
};

struct ActivityVersion {
  Id id = 0;
  Id activity_id = 0;
  int version_number = 1;
  VersionStatus status = VersionStatus::kDraft;
  Timestamp published_at = 0;
  std::string description;
  std::string rejection_reason;
  std::string title;
};

struct LogicalSession {
  Id id = 0;
  bool cancelled = false;
};

struct Session {
  Id id = 0;
  Id logical_session_id = 0;
  Id activity_version_id = 0;
  std::string location;
  Timestamp start_time = 0;
  Timestamp end_time = 0;
  Timestamp registration_start = 0;
  Timestamp registration_end = 0;
  int capacity = 0;
};

struct LogicalCategory {
  Id id = 0;
  bool cancelled = false;
};

struct CategoryVersion {
  Id id = 0;
  Id logical_category_id = 0;
  Id activity_version_id = 0;
  std::string name;
  int capacity = 0;
  Id logical_session_id = 0;
};

struct SessionGrant {
  Id user_id = 0;
  Id logical_session_id = 0;
  GrantStatus status = GrantStatus::kValid;
};

struct Registration {
  Id id = 0;
  Id user_id = 0;
  Id logical_session_id = 0;
  Id logical_category_id = 0;
  Id activity_version_id = 0;
  RegistrationStatus status = RegistrationStatus::kWaitlisted;
  Id waitlist_sequence = 0;
  Timestamp created_at = 0;
  Timestamp cancelled_at = 0;
};

struct Ticket {
  Id id = 0;
  Id registration_id = 0;
  std::string code;
  TicketStatus status = TicketStatus::kValid;
  Timestamp issued_at = 0;
};

struct CheckinEvent {
  Id id = 0;
  Id registration_id = 0;
  Timestamp checked_at = 0;
};

struct Notification {
  Id id = 0;
  Id user_id = 0;
  NotificationType typ = NotificationType::kPromoted;
  std::string cnt;
  bool read = false;
  Timestamp created_at = 0;
  std::string event_id;
};

struct AuditLog {
  Id id = 0;
  Id user_id = 0;
  std::string actn;
  AuditResult res = AuditResult::kSuccess;
  std::string det;
  Timestamp created_at = 0;
};

struct IdempotencyRecord {
  std::string ky;
  std::string op;
  std::string request_hash;
  std::string res;
  Timestamp created_at = 0;
};

struct BackgroundTask {
  Id id = 0;
  std::string task_type;
  std::string pl;
  TaskStatus status = TaskStatus::kPending;
  int retry_count = 0;
  Id user_id = 0;
  NotificationType typ = NotificationType::kPromoted;
  std::string cnt;
};

}
}

#endif
