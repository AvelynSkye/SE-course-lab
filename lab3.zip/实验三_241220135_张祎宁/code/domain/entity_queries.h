#ifndef DOMAIN_ENTITY_QUERIES_H_
#define DOMAIN_ENTITY_QUERIES_H_

#include <vector>

#include "domain/enums.h"
#include "domain/types.h"

namespace campus {
namespace domain {

// Internal queries: callers must hold the owning DataStore lock while using
// returned pointers. Missing logical entities are treated as unavailable.
template <typename Entity>
Entity* FindById(std::vector<Entity>& entities, Id id) {
  for (auto& entity : entities) {
    if (entity.id == id) return &entity;
  }
  return nullptr;
}

template <typename Entity>
const Entity* FindById(const std::vector<Entity>& entities, Id id) {
  for (const auto& entity : entities) {
    if (entity.id == id) return &entity;
  }
  return nullptr;
}

template <typename Entity>
bool IsCancelledOrMissing(const std::vector<Entity>& entities, Id id) {
  const auto* entity = FindById(entities, id);
  return entity == nullptr || entity->cancelled;
}

inline bool OccupiesSeat(RegistrationStatus status) {
  return status == RegistrationStatus::kRegistered ||
         status == RegistrationStatus::kCheckedIn;
}

}  // namespace domain
}  // namespace campus

#endif  // DOMAIN_ENTITY_QUERIES_H_
