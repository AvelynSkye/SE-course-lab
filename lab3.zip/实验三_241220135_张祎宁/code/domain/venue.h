#ifndef DOMAIN_VENUE_H_
#define DOMAIN_VENUE_H_

#include <string>

namespace campus {
namespace domain {

inline bool ValidVenue(const std::string& location) {
  for (int i = 1; i <= 20; ++i) {
    if (location == "A" + std::to_string(i)) return true;
  }
  return false;
}

}
}

#endif
